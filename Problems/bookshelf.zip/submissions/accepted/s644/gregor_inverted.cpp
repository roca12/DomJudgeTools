#include <bits/stdc++.h>

using namespace std;

const int oo = 0x3f3f3f3f;
const double eps = 1e-9;
const double PI = 2.0 * acos(0.0);


typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;

#define sz(c) int((c).size())
#define all(c) (c).begin(), (c).end()
#define FOR(i,a,b) for (int i = (a); i < (b); i++)
#define FORS(i,a,b,s) for (int i = (a); i < (b); i=i+(s))
#define FORD(i,a,b) for (int i = int(b)-1; i >= (a); i--)
#define FORIT(i,c) for (__typeof__((c).begin()) i = (c).begin(); i != (c).end(); i++)


int main(){
	int N,X,Y; cin >> N >> X >> Y;
	vector<pair<int,int>> books(N);
	FOR(i,0,N) cin >> books[i].second >> books[i].first;
	FOR(i,0,N) if (books[i].second > X || books[i].first > Y) {
		cout << "impossible" << endl;
		return 0;
	}
	sort(all(books));
	reverse(all(books)); // tallest one first;

	// book 0 always goes to the bottom
	int B = books[0].first;
	int T = Y - B;

	// all books taller than the top half must to to the bottom
	int bw = 0;
	int I = 0;
	while (I < N && books[I].first > T)
		bw += books[I].second, I++;

	int restW = 0;
	FOR(i,I,N) restW += books[i].second;

	// now bw width is taken at the bottom, if this is more than we have .... impossible
	if (bw > X){
		cout << "impossible" << endl;
		return 0;
	}

	if (Y == B && bw + restW <= X){
		cout << -1 << endl;
		return 0;	
	}

	// all remaining books will fit in both segments, so check how much width we can put into the top
	
	bool dp[X+1][N+1];
	FOR(w,1,X+1) dp[w][I] = false;
	dp[0][I] = true;
	
	FOR(i,I+1,N+1) FOR(w,0,X+1) {
		dp[w][i] = dp[w][i-1];
		if (books[i-1].second <= w)
			dp[w][i] |= dp[w - books[i-1].second][i-1];
	}

	int maxi = 0;
	FORD(w,0,X+1)
		if (dp[w][N]) {
			maxi = w; break;
		}

	if (restW - maxi > X - bw){
		cout << "impossible" << endl;
	} else cout << Y - B << endl;
}
