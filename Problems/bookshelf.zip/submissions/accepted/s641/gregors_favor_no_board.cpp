#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std;

void possible(int z) {cout << z << endl; exit(0);}
void impossible() {cout << "impossible" << endl; exit(0);}

int main()
{
	int n,x,y; cin >> n >> x >> y;
	vector<pair<int,int>> books;
	int totalW = 0;
	for (int i = 0; i < n; ++i)
	{
		int w,h; cin >> w >> h;
		if (w > x || h > y) impossible();
		totalW += w;
		books.emplace_back(w,h);
	}
	sort(books.begin(), books.end(), [](auto &p1, auto &p2) {return p1.second > p2.second;});
	int board = books.front().second;
	if (board <= y && totalW <= x) possible(-1);
	if (board == y && totalW > x) impossible();
	int greedyW = 0;
	int k = 0;
	while (k < n && books[k].second > y - board)
	{
		greedyW += books[k].first;
		k++;
	}
	if (greedyW > x) impossible();
	int cap = x - greedyW;
	vector<int> dp(cap+1,0);
	for (int i = k; i < n; ++i)
	{
		int wi = books[i].first;
		for (int j = cap; j >= wi; --j)
			dp[j] = max(dp[j], dp[j-wi] + wi);
	}
	if (totalW - greedyW - dp[cap] > x) impossible();
	possible(board);
}
