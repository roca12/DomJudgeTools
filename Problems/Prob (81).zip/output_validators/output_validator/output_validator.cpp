#include <cassert>
#include "validation.h"

int main(int argc, char **argv) {
	std::ifstream in(argv[1]);    // testcase input
	std::ifstream ans(argv[2]);    // testcase output
	OutputValidator v(argc, argv);

	if( v.peek('i') || v.peek('I') ){
		v.read_string("impossible");
		v.newline();
		string s;
		ans >> s;
		v.check(s == "impossible", "Printed impossible but .ans says it's possible!");
		return 0;
	}

	int n, k;
	in >> n >> k;

	vector<pair<int,int>> sheets(n);
	for(auto &s : sheets) in >> s.first >> s.second;

	vector<bool> used(n, false);
	for(int i = 0; i < k; ++i){
		int s = v.read_long_long(1, n);
		v.newline();

		v.check(!used[s-1], "Sheet ", s, " cannot be used twice!");
		used[s-1] = true;

		int wanted_colour;
		in >> wanted_colour;

		v.check(sheets[s-1].first == wanted_colour or sheets[s-1].second == wanted_colour, "Sheet ", s, " does not contain colour ", wanted_colour, "!");
	}
	
	// Team found a valid solution. Make sure .ans does so as well.
	string s;
	ans >> s;
	if(s == "impossible"){
		cerr << "Team found a valid solution but .ans says impossible!\n";
		assert(false);
	}

	return 0;
}
