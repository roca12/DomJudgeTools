#include <iostream>
#include <vector>
#include <tuple>
#include <algorithm>

using namespace std;

int main() {
    int p, v;
    cin >> p >> v;

    vector<tuple<int, int, int>> peds;

    for (auto i = 0; i < p; i++) {
        int a, b;
        cin >> a >> b;
        tuple<int, int, int> ped;
        if (a < b) {
            ped = make_tuple(a, b, i + 1);
        } else {
            ped = make_tuple(b, a, i + 1);
        }

        peds.push_back(ped);
    }

    sort(peds.begin(), peds.end());

    vector<tuple<int, int>> vases;
    for (auto i = 0; i < v; i++) {
        int vase;
        cin >> vase;
        vases.push_back(make_tuple(vase, i + 1));
    }

    sort(vases.begin(), vases.end());

    vector<tuple<int, int>> mapping;
    int currentPedestalIndex = 0;
    for (auto vidx = 0; vidx < vases.size();) {
        if (currentPedestalIndex >= peds.size()) {
            break;
        }
        auto vase = vases[vidx];
        // This is the next smallest vase, which we need to place on the smallest available pedestal
        auto pedestal = peds[currentPedestalIndex];
        if (get<0>(pedestal) == get<0>(vase) || get<1>(pedestal) == get<0>(vase)) {
            // It fits! Vase vase.1 fits is on pedestal pedestal.2, keep track of this
            mapping.push_back(make_tuple(get<1>(vase), get<2>(pedestal)));
			++vidx;
        } else if (get<0>(pedestal) > get<0>(vase) || get<1>(pedestal) > get<0>(vase)) {
            // If both sides of the pedestal are too small, we will never ever (ever ever) encounter a valid pedestal anymore
            break;
        }
        // else: just skip this pedestal. Maybe the next one fits...

        currentPedestalIndex++;
    }

    if (mapping.size() == v) {
        // All ok, output it
        sort(mapping.begin(), mapping.end());
        for (auto i = 0; i < v; i++) {
            cout << get<1>(mapping[i]) << endl;
        }
    } else {
        cout << "impossible" << endl;
    }

    return 0;
}
