import java.util.Scanner;
import java.util.Stack;
public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int C = 10000;
        int n = sc.nextInt();
        int k = sc.nextInt();
        /*ArrayList<Stack<Integer>> cc = new ArrayList<Stack<Integer>>();
        ArrayList<Stack<Integer>> cc = new ArrayList<Stack<Integer>>();*/
        Stack<Integer>[] cc = new Stack[C+1];
        Stack<Integer>[] cc2= new Stack[C+1];
        Stack<Integer>[] needed = new Stack[C+1];
        for(int i = 0; i <= C; i++) {
            cc[i] = new Stack<Integer>();
            cc2[i] = new Stack<Integer>();
            needed[i] = new Stack<Integer>();
        }
        for(int i = 1; i <= n; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            if(a == b) {
                cc[a].push(i);
            }
            else if(a > b) {
                cc2[b].push(i);
            }
            else {
                cc2[a].push(i);
            }
        }

        int[] ans = new int[k];
        int maxi = -1;
        for(int i = 0; i < k; i++) {
            int c = sc.nextInt();
            needed[c].push(i);
            if(i > maxi)
                maxi = i;
        }

        for(int c = 1; c <= C; c++) {
            while(!needed[c].empty()) {
                if(!cc[c].empty()) {
                    ans[needed[c].pop()] = cc[c].pop();
                }
                else if(!cc2[c-1].empty()) {
                    ans[needed[c].pop()] = cc2[c-1].pop();
                }
                else if(!cc2[c].empty()) {
                    ans[needed[c].pop()] = cc2[c].pop();
                }
                else {
                    System.out.println("impossible");
                    return;
                }
            }
        }

        for(int i = 0; i < k; i++) {
            System.out.println(ans[i]);
        }
	}
}
