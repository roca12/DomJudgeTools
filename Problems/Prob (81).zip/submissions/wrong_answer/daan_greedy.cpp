#include <iostream>
#include <vector>
using namespace std;

int main() {
	int c=10000, m, n, u, v;
	cin >> m >> n;
	vector<int> a(c,0);
	vector<int> b(c-1,0);
	for( int i = 0; i < m; ++i ) {
		cin >> u >> v;
		if( u == v )
			a[u-1]++;
		else
			b[min(u,v)-1]++;
	}
	for( int i = 0; i < n; ++i ) {
		cin >> u; u--;
		if( a[u] > 0 )
			a[u]--;
		else {
			v = u;
			if( v > 0 and ( v == c-1 or  b[v-1]+a[v-1] > b[v]+a[v+1] ) )
				v--;
			if( b[v] <= 0 ) {
				cout << "impossible" << endl;
				return 0;
			}
			b[v]--;
		}
	}
	cout << "possible" << endl;
	return 0;
}
