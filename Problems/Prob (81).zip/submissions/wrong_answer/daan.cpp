#include <iostream>
#include <vector>
using namespace std;

int main() {
	int c=10000, m, n, u, v;
	cin >> m >> n;
	vector<int> a(c,0);
	vector<int> b(c-1,0);
	for( int i = 0; i < m; ++i ) {
		cin >> u >> v;
		if( u == v )
			a[u-1]--;
		else
			b[min(u,v)-1]++;
	}
	for( int i = 0; i < n; ++i ) {
		cin >> u;
		a[u-1]++;
	}
	for( int i = 0; i < c; ++i ) {
		a[i] = max( 0, a[i] );
		a[i] -= b[i];
		b[i] = 0;
		if( a[i] > 0 )
			break;
		if( i+1 < c )
			a[i+1] += a[i];
	}
	for( int i = c; i >= 0; --i ) {
		a[i] = max( 0, a[i] );
		a[i] -= b[i-1];
		b[i-1] = 0;
		if( a[i] > 0 )
			break;
		if( i > 0 )
			a[i-1] += a[i];
	}
	for( int i = 0; i < c; ++i ) {
		if( a[i] > 0 ) {
			cout << "impossible" << endl;
			return 0;
		}
	}
	cout << "possible" << endl;
	return 0;
}
