#include <iostream>
#include <vector>

using namespace std;


int main() {
  int h, w;
  cin >> h >> w;
  vector<string> picture(h);
  double avg_x = 0;
  int mass = 0;
  for(int y=0; y<h; y++) {
    cin >> picture[y];
    for(int x=0; x<w; x++) {
      if (picture[y][x] != '.') {
        avg_x += x;
        mass++;
      }
    }
  }
  avg_x /= mass;

  double base_min_x;
  for(int x=0; x<w; x++) {
    if (picture[h-1][x] != '.') {
      base_min_x = x;
      break;
    }
  }
  double base_max_x;
  for(int x=w-1; x>0; x--) {
    if (picture[h-1][x] != '.') {
      base_max_x = x;
      break;
    }
  }
  if (avg_x < base_min_x) cout << "left";
  else if (avg_x > base_max_x) cout << "right";
  else cout << "balanced";
}
