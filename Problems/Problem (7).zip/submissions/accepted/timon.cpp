#include <bits/stdc++.h>
using namespace std;

using ll = long long;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int h, w;
	cin >> h >> w;

	int l, r;
	ll sum = 0LL, count = 0LL;
	while (h--) {
		l = 2 * w, r = 0;
		for (int i = 0; i < w; ++i) {
			char c;
			cin >> c;
			if (c == '.') continue;
			l = min(l, 2 * i);
			r = max(r, 2 * i + 2);
			sum += (ll)(2 * i + 1);
			count += 1;
		}
	}

	if (count == 0)
		cout << "balanced" << endl;
	else if (sum < l * count)
		cout << "left" << endl;
	else if (sum <= r * count)
		cout << "balanced" << endl;
	else
		cout << "right" << endl;

	return 0;
}
