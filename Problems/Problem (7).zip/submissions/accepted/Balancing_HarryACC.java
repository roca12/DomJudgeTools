import java.util.List;
import java.util.Scanner;

public class Balancing_HarryACC {

  static double[] enjoyment;
  static List<List<Integer>> connections;

  static double[] maxima;

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    int l = sc.nextInt();
    int w = sc.nextInt();
    Boolean[][] grid = new Boolean[l][w];

    for (int i = 0; i < l; i++) {
      String s = sc.next();
      for (int j = 0; j < w; j++) {
        if (s.charAt(j) != '.') grid[i][j] = true;
        else grid[i][j] = false;
      }
    }

    int minx = -1;
    for (int j = 0; j < w && minx == -1; j++) if (grid[l - 1][j]) minx = j;

    int maxx = -1;
    for (int j = w - 1; j >= 0 && maxx == -1; j--) if (grid[l - 1][j]) maxx = j + 1;

    double totalweight = 0;
    int totalblocks = 0;

    for (int i = 0; i < l; i++)
      for (int j = 0; j < w; j++)
        if (grid[i][j]) {
          totalweight += (j + 0.5d);
          totalblocks++;
        }

    double midx = totalweight / totalblocks;

    if (midx < minx) {
      System.out.println("left");
    } else if (midx > maxx) {
      System.out.println("right");
    } else {
      System.out.println("balanced");
    }
    return;
  }
}
