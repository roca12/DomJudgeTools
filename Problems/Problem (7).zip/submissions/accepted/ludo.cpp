#include<bits/stdc++.h>
using namespace std;
int s, x, h, i, l, r;
int main()
{
	string A;
	cin >> h >> r;
	while (h--) {
		cin >> A;
		i = 0;
		for (char c : A) {
			if (c != '.') x += i, s++;
			i++;
		}
	}
	while (A[l] == '.') l++;
	while (A[r-1] == '.') r--;
	cout << ((2 * x > (2 * r - 1) * s) ? "right" :
			 (2 * x < (2 * l - 1) * s ? "left" : "balanced")) << endl;
}
