#include <array>
#include <iostream>

using namespace std;
constexpr int N = 100;

int main() {
	int R, C;
	cin >> R >> C;
	int left = N + 1, right = -1, sum = 0, count = 0;
	for(int r = 0; r < R; ++r)
		for(int c = 0; c < C; ++c) {
			char x;
			cin >> x;
			if(x != '.') {
				++count;
				sum += c;
				if(r == R - 1) left = min(left, c), right = max(right, c);
			}
		}
	// cerr << "left: " << left << ", right: " << right << endl;
	if(2 * sum < (2 * left - 1) * count)
		cout << "left\n";
	else if(2 * sum > (2 * right + 1) * count)
		cout << "right\n";
	else
		cout << "balanced\n";
	return 0;
}
