#include <bits/stdc++.h>
using namespace std;

string cube = "cube", cylinder = "cylinder";

bool cubeincylin(int edge, int radius) {
	return edge*edge <= radius*radius*2;
}

bool cylincube(int radius, int edge) {
	return radius*2 <= edge;
}

void cubeline(string& res, int& lines, int& idx, int size) {
	res += cube + " " + to_string(size) + "\n";
	lines++;
	idx++;
}

void cyline(string& res, int& lines, int& idx, int size) {
	res += cylinder + " " + to_string(size) + "\n";
	lines++;
	idx++;
}

int main() {
	int n;
	cin >> n;

	vector<int> cubes, cylin;
	while(n--) {
		string type;
		int size;
		cin >> type >> size;
		if(type == cube) {
			cubes.push_back(size);
		} else {
			cylin.push_back(size);
		}
	}

	sort(cubes.begin(), cubes.end());
	sort(cylin.begin(), cylin.end());

	if(cubes.empty()) {
		for(int i : cylin) {
			cout << cylinder << ' ' << i << endl;
		}
		return 0;
	}
	if(cylin.empty()) {
		for(int i : cubes) {
			cout << cube << ' ' << i << endl;
		}
		return 0;
	}

	bool cubemode;
	if(cubeincylin(cubes[0], cylin[0])) {
		cubemode = true;
	} else if(cylincube(cylin[0], cubes[0])) {
		cubemode = false;
	} else {
		cout << "impossible" << endl;
		return 0;
	}

	int cubeidx = 0, cylidx = 0;
	string res = "";
	int lines = 0;
	while(true) {
		if(cubemode) {
			while(cubeincylin(cubes[cubeidx], cylin[cylidx])) {
				cubeline(res, lines, cubeidx, cubes[cubeidx]);
				if(cubeidx == cubes.size()) {
					while(cylidx < cylin.size()) {
						cyline(res, lines, cylidx, cylin[cylidx]);
					}
					goto considered_harmful;
				}
			}
		} else {
			while(cylincube(cylin[cylidx], cubes[cubeidx])) {
				cyline(res, lines, cylidx, cylin[cylidx]);
				if(cylidx == cylin.size()) {
					while(cubeidx < cubes.size()) {
						cubeline(res, lines, cubeidx, cubes[cubeidx]);
					}
					goto considered_harmful;
				}
			}
		}
		cubemode = !cubemode;
	}

considered_harmful:
	if(lines < cubes.size() + cylin.size()) {
		cout << "impossible" << endl;
	} else {
		cout << res;
	}
}
