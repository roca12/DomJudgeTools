#include <bits/stdc++.h>

using namespace std;

const int oo = 0x3f3f3f3f;
const double eps = 1e-9;
const double PI = 2.0 * acos(0.0);


typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;

#define sz(c) int((c).size())
#define all(c) (c).begin(), (c).end()
#define FOR(i,a,b) for (int i = (a); i < (b); i++)
#define FORS(i,a,b,s) for (int i = (a); i < (b); i=i+(s))
#define FORD(i,a,b) for (int i = int(b)-1; i >= (a); i--)
#define FORIT(i,c) for (__typeof__((c).begin()) i = (c).begin(); i != (c).end(); i++)


int main(){
	int N; cin >> N;
	vector<tuple<double,string,int>> toys(N);
	FOR(i,0,N){
		cin >> get<1>(toys[i]) >> get<2>(toys[i]);
		if (get<1>(toys[i])[1] == 'u')
			get<0>(toys[i]) = get<2>(toys[i]) * get<2>(toys[i]);
		else
			get<0>(toys[i]) = PI * get<2>(toys[i]) * get<2>(toys[i]);
		
	}

	sort(all(toys));

	// check impossible
	bool impossible = false;
	FOR(i,0,N-1){
		if (get<1>(toys[i])[1] == 'u' && get<1>(toys[i+1])[1] == 'y'){
			// cube on cylinder
			impossible |= get<2>(toys[i]) * sqrt(2) > 2 * get<2>(toys[i+1]);
		}
		if (get<1>(toys[i])[1] == 'y' && get<1>(toys[i+1])[1] == 'u'){
			// cylinder on cube
			impossible |= get<2>(toys[i+1]) * sqrt(2) < 2 * get<2>(toys[i]);
		}
	}

	if (impossible)
		cout << "impossible" << endl;
	else {
		FOR(i,0,N)
			cout << get<1>(toys[i]) << " " << get<2>(toys[i]) << endl;
	}
}
