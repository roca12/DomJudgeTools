#include <bits/stdc++.h>
using namespace std;
using block = pair<string,int>;

double area(block a) {
	double sqr = pow(a.second, 2);
	if (a.first == "cube") return sqr;
	return M_PI * sqr;
}

int main() {
	int n; cin >> n;
	vector<block> blocks(n);
	for (int i = 0; i < n; i++) {
		cin >> blocks[i].first >> blocks[i].second;
	}
	
	sort(begin(blocks), end(blocks), [&](block a, block b) {
		return area(a) < area(b);
	});
	
	bool ok = true;
	for (int i = 0; i+1 < n; i++) {
		if (blocks[i].first == blocks[i+1].first) continue;

		if (blocks[i].first == "cube") {
			 if (blocks[i].second > blocks[i+1].second * sqrt(2)) ok = false;
		} else {
			 if (blocks[i].second * 2 > blocks[i+1].second) ok = false;
		}
	}
	
	if (!ok) cout << "impossible" << endl;
	else for (auto [t,a]: blocks) cout << t << " " << a << endl;
}
