import java.util.*;

public class Paul {
	static class Brick implements Comparable<Brick> {
		int size;
		boolean isCube;

		Brick(String type, int size) {
			this.size = size;
			this.isCube = type.equals("cube");
		}

		double area() {
			return isCube ? size*size : Math.PI * size*size;
		}

		public int compareTo(Brick b) {
			return Double.compare(area(), b.area());
		}

		boolean fitsInside(Brick b) {
			if (isCube) {
				if (b.isCube) return size <= b.size;
				else return size <= Math.sqrt(2) * b.size;
			} else {
				if (b.isCube) return size <= 0.5 * b.size;
				else return size <= b.size;
			}
		}
	};

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		Brick[] bricks = new Brick[n];
		for (int i = 0; i < n; i++) {
			bricks[i] = new Brick(sc.next(), sc.nextInt());
		}
		Arrays.sort(bricks);
	
		for (int i = 0; i+1 < n; i++) {
			if (!bricks[i].fitsInside(bricks[i+1])) {
				System.out.println("impossible");
				return;
			}
		}

		for (Brick b: bricks) {
			System.out.print(b.isCube ? "cube" : "cylinder");
			System.out.println(" " + b.size);
		}
	}
}
