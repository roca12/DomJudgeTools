#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
void impossible() {cout << "impossible" << endl; exit(0);}
double area(pair<string,int> &p)
{
	if (p.first == "cube") return p.second * p.second;
	return M_PI * p.second * p.second;
}

int main()
{
	int n; cin >> n;
	vector<pair<string,int>> bricks;
	for (int i = 0; i < n; ++i)
	{
		string s; cin >> s;
		int x; cin >> x;
		bricks.emplace_back(s,x);
	}
	sort(bricks.begin(), bricks.end(), [](auto &a, auto &b) {return area(a) < area(b);});
	for (int i = 1; i < n; ++i)
	{
		auto &[t1,x1] = bricks[i-1];
		auto &[t2,x2] = bricks[i];
		if (t1 == t2) continue;
		if (t1 == "cube" && x1*x1 > 2*x2*x2) impossible();
		if (t1 == "cylinder" && 2*x1 > x2) impossible();
	}
	for (auto &[t,x] : bricks) cout << t << " " << x << endl;
}