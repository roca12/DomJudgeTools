import java.util.*;

public class gregor {

    static double eps = 1e-8;
    static double PI = Math.PI;



    static int sig(double d) {
        int a = (d > eps) ? 1 : 0;
        int b = (d < -eps) ? 1 : 0;
        return (a) - (b);
    }

    static class CoordinatePair{
        long first, second;
    }

    static int n, m;
    static CoordinatePair[] b = new CoordinatePair[10500];

    static long[] px = new long[10500];
    static long[] py = new long[10500];
    static long[] pr = new long[10500];

    static class AngularElement implements Comparable<AngularElement>{
        double angle;
        int x;
        long y;

        public AngularElement(double a, int _x, long _y){
            if (sig(a) < 0) throw new IllegalArgumentException();
            angle = a;
            x = _x;
            y = _y;
        }

        @Override
        public int compareTo(AngularElement b) {
            if (angle < b.angle - eps) return -1;
            if (angle > b.angle + eps) return 1;
            if (x < 0 || x >= 2*n ||
                    b.x < 0 || b.x >= 2*n){
                if (x < b.x) return -1;
                if (x > b.x) return 1;
                if (y < b.y) return -1;
                if (y > b.y) return 1;
                return 0;
            } else {
                if (y < b.y - eps) return -1;
            }
            return 0;
        }
    }

    static AngularElement[] an = new AngularElement[40000];


    static double norm(double a){
        while (sig(a) < 0) a += 2*PI;
        while ((2*PI - a) < 0) a -= 2*PI;
        return a;
    }

    /*static void era(multiset<double> & s, double e){
        if (!s.count(e)) return;
        s.erase(s.find(e));
    }*/


    static List<Integer>[] adj = new List[10500]; // input: adj list
    static long[] pre = new long[10500]; // temp: preorder nums
    static long[] lo = new long[10500]; // temp: lowlink nums
    static long curpre; // temp: next preorder num
    static Set<Integer> arti = new TreeSet<>(); // output: articulation nodes
    static Set<Integer>[] blocks = new Set[10500];

    static void dfs(int a) {
        boolean isan = false;
        pre[a] = curpre++;
        lo[a] = pre[a];
        long cc = 0;
        for (int i = 0; i< adj[a].size(); i++) {
            int b = adj[a].get(i);
            if (pre[b] == -1) {
                cc++;
                dfs(b);
                lo[a] = Math.min(lo[a], lo[b]);
                if (pre[a] != 0 && lo[b] >= pre[a])
                    isan = true;
            }
            else
                lo[a] = Math.min(lo[a],pre[b]);
        }
        blocks[a].add(arti.size());
        if (isan || (pre[a] == 0 && cc >= 2)){
            arti.add(a);
            blocks[a].add(arti.size());
        }
    }

    static long articulation(int n) {
        for (int i = 0; i <n; i++) {
            pre[i] = -1;
            blocks[i] = new TreeSet<>();
        }
        curpre = 0;
        arti.clear();
        dfs(n-1); // start in the component in which the initial node lies
        return arti.size();
    }


    static Set<Integer> safe_spots = new TreeSet<>();
    static boolean[] visi = new boolean[10500];

    static void find_safe_spots(int n, int i){
        if (visi[i]) return;
        visi[i] = true;
        if (i != n-1) safe_spots.add(i);

        if (i != n-1 && arti.contains(i)) return;
        for (int j : adj[i]) {
            find_safe_spots(n,j);
        }
    }


    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        m = sc.nextInt();

        for (int i = 0; i < n; i++) {
            b[i] = new CoordinatePair();
            b[i].first = sc.nextInt();
            b[i].second = sc.nextInt();
        }

        for (int i = 0; i < m; i++) {
            px[i] = sc.nextInt();
            py[i] = sc.nextInt();
            pr[i] = sc.nextInt();
        }

        // construct the graph
        for (int i = 0; i < n; i++) {
            adj[i] = new ArrayList<>();
            int idx = 0;
            //compute angles for the other beacons
            for (int j = 0; j < n; j++) if (i != j){
                long ox = b[j].first - b[i].first;
                long oy = b[j].second - b[i].second;
                double ang = Math.atan2(oy,ox);
                while (sig(ang) < 0) ang += 2*PI;
                an[idx++] = new AngularElement(ang , j, ox*ox+oy*oy);
            }


            // peaks
            for (int j = 0; j < m; j++){
                long ox = px[j] - b[i].first;
                long oy = py[j] - b[i].second;
                long d = ox*ox + oy*oy;
                double angle = norm(Math.atan2(oy,ox));
                double rad = Math.asin(pr[j]/Math.sqrt(d));
                double a1 = angle - rad;
                double a2 = angle + rad;
                while (sig(a1) < 0 || sig(a2) < 0) {
                    a1 += 2*PI;
                    a2 += 2*PI;
                }
                d -= pr[j] * pr[j];

                if (sig(a2 - 2*PI) < 0) {
                    an[idx++] = new AngularElement(a1,-2*n-j,d);
                    an[idx++] = new AngularElement(a2,2*n+j,d);
                } else {
                    an[idx++] = new AngularElement(a1,-2*n-j,d);
                    an[idx++] = new AngularElement(2*PI,2*n+j,d);
                    an[idx++] = new AngularElement(0.0,-2*n-j,d);
                    an[idx++] = new AngularElement(a2-2*PI,2*n+j,d);
                }
            }

            AngularElement[] an2 = new AngularElement[idx];
            for (int j = 0; j < idx; j++)
                an2[j] = an[j];

            Arrays.sort(an2);
			
            // build
            SortedMap<Long,Integer> c = new TreeMap<>();
            //System.out.println("\n\n\nROUND " + i);
            for (int j = 0; j < idx; j++){
                //System.out.print(an2[j].angle + " Object "  + an2[j].x + " Distance: " + an2[j].y);
                //if (c.size() == 0) System.out.println(" |C| " + c.size());
                //if (c.size() != 0) System.out.println(" |C| " + c.size() +  "; 0 > " + (an2[j].y - c.firstKey()) + " " + c.firstKey());
                if (an2[j].x <= -2*n) {
                    int v = c.getOrDefault(an2[j].y,0);
                    c.put(an2[j].y,v+1);
                } else if (an2[j].x >= 2*n) {
                    int v = c.get(an2[j].y);
                    if (v == 1)
                        c.remove(an2[j].y);
                    else
                        c.put(an2[j].y,v-1);
                } else if (c.size() == 0 || 0 > an2[j].y - c.firstKey()) {
                    // these are sorted by distance, so take only the first one
                    if (j != 0 && Math.abs(an2[j-1].angle - an2[j].angle) < 1e-6 &&
                            an2[j-1].x >-2*n &&
                            an2[j-1].x < 2*n) continue;
                    int b = an2[j].x;
                    //System.out.println("E " + i + " " + b);
                    //cerr << "E " << i << " " << b << endl;
                    adj[i].add(b);
                }
            }
        }

        
		articulation(n);
        for (int i = 0; i < n; i++) {
            visi[i] = false;
        }
        find_safe_spots(n,n-1);
        boolean first = true;
        for(int ss : safe_spots) {
            if (!first) System.out.print(" ");
            first = false;
            System.out.print(1+ss);
        }
        System.out.println();
    }
}
