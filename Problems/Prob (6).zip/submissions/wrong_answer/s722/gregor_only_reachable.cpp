#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cfloat>
#include <climits>
#include <numeric>
#include <iomanip>

using namespace std;

const int oo = 0x3f3f3f3f;
const double eps = 1e-8;
const double PI = acos(-1.0);


typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<ll> vll;
typedef vector<int> vi;
typedef vector<string> vs;

#define sz(c) int((c).size())
#define all(c) (c).begin(), (c).end()
#define FOR(i,a,b) for (int i = (a); i < (b); i++)
#define FORS(i,a,b,s) for (int i = (a); i < (b); i=i+(s))
#define FORD(i,a,b) for (int i = int(b)-1; i >= (a); i--)
#define FORIT(i,c) for (__typeof__((c).begin()) i = (c).begin(); i != (c).end(); i++)


int sig(double d) {
		return (d > eps) - (d < -eps);
}

int n, m;
pair<ll,ll> b[1050];

ll px[1050];
ll py[1050];
ll pr[1050];


pair<double,pair<ll, ll> > an[4000];

bool doubleCMP(pair<double,pair<ll, ll> > & a, pair<double,pair<ll, ll> > & b){
       if (a.first < b.first - eps) return true;
       if (a.first > b.first + eps) return false;
	   if (a.second < b.second) return true;
		return false;
}

double norm(double a){
		while (sig(a) < 0) a += 2*PI;
		while ((2*PI - a) < 0) a -= 2*PI;
		return a;
}

void era(multiset<double> & s, double e){
		if (!s.count(e)) return;
		s.erase(s.find(e));
}


vll adj[1050]; // input: adj list

set<ll> safe_spots;
ll visi[1050];

void find_safe_spots(int n, int i){
	if (visi[i]) return;
	visi[i] = true;
	if (i != n-1) safe_spots.insert(i);
	FORIT(j, adj[i]) find_safe_spots(n,*j);
}


int main(){
		cin >> n >> m;

		FOR(i,0,n) cin >> b[i].first >> b[i].second;
		FOR(i,0,m) cin >> px[i] >> py[i] >> pr[i];

		// construct the graph
		FOR (i,0,n) {
				int idx = 0;
				//compute angles for the other beacons
				FOR(j,i+1,n) {
						ll ox = b[j].first - b[i].first;
						ll oy = b[j].second - b[i].second;
						an[idx++] = make_pair(norm(atan2(oy,ox)),make_pair(j,ox*ox+oy*oy));
				}


				// peaks
				FOR(j,0,m){
						ll ox = px[j] - b[i].first;
						ll oy = py[j] - b[i].second;
						ll d = ox*ox + oy*oy;
						double angle = norm(atan2(oy,ox));
						double rad = asin(pr[j]/sqrt(d));
						double a1 = angle - rad;
						double a2 = angle + rad;
						while (sig(a1) < 0) a1 += 2*PI, a2 += 2*PI;
						d -= pr[j] * pr[j];

						if (sig(a2 - 2*PI) <= 0) {
								an[idx++] = make_pair(a1,make_pair(-2*n-j,d));
								an[idx++] = make_pair(a2,make_pair(2*n+j,d));
						} else {
								an[idx++] = make_pair(a1,make_pair(-2*n-j,d));
								an[idx++] = make_pair(2*PI,make_pair(2*n+j,d));
								an[idx++] = make_pair(0.0,make_pair(-2*n-j,d));
								an[idx++] = make_pair(a2-2*PI,make_pair(2*n+j,d));
						}
				}

				sort(an,an+idx,doubleCMP);
				// build
				multiset<double> c;
				//cout << endl << endl << "ROUND " << endl;
				FOR(j,0,idx){
						//cout << an[j].first << " " << an[j].second.first << " " << an[j].second.second << endl;
						if (an[j].second.first <= -2*n) c.insert(an[j].second.second);
						else if (an[j].second.first >= 2*n) era(c,an[j].second.second);
						else if (!sz(c) || 0 > an[j].second.second - *c.begin()) {
								// these are sorted by distance, so take only the first one
								if (j && fabs(an[j-1].first - an[j-1].first) < 1e-6 &&
												an[j-1].second.first >-2*n &&
												an[j-1].second.first < 2*n) continue;
								int b = an[j].second.first;
								//cout << "EDGE " << i << " " << b << endl;
								adj[i].push_back(b);
								adj[b].push_back(i);
						}
				}

		}

		FOR(i,0,n) visi[i] = false;
		find_safe_spots(n,n-1);
		FORIT(ss,safe_spots) cout << (ss == safe_spots.begin() ? "" : " ") << 1 + *ss;
		cout << endl;
		return 0;
}
