#include <bits/stdc++.h>
using namespace std;

struct point { long x, y; };

point operator+(point a, point b) { return {a.x+b.x, a.y+b.y}; }
point operator-(point a, point b) { return {a.x-b.x, a.y-b.y}; }
long  operator*(point a, point b) { return a.x*b.x + a.y*b.y; }  // dot product
long  operator%(point a, point b) { return a.x*b.y - a.y*b.x; }  // cross product

long dst(point a, point b){
	return (a-b)*(a-b);
}

// check if point p lies strictly inside the segment a-b
bool on_segment(point p, point a, point b) {
	return (b-a)%(p-a) == 0 && (a-p)*(b-p) < 0;
}

// check if the segment a-b intersects the circle (c,r)
bool intersectSC(point a, point b, point c, long r) {
	if ((c-a)*(b-a) < 0) return (a-c)*(a-c) <= r*r;
	if ((c-b)*(a-b) < 0) return (b-c)*(b-c) <= r*r;
	__int128 area = abs((c-a)%(b-a)), len2 = (b-a)*(b-a);
	return area*area <= len2*r*r;
}

const int N = 12340;
int T = 0, top = -1, s;
int t[N], st[N], safe[N];
vector<int> adj[N];

int dfs(int i, int p = -1) {
	int tmin = t[i] = T++;
	st[++top] = i;
	for (int j: adj[i]) if (j != p) {
		if (t[j] != -1) {
			tmin = min(tmin, t[j]); continue;
		}
		
		int tcur = dfs(j,i);
		if (tcur >= t[i]) {
			while (true) {
				if (i == s) safe[st[top]] = true;
				if (st[top--] == j) break;
			}
		}
		tmin = min(tmin, tcur);
	}
	return tmin;
}

int main() {
	int n, m;
	cin >> n >> m;

	vector<point> node(n);
	for (auto &p: node) cin >> p.x >> p.y;

	vector<point> center(m);
	vector<long> radius(m);
	for (int i = 0; i < m; i++) {
		cin >> center[i].x >> center[i].y >> radius[i];
	}
	
	for (int i = 0; i < n; i++) {
		vector<int> dists;
		for (int k = 0; k < n; k++)
			dists.push_back(dst(node[k],node[i]));

		sort(dists.begin(), dists.end());

		int maxDist = (n > 100) ? dists[100] : dists[n-1];

		vector<int> nearSC;
		vector<int> nearP;

		for (int k = 0; k < m; k++)
			if (dst(node[i],center[k]) - radius[k] < maxDist)
				nearSC.push_back(k);

		for (int k = 0; k < n; k++)
			if (dst(node[k],node[i]) < maxDist)
				nearP.push_back(k);

		for (int j = i+1; j < n; j++) {
			bool ok = true;
			for (int k : nearSC) {
				ok = ok && !intersectSC(node[i], node[j], center[k], radius[k]);
			}
			for (int k : nearP) {
				ok = ok && !on_segment(node[k], node[i], node[j]);
			}
			if (ok) {
				adj[i].push_back(j);
				adj[j].push_back(i);
			}
		}
	}
	
	s = n-1;
	memset(t,-1,sizeof t);
	dfs(s);

	for (int i = 0; i < n; i++) {
		if (i != s && safe[i]) cout << 1 + i << " ";
	}
	cout << endl;
}
