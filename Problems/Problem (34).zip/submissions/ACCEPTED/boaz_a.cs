﻿using System;

namespace ACCEPTED {
    class Program {
        static void Main(string[] args) {
            string input;
            input = Console.ReadLine();
            int n = Int32.Parse(input), a = 0, b = 0, i = n - 1;
            bool turn = false;
            input = Console.ReadLine();
            
            var inputs = input.Split(' ');
            var bla = new int[n];
            for (var j = 0; j < n; j++)
                bla[j] = Int32.Parse(inputs[j]);

            Array.Sort(bla);
            do {
                var s = bla[i];
                if (!turn) a += s;
                else b += s;
                --i;
                turn = !turn;
            } while (i >= 0);
            Console.WriteLine($"{a} {b}");
        }
    }
}
