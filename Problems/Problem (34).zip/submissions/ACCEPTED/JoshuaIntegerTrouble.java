import java.util.*;

/*
Copied Timon's code for this
 */

public class JoshuaIntegerTrouble {
    Scanner s = new Scanner(System.in);

    public static void main(String[] args) {
        (new JoshuaIntegerTrouble()).solve();
    }

    void solve() {
        int N = s.nextInt();
        
        int[] A = new int[N];

        for (int i = 0; i < N; i++) {
            A[i] = s.nextInt();
        }
        
        Arrays.sort(A);
        for (int i = 0; i < A.length / 2; i++) {
            int temp = A[i];
            A[i] = A[A.length - 1 - i];
            A[A.length - 1 - i] = temp;
        }
        
        int[] a = {0, 0};
        for (int i = 0; i < N; ++i) a[i&1] += A[i];

        System.out.println(a[0] + " " + a[1]);
    }
}
