#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <stack>

using namespace std;

int main(){
	int N;
	cin >> N;
	vector<int> ps (N, 0);
	for(int i = 0; i < N; i++){
		cin >> ps[i];
	}
	sort(ps.rbegin(),ps.rend());
	int aans = 0, bans = 0;
	for(int i = 0; i < N; i++){
		if(i % 2 == 0) aans += ps[i];
		else bans += ps[i];
	}
	cout << aans << " " << bans << endl;
	return 0;
}