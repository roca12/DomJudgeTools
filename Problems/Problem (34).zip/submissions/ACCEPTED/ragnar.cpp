#include <algorithm>
#include <array>
#include <iostream>
#include <vector>
using namespace std;
int main() {
	int n;
	cin >> n;
	vector<int> v(n);
	for(auto &x : v) cin >> x;
	sort(v.rbegin(), v.rend());
	array<int, 2> a{{0, 0}};
	for(int i = 0; i < n; ++i) a[i & 1] += v[i];
	cout << a[0] << ' ' << a[1] << '\n';
	return 0;
}
