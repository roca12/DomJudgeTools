#include <bits/stdc++.h>
using namespace std;

int main() {
	int N;
	cin >> N;

	vector<int> A(N, 0LL);
	for (int &a : A) cin >> a;

	int a[2] = {0, 0};
	for (int i = 0; i < N; ++i) a[i&1] += A[i];

	cout << a[0] << ' ' << a[1] << endl;
	return 0;
}
