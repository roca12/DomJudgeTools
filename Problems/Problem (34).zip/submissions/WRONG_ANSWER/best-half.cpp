#include <bits/stdc++.h>
using namespace std;

int main() {
	int N;
	cin >> N;

	vector<int> A(N, 0LL);
	for (int &a : A) cin >> a;
	sort(A.rbegin(), A.rend());

	int alice = 0, bob = 0;
	for (int i = 0; i <= N / 2; ++i) alice += A[i];
	for (int i = N/2+1; i < N; ++i) bob += A[i];

	cout << alice << ' ' << bob << endl;
	return 0;
}
