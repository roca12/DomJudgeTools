#include <bits/stdc++.h>
using namespace std;

//---- copied from Saarland University cheat sheet ---------
bool find_match(int i, const vector<vector<int>>& adj, vector<int>& mr, vector<int>& mc, vector<bool>& seen) {
    for (int j: adj[i]) {
        if (!seen[j]) {
            seen[j] = true;
            if (mc[j] < 0 || find_match(mc[j], adj, mr, mc, seen)) {
                mr[i] = j;
                mc[j] = i;
                return true;
            }
        }
    }
    return false;
}

int max_bipartite_matching(int n, int m, const vector<vector<int>>& adj, vector<int>& mr, vector<int>& mc) {
    mr.assign(n, -1);
    mc.assign(m, -1);
    int count = 0;
    vector<bool> seen;
    for (int i = 0; i < n; i++) {
        seen.assign(m, false);
        if (find_match(i, adj, mr, mc, seen)) ++count;
    }
    return count;
}
//----------------------------------------------------------

typedef pair<int, int> point;
typedef pair<point, point> domino;

point directions[4] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};

point operator+(point a, point b)
{
    return {a.first + b.first, a.second + b.second};
}

int main()
{
    int n;
    cin >> n;

    vector<domino> dominos(n);
    for (auto& d: dominos) cin >> d.first.first >> d.first.second >> d.second.first >> d.second.second;

    map<point, int> point_to_id;
    vector<point> id_to_point[2];
    for (int i = 0; i < n; ++i) {
        for (point p: {dominos[i].first, dominos[i].second}) {
            point_to_id[p] = i;
            id_to_point[(p.first + p.second) % 2].push_back(p);
        }
    }

    vector<vector<int>> adj(n);
    for (int i = 0; i < n; ++i) {
        point p = id_to_point[0][i];
        for (point d: directions) {
            point neighbour = p + d;
            if (point_to_id.count(neighbour)) {
                int j = point_to_id[neighbour];
                if (i != j) adj[i].push_back(j);
            }
        }
    }

    vector<int> mr(n), mc(n);
    if (max_bipartite_matching(n, n, adj, mr, mc) != n) {
        cout << "impossible\n";
        return 0;
    }

    map<point, int> numbering;
    for (int i = 0; i < n; ++i) {
        numbering[id_to_point[0][i]] = i;
        numbering[id_to_point[1][mr[i]]] = i;
    }

    for (auto d: dominos) {
        cout << numbering[d.first] << " " << numbering[d.second] << "\n";
    }
}
