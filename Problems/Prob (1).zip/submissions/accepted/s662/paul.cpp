#include <bits/stdc++.h>
using namespace std;

struct point {
	int x, y;
	bool even() const { return (x+y)%2; }
	bool operator<(const point &p) const {
		return make_pair(x, y) < make_pair(p.x, p.y);
	}
};

struct matching {
	int L, R;
	vector<vector<int>> adj;
	vector<int> matchR, mark;

	matching(int L, int R): L(L), R(R), adj(L), matchR(R,-1) { }

	bool dfs(int i) {
		if (i == -1) return true;
		if (mark[i]) return false;
		mark[i] = true;
		for (int j: adj[i]) if (dfs(matchR[j])) {
			matchR[j] = i;
			return true;
		}
		return false;
	}
	
	int max_match() {
		int res = 0;
		for (int i = 0; i < L; i++) {
			mark.assign(L,false);
			if (dfs(i)) res++;
		}
		return res;
	}
};

int main() {
	int n; cin >> n;
	
	map<point,int> id;
	vector<pair<point,point>> a(n);
	for (int i = 0; i < n; i++) {
		point p, q;
		cin >> p.x >> p.y >> q.x >> q.y;
		a[i] = {p,q};
		id[p] = id[q] = i;
	}
	
	matching M(n,n);

	for (auto [p,i]: id) if (p.even()) {
		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				if (abs(dx)+abs(dy) != 1) continue;
				
				point q = p;
				q.x += dx, q.y += dy;
				
				if (id.count(q) && id[q] != i) {
					M.adj[i].push_back(id[q]);
				}
			}
		}
	}
	
	if (M.max_match() < n) {
		cout << "impossible" << endl;
	} else {
		vector<vector<int>> res(n, vector<int>(2));
		for (int i = 0; i < n; i++) {
			int j = M.matchR[i];

			res[i][ a[i].first.even()] = i;
			res[j][!a[j].first.even()] = i;
		}
		for (auto v: res) cout << v[0] << " " << v[1] << endl;
	}
}
