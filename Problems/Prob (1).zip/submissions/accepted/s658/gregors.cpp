#include <iostream>
#include <vector>
#include <map>
#include <utility>
#include <tuple>
using namespace std;
using Point = std::pair<int,int>;

bool findPath(int i, vector<vector<int>> &g, vector<char> &visited, vector<int> &match)
{
	if (visited[i]) return false;
	visited[i] = true;
	for (int j : g[i])
	{
		if (match[j] == -1 || findPath(match[j], g, visited, match))
		{
			match[i] = j;
			match[j] = i;
			return true;
		}
	}
	return false;
}

tuple<int,vector<int>> maxBipartiteMatching(int numLeft, vector<vector<int>> &g)
{
	vector<char> visited;
	vector<int> match(g.size(),-1);
	int cnt = 0;
	for (int i = 0; i < numLeft; ++i)
	{
		visited.assign(numLeft,false);
		cnt += findPath(i,g,visited,match);
	}
	return tie(cnt,match);
}

int main()
{
	int n; cin >> n;
	map<Point,int> ids;
	vector<Point> points;
	for (int i = 0; i < n; ++i)
	{
		int x1,y1,x2,y2;
		cin >> x1 >> y1 >> x2 >> y2;
		Point p1 {x1,y1}; Point p2 {x2,y2};
		points.push_back(p1); points.push_back(p2);
		ids[p1] = i; ids[p2] = n+i;
		if ((x1 + y1) % 2) swap(ids[p1],ids[p2]);	
	}
	vector<vector<int>> g(2*n);
	for (auto &[p,id] : ids)
	{
		if (id >= n) continue;
		for (int dx = -1; dx <= 1; dx++)
		{
			for (int dy = -1; dy <= 1; dy++)
			{
				Point q {p.first + dx, p.second + dy};
				if (abs(dx) != abs(dy) && ids.count(q) && id != ids[q] - n) 
					g[id].push_back(ids[q]);
			}
		}
	}
	int cnt;
	vector<int> match;
	tie(cnt,match) = maxBipartiteMatching(n,g);
	if (cnt < n)
		cout << "impossible" << endl;
	else
	{
		for (int i = 0; i < points.size(); ++i)
		{
			Point &p = points[i];
			if (ids[p] < n) cout << ids[p];
			else cout << match[ids[p]];
			if (i % 2) cout << endl;
			else cout << " ";
		}
	}
}
