#include <iostream>
#include <vector>
#include <map>
#include <utility>
#include <tuple>
using namespace std;
using Point = std::pair<int,int>;

struct Edge {int to, rev, f, cap;};

void addEdge(vector<vector<Edge>> &g, int s, int t, int cap)
{
	Edge a = {t, (int) g[t].size(), 0, cap};
	Edge b = {s, (int) g[s].size(), 0, 0};
	g[s].push_back(a);
	g[t].push_back(b);
}

int flow_dfs(vector<vector<Edge>> &g, vector<char> &visited, int u, int f, int dest) 
{
	if (u == dest) return f;
	if (visited[u]) return 0;
	visited[u] = true;
	for (Edge &e : g[u]) 
	{
		if (e.f >= e.cap) 
			continue;
		int v = e.to;
		int df = flow_dfs(g, visited, v, min(f, e.cap - e.f), dest);
		if (df > 0) 
		{
			e.f += df;
			g[v][e.rev].f -= df;
			return df;
		}
	}
	return 0;
}

int maxFlow(vector<vector<Edge>> &g, int src, int dest) 
{
	int result = 0;
	int df = 0;
	do 
	{
		vector<char> visited(g.size(), false);
		df = flow_dfs(g, visited, src, numeric_limits<int>::max(), dest);
		result += df;
	} while (df > 0);
	return result;
}


int main()
{
	int n; cin >> n;
	map<Point,int> ids;
	vector<Point> points;
	for (int i = 0; i < n; ++i)
	{
		int x1,y1,x2,y2;
		cin >> x1 >> y1 >> x2 >> y2;
		Point p1 {x1,y1}; Point p2 {x2,y2};
		points.push_back(p1); points.push_back(p2);
		ids[p1] = i; ids[p2] = n+i;
		if ((x1 + y1) % 2) swap(ids[p1],ids[p2]);	
	}
	vector<vector<Edge>> g(2*n+2);
	for (auto &[p,id] : ids)
	{
		if (id >= n) continue;
		for (int dx = -1; dx <= 1; dx++)
		{
			for (int dy = -1; dy <= 1; dy++)
			{
				Point q {p.first + dx, p.second + dy};
				if (abs(dx) != abs(dy) && ids.count(q) && id != ids[q] - n) 
					addEdge(g,id,ids[q],1);
			}
		}
	}
	for (int i = 0; i < n; ++i)
	{
		addEdge(g,2*n,i,1);
		addEdge(g,n+i,2*n+1,1);
	}
	int cnt = maxFlow(g,2*n,2*n+1);
	vector<int> match(2*n,-1);
	for (int i = 0; i < 2*n; ++i) for (Edge &e : g[i]) 
	{
		if (e.to < 2*n && e.f == 1)
		{
			match[i] = e.to;
			match[e.to] = i;
		}
	}
	if (cnt < n)
		cout << "impossible" << endl;
	else
	{
		for (int i = 0; i < points.size(); ++i)
		{
			Point &p = points[i];
			if (ids[p] < n) cout << ids[p];
			else cout << match[ids[p]];
			if (i % 2) cout << endl;
			else cout << " ";
		}
	}
}
