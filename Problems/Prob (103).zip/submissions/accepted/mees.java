import java.util.Scanner;
import java.lang.Math;

public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int k = sc.nextInt();
        double p = sc.nextDouble();

        int num_steps = 100000;

        double[][] v = new double[k+1][num_steps];
        v[k][0] = 1.0;
        for(int i = 0; i < k; i++)
            v[i][0] = 0.0;

        for(int j = 1; j < num_steps; j++) {
            v[k][j] = p * v[k][j-1];
            v[0][j] = (1.0 - p) * v[1][j-1] + v[0][j-1];
            for(int i = 1; i < k; i++) {
                v[i][j] = (1.0 - p) * v[i+1][j-1] + p * v[i][j-1];
            }
        }

        double acc = 0.0;
        for(int j = 1; j < num_steps; j++) {
            acc += (v[0][j] - v[0][j-1]) * Math.pow(v[0][j-1], n-1);
        }
        System.out.format("%.8f\n", 1.0 - n*acc);
	}
}
