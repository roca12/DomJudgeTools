
#include <iostream>
#include <cstdio>
#include <vector>
#include <cmath>

using namespace std;

int main () {
    int n, k;
    double p;
    cin >> n >> k >> p;
int num_steps = max(800, 100 * k);

    // v[i][j] contains the probability that a player has i lives left after j
    // throws. if you keep flipping tails, you stay at 0 lives.
    vector<vector<double>> v(k + 1, vector<double>(num_steps, false));
    v[k][0] = 1.0;
    for(int i = 0; i < k; i++) {
        v[i][0] = 0.0;
    }

    for(int j = 1; j < num_steps; j++) {
        v[k][j] = p * v[k][j-1];
        v[0][j] = (1.0 - p) * v[1][j-1] + v[0][j-1];
        for(int i = 1; i < k; i++) {
            v[i][j] = (1.0 - p) * v[i+1][j-1] + p * v[i][j-1];
        }
    }

    double acc = 0.0;
    for(int j = 1; j < num_steps; j++) {
        // We add the probability that a player takes exactly i steps to die, and others take longer.
        acc += (v[0][j] - v[0][j-1]) * pow(v[0][j-1], n-1);
    }

    printf("%.8lf\n", 1.0 - n*acc);

    return 0;
}
