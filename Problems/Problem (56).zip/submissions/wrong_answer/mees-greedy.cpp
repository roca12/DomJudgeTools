#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

int main() {
    int n, m; cin >> n >> m;

    vector<vector<int>> adj = vector<vector<int>>(n, vector<int>());
    vector<int> num_neighbors(n, 0);

    for(int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a -= 1;
        b -= 1;
        adj[a].push_back(b);
        adj[b].push_back(a);
        num_neighbors[a]++;
        num_neighbors[b]++;
    }
    int MIS_ct = 0;
    vector<bool> out(n, false);
    
    while(true) {
        int least_nbs = 10000;
        int best_vertex = -1;
        for(int i = 0; i < n; i++) {
            if(!out[i] && num_neighbors[i] < least_nbs) {
                least_nbs = num_neighbors[i];
                best_vertex = i;
            }
        }
        if(best_vertex == -1)
            break;
        out[best_vertex] = true;
        for(int nb: adj[best_vertex]) {
            out[nb] = true;
            for(int nbnb : adj[nb])
                num_neighbors[nbnb]--;
        }
        MIS_ct++;
    }

    cout << MIS_ct << endl;

    return 0;
}

