import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Math;

public class ragnar {
	static public class Pair {
		public int f;
		public int t;
		Pair(int a, int b){
			f = a;
			t = b;
		}
	}

	static ArrayList<Integer>[] graph, tree;
	static ArrayList<int[]> edges;
	static boolean[] done;
	static boolean[] off;

	static void dfs1(int u, int p){
		done[u] = true;
		for(Integer v : graph[u]){
			if(v == p) continue;
			if(done[v]) {
				if(u < v) edges.add(new int[]{u, v});
			} else {
				tree[u].add(v);
				tree[v].add(u);
				dfs1(v, u);
			}
		}
	}

	static Pair dfs2(int u, int p){
		int f = 0;
		int t = 1;
		for(Integer v : tree[u]){
			if(v == p) continue;
			Pair r = dfs2(v, u);
			f += r.t;
			t += r.f;
		}
		if(off[u]) t = f;
		else t = Math.max(t, f);
		return new Pair(f, t);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = sc.nextInt();
		int m = sc.nextInt();
		int k = m-n+1;

		done = new boolean[n];
		graph = new ArrayList[n];
		tree = new ArrayList[n];
		edges = new ArrayList<int[]>();
		for(int i = 0; i < n; ++i){
			graph[i] = new ArrayList<Integer>();
			tree[i] = new ArrayList<Integer>();
		}

		for(int i = 0; i < m; ++i){
			int u = sc.nextInt();
			int v = sc.nextInt();

			--u;
			--v;

			graph[u].add(v);
			graph[v].add(u);
		}

		dfs1(0, -1);

		assert(edges.size() == k);

		int ans = 0;
		for(int ma = 0; ma < (1<<k); ++ma){
			off = new boolean[n];
			for(int i = 0; i < n; ++i) off[i] = false;
			for(int i = 0; i < k; ++i) off[edges.get(i)[(ma>>i)&1]] = true;
			ans = Math.max(ans, dfs2(0, -1).t);
		}
		System.out.println(ans);
	}
}


