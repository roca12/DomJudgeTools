#include <stdio.h>

int main() {
    int n, m;
    scanf("%d %d", &n, &m);

    int nnbs[n];
    int adj[n][n];
    int in_set[n];
    for(int i = 0; i < n; i++) {
        in_set[i] = 0;
        nnbs[i] = 0;
    }

    for(int i = 0; i < m; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        a--;
        b--;
        adj[a][nnbs[a]] = b;
        adj[b][nnbs[b]] = a;
        nnbs[a]++;
        nnbs[b]++;
    }

    int cur_set = 0;
    int max_set = 0;
   
    // complete starting at idx. update. then move back to the first place to erase.
    int idx = 0;
    while(idx >= 0) {
        /*for(int i = 0; i < n; i++)
            if(in_set[i])
                printf("1");
            else
                printf("0");
        printf("\n");
        for(int i = 0; i < n; i++) {
            if(idx == i)
                printf("^");
            else
                printf(" ");
        }
        printf("\n");*/
        while(idx < n) {
            // test if you can turn on at idx
            int allowed = 1;
            for(int j = 0; j < nnbs[idx]; j++) {
                if(in_set[adj[idx][j]]) {
                    allowed = 0;
                    break;
                }
            }
            if(allowed) {
                in_set[idx] = 1;
                cur_set++;
                if(cur_set > max_set)
                    max_set = cur_set;
            }
            idx++;
        }
        /*
        for(int i = 0; i < n; i++)
            if(in_set[i])
                printf("1");
            else
                printf("0");
        printf("\n");
        for(int i = 0; i < n; i++) {
            if(idx == i)
                printf("^");
            else
                printf(" ");
        }
        printf("\n");*/
        idx--;
        while(idx >= 0 && !in_set[idx])
            idx--;
        if(idx < 0)
            break;
        in_set[idx] = 0;
        cur_set--;
        idx++;
    }
    printf("%d\n", max_set);
    return 0;
}
