#include <bits/stdc++.h>
using namespace std;

int main() {
	int T, V, n;
	cin >> T >> V >> n;

	int prev = 0, rem = 0;
	while (n--) {
		int cur; cin >> cur;
		rem = V - max(rem-cur+prev,0);
		prev = cur;
	}
	rem = max(rem-T+prev,0);

	cout << rem << endl;
}
