#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ll t, s, n, a, b = 0, lo, hi = 0;
	cin >> t >> s >> n;
	lo = s;
	for (ll i = 0; i < n; ++i) {
		cin >> a;
		lo += min(hi, a - b);
		hi = max(0ll, hi - a + b);
		swap(lo, hi);
		b = a;
	}
	lo += min(hi, t - b);
	hi = max(0ll, hi - t + b);
	cout << hi << endl;
}
