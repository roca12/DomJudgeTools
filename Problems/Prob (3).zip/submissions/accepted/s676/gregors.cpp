#include <iostream>
using namespace std;

int main()
{
	int t,s,n; cin >> t >> s >> n;
	int top = 0;
	int bottom = s;
	int last = 0;
	for (int i = 0; i < n; ++i)
	{
		int a; cin >> a;
		int x = min(a - last, top);
		top -= x; bottom += x;
		swap(top,bottom);
		last = a;
	}
	cout << max(0,top - t + last) << endl;
}
