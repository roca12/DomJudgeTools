import java.util.*;

public class Paul {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt();
		int s = sc.nextInt();
		int n = sc.nextInt();
		
		int[] a = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		
		int i = 0, v = 0;
		for (int j: a) {
			v -= j-i;
			if (v < 0) v = 0;
			v = s-v;
			i = j;
		}
		
		v -= t-i;
		if (v < 0) v = 0;
		System.out.println(v);
	}
}
