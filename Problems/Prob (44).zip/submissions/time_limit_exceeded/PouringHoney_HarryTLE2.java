import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

class Location
{
	int row, col;
	Location(int r, int c)
	{
		row = r; col = c;
	}
}

public class PouringHoney_HarryTLE2 {

	static Boolean[][] visited;	
	static int m,n;
	static int bfs(Location l)
	{
		int size = 0;
		Queue<Location> queue = new LinkedList<Location>();
		queue.add(l);
		visited[l.row][l.col]= true; 
		while(!queue.isEmpty())
		{
			Location cur = queue.remove();
			size++;
			
			if(cur.col + 2 < 2 * n && !visited[cur.row][cur.col + 2])
			{
				queue.add(new Location(cur.row, cur.col + 2));
				visited[cur.row][cur.col + 2] = true;
			}
			
			if(cur.col - 2 >= 0 && !visited[cur.row][cur.col - 2])
			{
				queue.add(new Location(cur.row, cur.col - 2));
				visited[cur.row][cur.col - 2] = true;
			}
			
			for(int a = -1; a <= 1; a += 2)
				for(int b = -1; b <= 1; b += 2)
					{
						int new_row = cur.row + a;
						int new_col = cur.col + b;
						if(new_row >= 0 && new_row < m && new_col >= 0 && new_col < 2 * n && !visited[new_row][new_col])
						{
							queue.add(new Location(new_row, new_col));
							visited[new_row][new_col] = true;
						}
					}
			
		}
		
		return size;
		
	}
	
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int H = sc.nextInt();
		m = sc.nextInt(); n = sc.nextInt();
		
		visited = new Boolean[m][2*n];
		
		for(int i = 0; i < m; i++)
			for(int j = 0; j < 2*n; j++)
				visited[i][j] = false;
		
		for(int i = 0; i < m; i++)
			for(int j = 0; j < n; j++)
				visited[i][2*j + (i%2)] = sc.next().equals("#");	

		ArrayList<Integer> component_sizes = new ArrayList<Integer>(500000);
		
		for(int i = 0; i < m; i++)
			for(int j = 0; j < n; j++)
				if(!visited[i][2*j + i%2])
					component_sizes.add(bfs(new Location(i, 2*j + i%2)));
					
		Collections.sort(component_sizes, Collections.reverseOrder());
		
		int ans = 0;
		while(H > 0)
		{
			ans++;
			H -= component_sizes.get(0);
			component_sizes.remove(0);
		}
		System.out.println(ans);
		
	}

}
