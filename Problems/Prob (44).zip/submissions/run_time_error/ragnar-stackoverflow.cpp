#include <algorithm>
#include <array>
#include <cassert>
#include <iostream>
#include <vector>
using namespace std;
struct P{int r,c;};
array<P, 6> dp{{{-1,-1},{-1,0},{0,-1},{0,1},{1,0},{1,1}}};
P operator+(P l, P r){return {l.r+r.r, l.c+r.c};}
array<array<bool, 1500>, 1000> b; // false=closed, true=open
bool& get(P p){return b[p.r][p.c];}
int dfs(P u, int n, int m){
	if(u.r < 0 || u.c < 0 || u.r >= n || u.c >= n + m/2)
		return 0;
	if(!get(u)) return 0;
	get(u) = false;
	int ans = 1;
	for(auto d : dp)
		ans += dfs(u+d, n, m);
	return ans;
}
int main(){
	for(auto &x:b) x.fill('1');
	int h,n,m; cin >> h >> n >> m;
	char c;
	for(int i = 0; i < n; ++i)
		for(int j = i/2; j < i/2 + m; ++j){
			cin >> c;
			b[i][j] = c=='0';
			}
	vector<int> sizes;
	for(int r = 0; r < n; ++r)
		for(int c = r/2; c < r/2 + m; ++c){
			int x=dfs({r,c}, n, m);
			if(x) sizes.push_back(x);
		}
	sort(sizes.rbegin(), sizes.rend());
	int i = 0;
	do
		if(h<=0) return cout << i << endl, 0;
		else h -= sizes[i++];
	while(i<sizes.size());
	if(h<=0) return cout << i << endl, 0;
	assert(false);
}
