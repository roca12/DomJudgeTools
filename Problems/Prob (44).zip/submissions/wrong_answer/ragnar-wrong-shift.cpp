#include <algorithm>
#include <array>
#include <cassert>
#include <iostream>
#include <stack>
#include <vector>
using namespace std;
struct P{int r,c;};
array<P, 6> dp{{{-1,-1},{-1,0},{0,-1},{0,1},{1,0},{1,1}}};
P operator+(P l, P r){return {l.r+r.r, l.c+r.c};}
array<array<bool, 1500>, 1000> b; // false=closed, true=open
bool& get(P p){return b[p.r][p.c];}
int main(){
	for(auto &x:b) x.fill(false);
	int h,n,m; cin >> h >> n >> m;
	char c;
	for(int i = 0; i < n; ++i)
		for(int j = i/2; j < i/2 + m; ++j)
			cin >> c, b[i][j] = c=='.';
	vector<int> sizes;
	for(int r = 0; r < n; ++r)
		for(int c = r/2; c < r/2 + m; ++c){
			stack<P> s;
			s.push({r,c});
			int a = 0;
			while(!s.empty()){
				auto u = s.top();
				s.pop();
				if(!get(u)) continue;
				get(u) = false;
				++a;
				for(auto d : dp){
					auto v = u+d;
					if(!(v.r < 0 || v.c < 0 || v.r >= 1000 || v.c >= 1500))
						s.push(v);
				}
			}
			if(a) sizes.push_back(a);
		}
	sort(sizes.rbegin(), sizes.rend());
	int i = 0;
	do
		if(h<=0) return cout << i << endl, 0;
		else h -= sizes[i++];
	while(i<sizes.size());
	if(h<=0) return cout << i << endl, 0;
	assert(false);
}
