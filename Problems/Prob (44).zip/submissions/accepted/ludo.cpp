#include<bits/stdc++.h>
using namespace std;

#define REP(i, n) for (auto i = 0; i < n; i++)
#define x first
#define y second
typedef pair<int, int> ii;

const int maxn = 1001;
int H, N, M;
bool g[maxn][maxn];

int main()
{
	cin >> H >> N >> M;
	REP(i, N) REP(j, M) {
		char ch;
		cin >> ch;
		g[i][j] = ch == '.';
	}
	vector<int> cc;
	REP(i, N) REP(j, M) {
		if (!g[i][j]) continue;
		queue<ii> q;
		q.emplace(i, j);
		g[i][j] = false;
		int sz = 0;
		while (!q.empty()) {
			ii cur = q.front(); q.pop();
			sz++;

			if (cur.y > 0 && g[cur.x][cur.y - 1])
				q.emplace(cur.x, cur.y - 1), g[cur.x][cur.y - 1] = false;
			if (cur.y + 1 < M && g[cur.x][cur.y + 1])
				q.emplace(cur.x, cur.y + 1), g[cur.x][cur.y + 1] = false;

			if (cur.x > 0 && g[cur.x - 1][cur.y])
				q.emplace(cur.x - 1, cur.y), g[cur.x - 1][cur.y] = false;
			if (cur.x + 1 < N && g[cur.x + 1][cur.y])
				q.emplace(cur.x + 1, cur.y), g[cur.x + 1][cur.y] = false;

			int dy = cur.x % 2 == 0 ? -1 : 1;
			if (cur.x > 0 && (0 <= cur.y + dy && cur.y + dy < M) && g[cur.x - 1][cur.y + dy])
				q.emplace(cur.x - 1, cur.y + dy), g[cur.x - 1][cur.y + dy] = false;
			if (cur.x + 1 < N && (0 <= cur.y + dy && cur.y + dy < M) && g[cur.x + 1][cur.y + dy])
				q.emplace(cur.x + 1, cur.y + dy), g[cur.x + 1][cur.y + dy] = false;
		}
		cc.push_back(sz);
	}
	sort(cc.begin(), cc.end());
	int ans = 0;
	while (H > 0) H -= cc.back(), ans++, cc.pop_back();
	cout << ans << endl;
	return 0;
}
