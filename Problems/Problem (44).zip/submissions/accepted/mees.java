import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Math;

public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int m = sc.nextInt();
        int k = sc.nextInt();

        boolean[][] grid = new boolean[100][100];

        long start_area = 0;

        for(int i = 0; i < n; i++) {
            String s = sc.next();
            for(int j = 0; j < m; j++) {
                grid[i+40][j+40] = (s.charAt(j) == '#');
                if(grid[i+40][j+40])
                    start_area++;
            }
        }

        int num_brute = 11;

        ArrayList<Long> areas = new ArrayList<Long>();
        areas.add(start_area);

        for(int step = 0; step < num_brute; step++) {
            long next_area = 0;
            boolean[][] new_grid = new boolean[100][100];
            for(int i = 0; i < 100; i++)
                for(int j = 0; j < 100; j++)
                    for(int di = i-1; di <= i+1; di++)
                        if(di >= 0 && di < 100)
                            for(int dj = j-1; dj <= j+1; dj++)
                                if(dj >= 0 && dj < 100)
                                    new_grid[i][j] |= grid[di][dj];

            for(int i = 0; i < 100; i++) {
                for(int j = 0; j < 100; j++) {
                    if(new_grid[i][j])
                        next_area++;
                }
            }

            grid = new_grid;

            areas.add(next_area);
        }
        int s = areas.size();
        long g1 = areas.get(s-1) - areas.get(s-2);
        long g2 = areas.get(s-2) - areas.get(s-3);
        long gg = g1 - g2;

        long cs = g1;

        while(areas.size() <= k) {
            cs += gg;
            areas.add(areas.get(((int)areas.size()) - 1) + cs);
        }

        System.out.println(areas.get(k));
	}
}

