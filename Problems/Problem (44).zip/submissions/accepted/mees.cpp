#include <iostream>
#include <vector> 
using namespace std;

int main() {
    int n, m, k; cin >> n >> m >> k;

    vector<vector<bool>> grid(100, vector<bool>(100, false));

    string s;
    long long start_area = 0;
    for(int i = 0; i < n; i++) {
        cin >> s;
        for(int j = 0; j < m; j++) {
            grid[i+40][j+40] = s[j] == '#';
            if(grid[i+40][j+40])
                start_area++;
        }
    }
    int num_brute = 11;
    vector<long long> areas = {start_area};

    for(int step = 0; step < num_brute; step++) {
        vector<vector<bool>> new_grid(100, vector<bool>(100, false));
        for(int i = 0; i < 100; i++) {
            for(int j = 0; j < 100; j++) {
                for(int di = i - 1; di <= i + 1; di++) {
                    for(int dj = j - 1; dj <= j + 1; dj++) {
                        if(di >= 0 && dj >= 0 && di < 100 && dj < 100) {
                            new_grid[i][j] = new_grid[i][j] | grid[di][dj];
                        }
                    }
                }
            }
        }
        long long area = 0;
        for(int i = 0; i < 100; i++)
            for(int j = 0; j < 100; j++)
                if(new_grid[i][j])
                    area++;
        grid = new_grid;
        areas.push_back(area);
    }
    long long l = areas.size();
    long long g1 = areas[l-1] - areas[l-2];
    long long g2 = areas[l-2] - areas[l-3];
    long long gg = g1 - g2;
    long long cs = g1;
    while(areas.size() <= k) {
        cs += gg;
        areas.push_back(areas[areas.size() - 1] + cs);
    }
    cout << areas[k] << endl;
    return 0;
}
