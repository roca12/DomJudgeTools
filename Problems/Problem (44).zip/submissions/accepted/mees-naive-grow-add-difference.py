# The slowest submission that should be accepted (now also availably in py2).
# Uses a naive algorithm to simulate the grid for the first 40 steps. Then it
# actually does the addition step by step.

n, m, k = [int(x) for x in raw_input().split()]

start = [raw_input() for _ in range(n)]

grid = [[False]*100 for _ in range(100)]

for i in range(n):
    for j in range(m):
        grid[i+40][j+40] = start[i][j] == '#'

num_brute = 40
area = sum([sum([1 for i in range(100) if s[i]]) for s in grid])
areas = [area]

for step in range(num_brute):
    new_grid = [[False]*100 for _ in range(100)]
    for i in range(100):
        for j in range(100):
            for di in range(i-1, i+2):
                if di >= 0 and di < 100:
                    for dj in range(j-1, j+2):
                        if dj >= 0 and dj < 100:
                            new_grid[i][j] |= grid[di][dj]
    grid = new_grid
    area = sum([sum([1 for i in range(100) if s[i]]) for s in grid])
    areas.append(area)

gap1 = areas[-1] - areas[-2]
gap2 = areas[-2] - areas[-3]
gapgap = gap1 - gap2

cur_step = gap1

while len(areas) <= k:
    cur_step += gapgap
    areas.append(areas[-1] + cur_step)

print areas[k]
