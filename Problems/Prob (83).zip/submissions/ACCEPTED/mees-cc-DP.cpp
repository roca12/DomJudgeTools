#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <climits>

using namespace std;

int main() {
    int p, q; cin >> p >> q;
    int d = max(p, q);
    vector<vector<int>> score(d+1, vector<int>(d+1,0));

    for(int tot = 2; tot <= 2*d; tot++) {
        for(int i = 1; i <= d; i++) {
            int j = tot - i;
            if(j <= 0 || j > d)
                continue;
            score[i][j] = -1000;
            for(int k = 1; k <= j; k++) {
                int piece = 0;
                if(i % 2 && k % 2) {
                    if((q-j) % 2)
                        piece = -1;
                    else
                        piece = 1;
                }
                score[i][j] = max(score[i][j], piece - score[j-k][i]);
            }
        }
    }
    cout << score[p][q] << endl;
    return 0;
}
