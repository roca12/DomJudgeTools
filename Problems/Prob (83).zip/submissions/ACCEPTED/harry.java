import java.util.Scanner;

public class harry {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int p = sc.nextInt();
		int q = sc.nextInt();
		if(p % 2 == 0)
		{
			System.out.println("0");
		}
		else 
		{
			if(p % 2 == 1 && q % 2 == 1)
			{
				System.out.println("1");
			}
			else
			{
				assert(p % 2 == 1 && q % 2 == 0);
				if(q > p)
					System.out.println("2");
				else System.out.println("0");
			}
		}
	}
}

