#include <bits/stdc++.h>
using namespace std;

/*
		X X X X X
	ME	 X X X X
	p	X X X X X
		
		q	SISTER
*/

int oh_please_do_provide_the_answer_for_this_input(int p, int q) {
	if ((p&1) && (q&1)) return 1;
	if ((p&1) && !(q&1)) return p < q ? 2 : 0; // *
	if (!(p&1) && (q&1)) return 0;
	if (!(p&1) && !(q&1)) return 0;
	// * We can always start by grabbing +1 relative, but for p > q
	// our opponent can force a -1 on us (since at one point we will
	// be forced to eat all the remaining chocolate).
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int p, q;
	cin >> p >> q;
	cout << oh_please_do_provide_the_answer_for_this_input(p, q) << endl;

	return 0;
}
