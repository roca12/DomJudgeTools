#include <array>
#include <iostream>
using namespace std;
array<array<array<int, 101>, 101>, 2> dp; // topleft == dark?, rows, columns
int main() {
	for(auto &x : dp)
		for(auto &y : x) y.fill(0);
	for(int s = 1; s <= 200; ++s) // r+c
		for(int r = max(0, s - 100), c = s - r; r <= min(100, s - 1); ++r, c = s - r)
			for(int v : {0, 1}) {
				auto &d = dp[v][r][c] = -1000000;
				for(int k = 1; k <= c; ++k) // number of columns I break off
					d = max(d, -dp[(v ^ r ^ k ^ 1) & 1][c - k][r] + (r * k & 1) * (2 * v - 1));
			}
	int p, q;
	cin >> p >> q;
	cout << dp[1][p][q] << endl;
	return 0;
}
