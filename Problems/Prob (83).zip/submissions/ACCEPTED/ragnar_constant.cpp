#include <iostream>
int main() {
	int p, q;
	std::cin >> p >> q;
	return std::cout << (p & 1) * ((q & 1) ? 1 : 2 * (p < q)) << '\n', 0;
}
