﻿using System;

namespace boaz_a {
    class Program {
        static void Main(string[] args) {
            var input = Console.ReadLine();
            var inputs = input.Split(' ');
            var p = int.Parse(inputs[0]);
            var q = int.Parse(inputs[1]);

            if (even(p) && even(q)) { Console.WriteLine("0"); return; }
            if (!even(p) && even(q)) {
                if (p > q) Console.WriteLine("0");
                else Console.WriteLine("2");
                return;
            }
            if (even(p) && !even(q)) { Console.WriteLine("0"); return; }
            if (!even(p) && !even(q)) { Console.WriteLine("1"); return; }

            Console.WriteLine("Blurgh");
        }

        public static bool even(int a) => a % 2 == 0;
    }
}
