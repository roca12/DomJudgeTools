#include <bits/stdc++.h>
using namespace std;

/*
		X X X X X
	ME	 X X X X
	p	X X X X X
		
		q	SISTER
*/

int oh_please_do_provide_the_answer_for_this_input(int p, int q) {
	if ((p&1) && (q&1)) return 1;
	if ((p&1) && !(q&1)) return 2;
	if (!(p&1) && (q&1)) return 0;
	if (!(p&1) && !(q&1)) return 0;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int p, q;
	cin >> p >> q;
	cout << oh_please_do_provide_the_answer_for_this_input(p, q) << endl;

	return 0;
}
