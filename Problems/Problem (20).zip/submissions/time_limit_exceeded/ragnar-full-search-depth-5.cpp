#include <numeric>
#include <algorithm>
#include <cassert>
#include <vector>
#include <optional>
#include <string>
#include <iostream>

using std::cout;
using std::cerr;
using std::endl;

long long gcd(long long a, long long b){
	return b==0 ? a : gcd(b, a%b);
}

struct Fraction {
	long long a,b;
	Fraction(long long a_=0, long long b_=1) : a(a_), b(b_) {
		auto g = gcd(a, b);
		a/=g, b/=g;
		if(b < 0) a = -a, b = -b;
	}
};

Fraction operator+(const Fraction& l, const Fraction& r){ return {l.a*r.b + l.b*r.a, l.b*r.b}; }
Fraction& operator+=(Fraction& l, const Fraction& r){ return l=l+r; }
Fraction operator-(const Fraction& l, const Fraction& r){ return {l.a*r.b - l.b*r.a, l.b*r.b}; }
Fraction operator*(const Fraction& l, const Fraction& r){ return {l.a*r.a, l.b*r.b}; }
Fraction operator/(const Fraction& l, const Fraction& r){ return {l.a*r.b, l.b*r.a}; }
bool operator<(const Fraction& l, const Fraction& r){ return l.a*r.b < l.b*r.a; }
bool operator==(const Fraction& l, const Fraction& r){ return l.a*r.b == l.b*r.a; }
std::ostream& operator<<(std::ostream& o, const Fraction& f) { return o << f.a << " / " << f.b; }

std::vector<Fraction> binom(Fraction f, int k){
	if(k==0) return {{1}};
	std::vector<Fraction> v;
	for(auto x : binom(f, k-1)) v.push_back(x*f), v.push_back(x*(1-f));
	return v;
}

int main(){
	// Given a/b, make c/d
	long long a,b,c,d;
	std::cin >> a >> b >> c >> d;
	b+=a, d+=c;
	for(int k = 1; k < 5; ++k){
		//cerr << "F: " << Fraction{a, b} << endl;
		auto v = binom({a,b}, k);
		//sort(begin(v), end(v));
		assert(v.size() == 1<<k);

		//std::cerr << "K = " << k << endl;
		//for(auto x : v) cerr << x << endl;

		// We want a partition A+B+C s.t. A + (c/d)*B + 0 C = c/d.
		// We try all 3^k subsets where A and C are nonempty.
		for(int A = 0; A < 1<<v.size(); ++A){
			int set = ((1<<v.size())-1)^A;
			int mask = set;
			do {
				int B = mask;
				mask = (mask-1)&set;
				if(A==0 || A&B || (A|B)==(1<<v.size())-1) continue;
				Fraction sA, sB;
				for(int i = 0; i < v.size(); ++i){
					if(A&(1<<i)) sA += v[i];
					if(B&(1<<i)) sB += v[i];
				}
				//cerr << k << ' ' << A << "\t" << B << "\t" << sA << "\t" << sB << "\t" << sA + Fraction{c,d} * sB << endl;
				if(sA + Fraction{c,d} * sB == Fraction{c,d}){
					//std::cerr << "Solution with:\nsA = " << sA << "\nsB = " << sB << "\n";
					//cerr << "A: ";
					//for(int i = 0; i < v.size(); ++i) if(A&(1<<i)) std::cerr << v[i] << "\t";
					//cerr << endl;
					//cerr << "B: ";
					//for(int i = 0; i < v.size(); ++i) if(B&(1<<i)) std::cerr << v[i] << "\t";
					//cerr << endl;


					// Make a binary tree for the given expression
					cout << (1<<k)-1 << endl;
					for(int l = 0; l < (1<<(k-1))-1; ++l){
						cout << 2*l+1 << ' ' << 2*l+2 << endl;
					}
					for(int i = 0; i < (1<<k); ++i){
						if(A&(1<<i))
							cout << -1;
						else if(B&(1<<i))
							cout << 0;
						else
							cout << -2;
						cout << " \n"[i%2];
					}

					return 0;
				}
			} while(mask != set);
		}
	}
	//std::cerr << "NO SOLUTION FOUND!\n";
}
