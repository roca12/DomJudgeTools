#include <bits/stdc++.h>

using namespace std;

int main() {
	long long _a, _b, _c, _d;
	cin >> _c >> _d >> _a >> _b;
	
	unsigned __int128 a, b, c, d;
	a = _a;
	b = _b;
	c = _c;
	d = _d;
	
	unsigned __int128 s = 1;
	int initialIter = 0;
	
	while (s < a+b) {
		initialIter++;
		s *= c+d;
	}
	
	int next_idx = 1;
	
	vector<__int128> cur;
	cur.push_back(s);
	
	vector<__int128> next;
	
	vector<pair<int, int>> splitters;
	
	unsigned __int128 r = s-(a+b);
	
	for (int i=0; i<initialIter; i++) {
		for (unsigned __int128 v : cur) {
			unsigned __int128 vl = (v/(c+d))*c;
			unsigned __int128 vr = (v/(c+d))*d;
			
			int tl, tr;
			if (a >= vl) {
				a -= vl;
				tl = -2;
			} else if (b >= vl) {
				b -= vl;
				tl = -1;
			} else if (r >= vl) {
				r -= vl;
				tl = 0;
			} else {
				tl = next_idx;
				next_idx++;
				next.push_back(vl);
			}
			
			if (a >= vr) {
				a -= vr;
				tr = -2;
			} else if (b >= vr) {
				b -= vr;
				tr = -1;
			} else if (r >= vr) {
				r -= vr;
				tr = 0;
			} else {
				tr = next_idx;
				next_idx++;
				next.push_back(vr);
			}
			
			splitters.push_back({tl, tr});
		}
		
		cur.swap(next);
	}
	
	while (cur.size() != 0) {
		next.clear();
		a *= (c+d);
		b *= (c+d);
		r *= (c+d);
		for (unsigned __int128 v : cur) {
			unsigned __int128 vl, vr;
			int tl, tr;
			
			vl = v*c;
			if (a >= vl) {
				a -= vl;
				tl = -2;
			} else if (b >= vl) {
				b -= vl;
				tl = -1;
			} else if (r >= vl) {
				r -= vl;
				tl = 0;
			} else {
				tl = next_idx;
				next_idx++;
				next.push_back(vl);
			}
			
			vr = v*d;
			if (a >= vr) {
				a -= vr;
				tr = -2;
			} else if (b >= vr) {
				b -= vr;
				tr = -1;
			} else if (r >= vr) {
				c -= vr;
				tr = 0;
			} else {
				tr = next_idx;
				next_idx++;
				next.push_back(vr);
			}
			
			splitters.push_back({tl, tr});
		}
		
		cur.swap(next);
	}
	
	// Output all splitters
	cout << splitters.size() << endl;
	for (auto s : splitters) {
		cout << s.first << " " << s.second << endl;
	}
}
