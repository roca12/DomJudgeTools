#include <stdio.h>

typedef long long ll;
#define prt( x, y )	printf("%lld %lld\n",(x),(y))
void connect( ll a, ll x, ll y ) {
	prt( 3*a+1, 3*a+2 );
	prt( 3*a, x < 0 ? x : 3*x );
	prt( y < 0 ? y : 3*y, 3*a );
}

int main() {
	ll x[3], s, N = 2, B[3] = {0,0,1}, C[6], D;
	scanf( "%lld %lld", x+1, x );
	scanf( "%lld %lld", x+1, x );
	s = x[0]+x[1]-1;
	while( s >>= 1 ) N <<= 1; 
	x[2] = N-x[0]-x[1]; 
	printf( "%d\n", 3*(__builtin_popcountll(x[0])+__builtin_popcountll(x[1])+__builtin_popcountll(x[2])-1) );
	for( ll k = N>>1; B[1] < B[2]; k >>= 1 ) {
		B[0] = B[1];
		B[1] = B[2];
		D = 0;
		for( ll i = 0; i < 3; ++i ) {
			if( x[i] >= k ) {
				x[i] -= k;
				C[D++] = i-2;
			}
		}
		while( D < 2*(B[1]-B[0]) ) C[D++] = B[2]++;
		for( ll i = 0; i < B[1]-B[0]; ++i )
			connect( B[0]+i, C[2*i], C[2*i+1] );
	}
}
