import java.io.*;
import java.util.*;
import java.math.*;

public class Chess {
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

	public Chess() {}

	public static void main(String[] args) throws Exception {
		new Chess().doProblem();
	}

	public static void out(Object o, boolean newline) {
		if (newline) System.out.println(o.toString());
		else System.out.print(o.toString());
		System.out.flush();
	}

	public static void out(Object o) {
		out(o, true);
	}

	public void doProblem() throws Exception {
		solve();
	}

	public void solve() throws Exception {
		graph g = read_graph();
		if (g == null) return;
		spanning_tree(g);
		boolean cycles = detect_cycles(g);
		if (cycles) out("inconsistent");
		else out("consistent");
	}

	ArrayList<edge> cycle_edges;
	HashMap<Integer, vertex> vertices_in_tree;
	HashMap<Integer, edge> edges_in_tree;

	public boolean detect_cycles(graph g) {
    	// For each directed edge: add it to the tree and see whether a cycle is created
		HashMap<Integer, vertex> visited = new HashMap<Integer, vertex>();
		HashMap<Integer, edge> visited_edges = new HashMap<Integer, edge>();
		ArrayDeque stack = new ArrayDeque<vertex>();

		for (edge cycle_edge : cycle_edges) {
			if (!cycle_edge.directed()) continue;

			stack.clear();
			HashMap<Integer, vertex> in_stack = new HashMap<Integer, vertex>();

			stack.add(cycle_edge.v2);
			in_stack.put(cycle_edge.v2.id, cycle_edge.v2);
			visited.put(cycle_edge.v2.id, cycle_edge.v2);

			cycle_edge.v1.edges.add(cycle_edge);
			cycle_edge.v2.edges.add(cycle_edge);
			
			while (stack.size() > 0) {
				vertex v_current = (vertex)stack.remove();
				in_stack.remove(v_current.id);
				for (edge e : v_current.edges) {
					if (visited_edges.containsKey(e.hashCode())) continue;
					vertex to_add = null;
					if (!e.directed()) {
						if (v_current.id != e.v1.id) to_add = e.v1;
						else to_add = e.v2;
					}
					else if (v_current.id != e.v2.id) {
						to_add = e.v2;
					}
					else continue;
					visited_edges.put(e.hashCode(), e);

					if (to_add.id == cycle_edge.v1.id) {
						return true;
					}
					
					if (!visited.containsKey(to_add.id) && !in_stack.containsKey(to_add.id)) {
						stack.add(to_add);
						in_stack.put(to_add.id, to_add);
					}
					visited.put(v_current.id, v_current);
				}
			}
			cycle_edge.v1.edges.remove(cycle_edge);
			cycle_edge.v2.edges.remove(cycle_edge);
		}

		return false;
	}

	public graph read_graph() throws Exception {
		graph gr = new graph();
		String input = in.readLine();
		if (input == null) return null;
		String[] n_m = input.split(" ");
		int n = Integer.parseInt(n_m[0]);
		int m = Integer.parseInt(n_m[1]);
		// int n = readInt();
		// int m = readInt();

		gr.vertices = new vertex[n];
		gr.edges = new edge[m];
		for (int i = 0; i < n; i++)
			gr.vertices[i] = new vertex(i);

		for (int i = 0; i < m; i++) {
			input = in.readLine();
			String[] a_r_b = input.split(" ");
			int a = Integer.parseInt(a_r_b[0]);
			int b = Integer.parseInt(a_r_b[2]);
			char r = a_r_b[1].charAt(0);
			// int a = readInt();
			// char r = readChar();
			// int b = readInt();
			
			vertex v1, v2;
			v1 = gr.vertices[a];
			v2 = gr.vertices[b];

			edge e = new edge(v1, v2, r, i);
			v1.edges.add(e);
			v2.edges.add(e);
			gr.edges[i] = e;
		} 
		return gr;
	}

	public void spanning_tree(graph gr) {
		vertices_in_tree = new HashMap<Integer, vertex>(100000);
		edges_in_tree = new HashMap<Integer, edge>(500000);

		while (gr.vertices.length - vertices_in_tree.size() > 0) {
			ArrayDeque queue = new ArrayDeque<vertex>();
			ArrayDeque directed_queue = new ArrayDeque<vertex>();
			for (vertex v : gr.vertices) { 
				if (!vertices_in_tree.containsKey(v.id)) {
					queue.add(v);
					break;
				}
			}

			while (queue.size() > 0 || directed_queue.size() > 0) {
				if (queue.size() > 0) {
					vertex v = (vertex)queue.remove();
					directed_queue.add(v);

					for (edge e : v.edges) {
						if (!e.directed() && !vertices_in_tree.containsKey(e.v1.id)) {
							edges_in_tree.put(e.hashCode(), e);
							queue.add(e.v1);
							vertices_in_tree.put(e.v1.id, e.v1);
						}
						if (!e.directed() && !vertices_in_tree.containsKey(e.v2.id)) {
							edges_in_tree.put(e.hashCode(), e);
							queue.add(e.v2);
							vertices_in_tree.put(e.v2.id, e.v2);
						}
					}
				}

				if (queue.size() == 0) {
					if (directed_queue.size() > 0) {
						vertex v = (vertex)directed_queue.remove();
						for (edge e : v.edges) {
							if (!vertices_in_tree.containsKey(e.v1.id)) {
								if (e.directed()) {
									edges_in_tree.put(e.hashCode(), e);
									queue.add(e.v1);
									vertices_in_tree.put(e.v1.id, e.v1);
								}
							}
							if (!vertices_in_tree.containsKey(e.v2.id)) {
								if (e.directed()) {
									edges_in_tree.put(e.hashCode(), e);
									queue.add(e.v2);
									vertices_in_tree.put(e.v2.id, e.v2);
								}
							}
						}
					}
				}
			}
		}
		
		cycle_edges = new ArrayList<edge>();
		for (edge e : gr.edges) {
			if (!edges_in_tree.containsKey(e.hashCode())) {
				cycle_edges.add(e);
				e.v1.edges.remove(e);
				e.v2.edges.remove(e);
			}
		}
	}

	public int readInt() throws IOException {
		InputStream in = System.in;
		int ret = 0;
		boolean dig = false;

		for (int c = 0; (c = in.read()) != -1; ) {
			if (c >= '0' && c <= '9') {
				dig = true;
				ret = ret * 10 + c - '0';
			} else if (dig) break;
		}

		return ret;
	}

	public char readChar() throws IOException {
		InputStream in = System.in;
		return (char)in.read();
	}

    public class graph {
        public edge[] edges;
        public vertex[] vertices;

        public graph() {
        }

		public String toString() {
			String result = "";
			for (edge e : this.edges) {
				result += e.toString();
				result += '\n';
			}
			return result;
		}
    }
    
    public class vertex {
        public int id;
        public ArrayList<edge> edges;

        public vertex(int id) {
            this.id = id;
            this.edges = new ArrayList<edge>();
        }
        public boolean Equals(Object o) {
            vertex v = (vertex)o;
            return this.id == v.id;
        }
        public String toString() {
            return "(" + this.id + ")";
        }
        @Override
        public int hashCode() {
            return this.id;
        }
    }

    public class edge {
        public vertex v1, v2;
        public char result;
		public int id;
		public boolean _dir;
        public edge(vertex v1, vertex v2, char result, int id) {
            this.v1 = v1;
            this.v2 = v2;
            this.result = result;
			this.id = id;
			this._dir = this.result == '>'; 
        }
        public boolean directed() {
            return this._dir;
        }
        public boolean connected(vertex v) {
            return this.v1.id == v.id || this.v2.id == v.id;
        }
        public String toString() {
            return "[" + this.v1.id + " " + this.result + " " + this.v2.id + "]";
        }
        public boolean Equals(Object o) {
            edge e = (edge)o;
            return this.v1.id == e.v1.id && this.v2.id == e.v2.id;
        }
        @Override
        public int hashCode() {
			return this.id;
        }
    }
}
