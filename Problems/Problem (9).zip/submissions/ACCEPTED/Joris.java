
import java.io.*;
import java.util.*;

public class Joris
{

    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read input.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert (w.length == 2);
            int n = Integer.parseInt(w[0]);
            int m = Integer.parseInt(w[1]);
            assert (n >= 2 && n <= 50000);
            assert (m >= 1 && m <= 250000);

            ArrayList<ArrayList<Integer>> greaterThan =
                new ArrayList<ArrayList<Integer>>(n);
            ArrayList<ArrayList<Integer>> equalTo =
                new ArrayList<ArrayList<Integer>>(n);
            ArrayList<ArrayList<Integer>> groupNodes =
                new ArrayList<ArrayList<Integer>>(n);
            int[] nodeGroup =
                new int[n];

            ArrayList<HashSet<Integer>> edgeSet =
                new ArrayList<HashSet<Integer>>(n);
            HashSet<Integer> nodeSet = new HashSet();

            for (int i = 0; i < n; i++) {
                greaterThan.add(new ArrayList<Integer>());
                equalTo.add(new ArrayList<Integer>());
                edgeSet.add(new HashSet<Integer>());
            }

            for (int i = 0; i < m; i++) {
                s = ir.readLine();
                w = s.split(" ");
                assert (w.length == 3);
                int k = Integer.parseInt(w[0]);
                int l = Integer.parseInt(w[2]);
                assert (k >= 0 && k < n);
                assert (l >= 0 && l < n);
                assert (k != l);
                assert (!edgeSet.get(k).contains(l));
                assert (!edgeSet.get(l).contains(k));
                edgeSet.get(k).add(l);
                nodeSet.add(k);
                nodeSet.add(l);
                if (w[1].equals("=")) {
                    equalTo.get(k).add(l);
                    equalTo.get(l).add(k);
                } else {
                    assert (w[1].equals(">"));
                    greaterThan.get(k).add(l);
                }
            }

            assert (nodeSet.size() == n);

            // Use explicit stack to avoid recursion limit.
            Stack<int[]> stack = new Stack<int[]>();

            // Build equivalence groups.
            Arrays.fill(nodeGroup, -1);

            // Depth first search.
            for (int i = 0; i < n; i++) {
                if (nodeGroup[i] == -1) {
                    int g = groupNodes.size();
                    groupNodes.add(new ArrayList<Integer>());
                    stack.push(new int[] { i, -1 });
                    while (!stack.empty()) {
                        int[] sf = stack.peek();
                        int k = sf[0];
                        int p = sf[1];
                        if (p == -1) {
                            assert(nodeGroup[k] == -1);
                            nodeGroup[k] = g;
                            groupNodes.get(g).add(k);
                            p++;
                        }
                        ArrayList<Integer> vv = equalTo.get(k);
                        if (p < vv.size()) {
                            sf[1] = p + 1;
                            int kk = vv.get(p);
                            assert (nodeGroup[kk] == -1 ||
                                    nodeGroup[kk] == g);
                            if (nodeGroup[kk] == -1) {
                                stack.push(new int[] { kk, -1 });
                            }
                        } else {
                            stack.pop();
                        }
                    }
                }
            }

            // Search for cycles in greaterThan relation.
            int groupMark[] = new int[groupNodes.size()];
            int groupFlag[] = new int[groupNodes.size()];

            boolean consistent = true;

            // Depth first search.
            for (int i = 0; i < groupNodes.size(); i++) {
                if (groupMark[i] == 0) {
                    stack.push(new int[] { i, -1, -1 });
                    while (!stack.empty()) {
                        int[] sf = stack.peek();
                        int g = sf[0];
                        int p = sf[1];
                        int pp = sf[2];
                        if (p == -1) {
                            assert (groupMark[g] == 0);
                            assert (groupFlag[g] == 0);
                            groupMark[g] = 1;
                            groupFlag[g] = 1;
                            p++;
                            pp = 0;
                        }
                        ArrayList<Integer> vv = groupNodes.get(g);
                        if (p < vv.size()) {
                            int k = vv.get(p);
                            ArrayList<Integer> vvv = greaterThan.get(k);
                            if (pp < vvv.size()) {
                                sf[1] = p;
                                sf[2] = pp + 1;
                                int kk = vvv.get(pp);
                                int gg = nodeGroup[kk];
                                if (groupFlag[gg] == 1) {
                                    stack.clear();
                                    consistent = false;
                                    break;
                                }
                                if (groupMark[gg] == 0) {
                                    stack.push(new int[] { gg, -1, -1 });
                                }
                            } else {
                                sf[1] = p + 1;
                                sf[2] = 0;
                            }
                        } else {
                            groupFlag[g] = 0;
                            stack.pop();
                        }
                    }
                    if (!consistent) {
                        break;
                    }
                }
            }

            // Write output.
            if (consistent) {
                System.out.println("consistent");
            } else {
                System.out.println("inconsistent");
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
