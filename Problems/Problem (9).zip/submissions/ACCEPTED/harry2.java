// Source: https://en.wikipedia.org/wiki/Topological_sorting
// Runtime: O(n log n)

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.TreeSet;

class Graph 
{
	static class Node
	{
		public final TreeSet<Edge> inEdges;
		public final TreeSet<Edge> outEdges;
		public final int id;
		public Node(int c)
		{
			inEdges = new TreeSet<Edge>();
			outEdges = new TreeSet<Edge>();
			id = c;
		}
		public void addEdge(Node node)
		{
			Edge e = new Edge(this.id, node.id);
			outEdges.add(e);
			node.inEdges.add(e);
		}
	}

	static class Edge implements Comparable<Edge>
	{
		public final int from;
		public final int to;
    
		public Edge(int from, int to) 
		{
			this.from = from;
			this.to = to;
		}
		@Override
		public int compareTo(Edge anotherEdge) 
		{
				int a = this.from;
				int b = anotherEdge.from;
				int c = this.to;
				int d = anotherEdge.to;
				return a > b ? 1 : a < b ? -1 : (c < d ? 1 : c > d ? -1 : 0);
		}
		@Override // Necessary to make the TreeSets work.
		public boolean equals(Object obj) 
		{
			Edge e = (Edge)obj;
			return e.from == from && e.to == to;
		}
	}
	  
	public static void main(String[] args) throws IOException 
	{
	   	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
	   	boolean consistent = true;
	   	
	   	String line = reader.readLine();	
		String[] s = line.split(" ");
		int n = Integer.parseInt(s[0]);
		int m = Integer.parseInt(s[1]);
		
		Node[] nodes = new Node[n];
		Node[] nodes_eq = new Node[n];
		for(int i = 0; i < n; i++)
		{
			nodes[i] = new Node(i);
			nodes_eq[i] = new Node(i);
		}
		
		for(int i = 0; i < m; i++)
		{
			line = reader.readLine();
			s = line.split(" ");
			int a = Integer.parseInt(s[0]);
			int b = Integer.parseInt(s[2]);
			char t = s[1].charAt(0);
			
			if(t == '>')				
				nodes[a].addEdge(nodes[b]);
			if(t == '<')				
				nodes[b].addEdge(nodes[a]);
			if(t == '=')
			{
				nodes_eq[a].addEdge(nodes[b]);
				nodes_eq[b].addEdge(nodes[a]);
			}
		}

		
		int group_number = 0;
		int[] groups = new int[n]; // The number of the group for each node.
		Boolean[] visited = new Boolean[n];
		
		for(int i = 0; i < n; i++)
			visited[i] = false;
		
		Queue<Integer> q = new LinkedList<Integer>();
		
		for(int i = 0; i < n; i++)
		{
			if(visited[i]) continue;
			visited[i] = true;
			q.add(i);
			while(!q.isEmpty())
			{
				int a = q.poll();
				visited[a] = true;
				groups[a] = group_number;
				for(Iterator<Edge> it = nodes_eq[a].outEdges.iterator();it.hasNext();)
				{
					Edge e = it.next();
					int b = e.to;
					if(!visited[b])
					{
						visited[b] = true;
						q.add(b);
					}					
				}				
			}
			group_number++;
		}
		
		Node[] grouped_nodes = new Node[group_number];
		for(int i = 0; i < group_number; i++)
			grouped_nodes[i] = new Node(i);
		
		
		
		for(int i = 0; i < n; i++)
		{
			int groupi = groups[i];
			Node node = nodes[i];
			for(Iterator<Edge> it = node.outEdges.iterator();it.hasNext();)
			{
				Edge e = it.next();
				int to = groups[e.to];
				if(groupi == to)
					consistent = false;
				else grouped_nodes[groupi].addEdge(grouped_nodes[to]);
			}
		}
		
		if(consistent)
		{
			// S is the set of all nodes with no incoming edges (which gets updated constantly).
		    HashSet<Node> S = new HashSet<Node>(); 
		    for(Node node : grouped_nodes)
		      if(node.inEdges.size() == 0)
		        S.add(node);
		    
		    while(!S.isEmpty())
		    {
		    	Node node = S.iterator().next();
		    	S.remove(node);
		    	for(Iterator<Edge> it = node.outEdges.iterator();it.hasNext();)
		    	{
		    		Edge e = it.next();
		    		int volgende = e.to;
		    		Node next = grouped_nodes[volgende];
		    		it.remove();
		    		next.inEdges.remove(e);
	
		    		if(next.inEdges.isEmpty())
		    			S.add(next);
		    	}
		    }
		    
		    // Check to see if all edges are removed. If not, we have a consistency problem.
		    
		    for(Node node : grouped_nodes)
		      if(!node.inEdges.isEmpty())
		        consistent = false;
		    
		    if(consistent) System.out.println("consistent");	
		    else System.out.println("inconsistent");
		}
		else System.out.println("inconsistent");
	}
}