#include <iostream>
#include <queue>
#include <set>

using namespace std;

int main() {
  int players, matches, a, b;
  char c;
  cin >> players >> matches;
  vector<vector<int>> beat(players);
  vector<vector<int>> draw(players);

  for(int i = 0; i < matches; i++) {
    cin >> a >> c >> b;
    if(c == '=') {
      draw[a].push_back(b);
      draw[b].push_back(a);
    }
    else {
      beat[a].push_back(b);
    }
  }

  // Collect sets of players who are connected by a series of draws into
  // levels.
  int lv = 0;
  queue<int> q;
  vector<int> level(players,0);
  for(int i = 0; i < players; i++) {
    // If a player has not been sorted into a level...
    if(!level[i]) {
      // We make a new level, and put all players who are equally good
      // in the same level.
      lv++;
      q.push(i);
      while(!q.empty()) {
        int n = q.front(); q.pop();
        if(!level[n]) {
          level[n] = lv;
          for(int j : draw[n]) {
            if(!level[j])
              q.push(j);
          }
        }
      }
    }
  }

  // Make a new graph out of the levels, where a level k beats another
  // level l if a there is a player in level k who beat a player in level
  // l.
  vector<set<int>> lvbeat(lv);
  vector<set<int>> lvlose(lv);
  for(int i = 0; i < players; i++) {
    for(int j : beat[i]) {
      lvbeat[level[i] - 1].insert(level[j] - 1);
      lvlose[level[j] - 1].insert(level[i] - 1);
    }
  }

  // We look for cycles in our new graph, using a topological sort
  // algorithm. 
  vector<int> numstronger(lv);

  for(int i = 0; i < lv; i++) {
    numstronger[i] = lvlose[i].size();
    if(numstronger[i] == 0)
      q.push(i);
  }

  while(!q.empty()) {
    int n = q.front(); q.pop();
    for(int j : lvbeat[n]) {
      numstronger[j]--;
      if(numstronger[j] == 0)
        q.push(j);
    }
  }
  
  // We check if any nodes in our new graph could not be topologically
  // sorted (which shows an inconsistency).
  bool consistent = true;
  for(int j : numstronger) {
    if(j) {
      consistent = false;
      break;
    }
  }
  if(consistent) {
    cout << "consistent" << endl;
  }
  else {
    cout << "inconsistent" << endl;
  }
  return 0;
}
