/*
 * Solution to Chess Rankings.
 *
 * This solution is in principle correct, but uses very deep recursion.
 * It may blow up the default Java stack size depending on settings
 * of the Java VM.
 */

// @EXPECTED_RESULTS@: CORRECT, RUN-ERROR

import java.io.*;
import java.util.*;

public class JorisRecursive
{

    public static class Graph {
        public ArrayList<ArrayList<Integer>> greaterThan;
        public ArrayList<ArrayList<Integer>> equalTo;
        public ArrayList<ArrayList<Integer>> groupNodes;
        public int[] nodeGroup;
        public int groupMark[];
        public int groupFlag[];
    }

    // Build one new equivalence group.
    public static void buildGroup(Graph graph, int g, int i)
    {
        assert (graph.nodeGroup[i] == -1);
        graph.nodeGroup[i] = g;
        graph.groupNodes.get(g).add(i);
        for (int k : graph.equalTo.get(i)) {
            assert (graph.nodeGroup[k] == -1 || graph.nodeGroup[k] == g);
            if (graph.nodeGroup[k] == -1) {
                buildGroup(graph, g, k);
            }
        }
    }

    // DFS search for cycles.
    public static boolean searchCycle(Graph graph, int g)
    {

        assert (graph.groupMark[g] == 0);
        assert (graph.groupFlag[g] == 0);
        graph.groupMark[g] = 1;
        graph.groupFlag[g] = 1;

        for (int p : graph.groupNodes.get(g)) {
            for (int k : graph.greaterThan.get(p)) {
                int gg = graph.nodeGroup[k];
                if (graph.groupFlag[gg] == 1) {
                    return true;
                }
                if (graph.groupMark[gg] == 0) {
                    if (searchCycle(graph, gg)) {
                        return true;
                    }
                }
            }
        }

        graph.groupFlag[g] = 0;
        return false;
    }

    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read N and M from input.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert (w.length == 2);
            int n = Integer.parseInt(w[0]);
            int m = Integer.parseInt(w[1]);
            assert (n >= 2 && n <= 50000);
            assert (m >= 1 && m <= 250000);

            // Allocate data structures.
            Graph graph = new Graph();
            graph.greaterThan   = new ArrayList<ArrayList<Integer>>(n);
            graph.equalTo       = new ArrayList<ArrayList<Integer>>(n);
            graph.groupNodes    = new ArrayList<ArrayList<Integer>>(n);
            graph.nodeGroup     = new int[n];

            // Mark edges to check for duplicate games.
            ArrayList<HashSet<Integer>> edgeSet =
                new ArrayList<HashSet<Integer>>(n);

            // Mark nodes to check that each player has at least one match.
            HashSet<Integer> nodeSet = new HashSet();

            for (int i = 0; i < n; i++) {
                graph.greaterThan.add(new ArrayList<Integer>());
                graph.equalTo.add(new ArrayList<Integer>());
                edgeSet.add(new HashSet<Integer>());
            }

            // Read game reports.
            for (int i = 0; i < m; i++) {
                s = ir.readLine();
                w = s.split(" ");
                assert (w.length == 3);
                int k = Integer.parseInt(w[0]);
                int l = Integer.parseInt(w[2]);
                assert (k >= 0 && k < n);
                assert (l >= 0 && l < n);
                assert (k != l);

                // Check that each pair has at most one match.
                assert (!edgeSet.get(k).contains(l));
                assert (!edgeSet.get(l).contains(k));
                edgeSet.get(k).add(l);

                // Mark players as seen.
                nodeSet.add(k);
                nodeSet.add(l);

                // Add edge to equivalence relation or to greaterThan relation.
                if (w[1].equals("=")) {
                    graph.equalTo.get(k).add(l);
                    graph.equalTo.get(l).add(k);
                } else {
                    assert (w[1].equals(">"));
                    graph.greaterThan.get(k).add(l);
                }
            }

            // Check that each player has at least one match.
            assert (nodeSet.size() == n);

            // Build equivalence groups.
            Arrays.fill(graph.nodeGroup, -1);

            // Depth first search to resolve equivalence groups.
            for (int i = 0; i < n; i++) {
                if (graph.nodeGroup[i] == -1) {
                    int g = graph.groupNodes.size();
                    graph.groupNodes.add(new ArrayList<Integer>());
                    buildGroup(graph, g, i);
                }
            }

            // Search for cycles in greaterThan relation.
            graph.groupMark = new int[graph.groupNodes.size()];
            graph.groupFlag = new int[graph.groupNodes.size()];

            boolean consistent = true;

            // Depth first search to find a cycle.
            for (int i = 0; i < graph.groupNodes.size(); i++) {
                if (graph.groupMark[i] == 0) {
                    if (searchCycle(graph, i)) {
                        consistent = false;
                        break;
                    }
                }
            }

            // Write output.
            if (consistent) {
                System.out.println("consistent");
            } else {
                System.out.println("inconsistent");
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
