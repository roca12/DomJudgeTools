#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>
using namespace std;

// call as `./grammar [test.in test.ans feedbackdir] < team.out`
// very lenient with whitespace; we just use `cin`
const bool case_sensitive = false;

const int ret_AC = 42, ret_WA = 43;

[[noreturn]] void WA(string exp = "", string s = "") {
	if(s.size())
		cout << "Expected " << exp << ", found " << s << endl;
	else if(exp.size())
		cout << exp << endl;
	exit(ret_WA);
}

void eof() {
	string s;
	if(!(cin >> s)) return;
	WA("EOF", s);
}

string read_string() {
	string s;
	if(cin >> s) return s;
	WA("string", "nothing");
}

string &lowercase(string &s) {
	if(!case_sensitive) return s;
	transform(s.begin(), s.end(), s.begin(), ::tolower);
	return s;
}

void test_string(string t) {
	string s = read_string();
	if(lowercase(s) != lowercase(t)) WA(t, s);
}

void is_int(const string &s) {
	auto it = s.begin();
	// [0-9-]
	if(!(*it == '-' || ('0' <= *it && *it <= '9')))
		WA("integer with leading digit or minus sign", s);
	++it;
	for(; it != s.end(); ++it)
		if(!('0' <= *it && *it <= '9')) WA("integer", s);
}

long long read_long_long() {
	string s;
	if(!(cin >> s)) WA("integer", "nothing");
	is_int(s);
	long long val;
	try {
		val = stoll(s);
	} catch(const out_of_range &e) {
		WA("Number " + s + " does not fit in a long long!");
	} catch(const invalid_argument &e) { WA("Parsing " + s + " as long long failed!"); }
	return val;
}

long long read_long_long(long long low, long long high) {
	auto v = read_long_long();
	if(low <= v && v <= high) return v;
	WA("integer between " + to_string(low) + " and " + to_string(high), to_string(v));
}

bool peek(char c) { return (cin >> ws).peek() == char_traits<char>::to_int_type(c); }

int main(int argc, char *args[]) {
	assert(argc >= 3);
	ifstream in(args[1]);
	ifstream ans(args[2]);

	int n;
	in >> n;

	string answer;
	ans >> answer;
	if(answer == "impossible") {
		test_string("impossible");
	} else {
		// now read n integers between 0 and n-1
		for(int i = 0; i < n; ++i) read_long_long(0, n - 1);
	}
	eof();
	return ret_AC;
}
