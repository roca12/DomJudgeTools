#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

// returns 42 if team is correct
// returns 43 if not
// if something crashes or misses, it returns something else
// it ignores whitespace (before and after), but it does not ignore
// too much input
int main(int argc, char const *argv[]) {
    assert(argc >= 3);

    string inputfilename = argv[1];
    string ansfilename = argv[2];
    // string feedbackdir = argv[3]; // not used
    // we need no additional arguments
    // the answer of the team is given via cin

    // the ansfile will contain "impossible" or "possible" or actual numbers
    ifstream ansfile(ansfilename);
    string mode;
    ansfile >> mode;
    assert(ansfile);

    if (mode == "impossible") {
        // here we check whether the team also answered impossible,
        // and nothing more!
        string team_answer;
        cin >> team_answer;

        if (team_answer == "impossible") {
            string end_of_file;
            cin >> end_of_file;
            if (!end_of_file.empty()) {
                clog << "too many words given" << endl;
                return 43;
            }

            return 42;
        } else {
            clog << "team did not give 'impossible'" << endl;
            return 43;
        }
    } else {
        // here we will read the output of the team
        // and simulate the game (if the output is well-formed)
        ifstream inputfile(inputfilename);

        // we will first read the problem size
        int n;
        inputfile >> n;

        clog << "size = " << n << endl;

        // and then the team answer
        vector<int> team_answer(n);
        // we will also check whether it is a permutation
        vector<int> counts(n, 0);
        for (int i = 0; i < n; ++i) {
            cin >> team_answer[i];
            if (!cin) {
                clog << "we could not read enough integers" << endl;
                return 43;
            }

            if (team_answer[i] < 0 || team_answer[i] >= n) {
                clog << "invalid integer: " << team_answer[i] << endl;
                return 43;
            }

            counts[team_answer[i]]++;
            if(counts[team_answer[i]] > 1) {
                clog << "a duplicate number" << endl;
                return 43;
            }
        }

        string end_of_file;
        cin >> end_of_file;
        if (!end_of_file.empty()) {
            clog << "we have too much input" << endl;
            return 43;
        }

        for (auto c : counts) {
            if (c != 1) {
                clog << "one of the numbers did not occur" << endl;
                return 43;
            }
        }

        // at this point, the team answer is a permutation of the participants
        // (and nothing more). so it remains to check that it makes Henk win.

        // Now we read the graph, so that we can simulate
        // adjacency matrix
        vector<vector<bool>> beats(n, vector<bool>(n, false));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                char c;
                inputfile >> c;
                if (c == '1')
                    beats[i][j] = true;
                // skip '0' and 'X'
            }
        }

        // Now we simulate
        int king = team_answer[0];
        for (int i = 1; i < n; ++i) {
            int challenger = team_answer[i];
            if (beats[challenger][king])
                king = challenger;
        }

        if (king == 0) {
            return 42;
        } else {
            clog << "Henk did not win" << endl;
            return 43;
        }

    }
}
