#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

vector<bool> seen;
vector<int> pred;
vector<vector<bool> > winMatrix;
vector<vector<int> > g;

bool bfs(int start, int N)
{
	vector<bool> bfs_seen (N);
	queue<int> Q;
	Q.push(start);
	bool possible = false;
	int cur;
	while(!Q.empty()){
		cur = Q.front();
		Q.pop();
		if(seen[cur]) { possible = true; break; }
		if(bfs_seen[cur]) continue;
		bfs_seen[cur] = true;

		for(int i = 0; i < N; i++){
			if(winMatrix[cur][i] || bfs_seen[i]) continue;
			pred[i] = cur;
			Q.push(i);
		}
	}
	if(!possible) return possible;

	while(cur != start){
		int from = pred[cur];
		g[from].push_back(cur);
		cur = from;
		seen[cur] = true;
	}

	return possible;
}

vector<int> topological_sort() {
    int n = g.size();

    vector<int> in_degs(n);
    for(int u = 0; u < n; u++) for(const int &v : g[u]) {
        in_degs[v]++;
    }

    queue<int> s;
    for(int u = 0; u < n; u++) if(in_degs[u] == 0) s.push(u);

    vector<int> order;
    while(!s.empty()) {
        int u = s.front();
        s.pop();
        order.push_back(u);

        for(const int &v : g[u]) {
            in_degs[v]--;
            if(in_degs[v] == 0) s.push(v);
        }
    }
    return order;
}

int main(){
	int N;
	cin >> N;
	clog << N << endl;
	winMatrix.assign(N, vector<bool> (N, false));
	// cout << "wut" << endl;
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			char c;
			cin >> c;
			if(i == j) {winMatrix[i][j] = false;}
			else {winMatrix[i][j] = (c == '1');}
		}
	}

	seen.assign(N, false);
	pred.assign(N, -1);
	g.assign(N, vector<int> ());
	seen[0] = true;
	bool succes = true;
	for(int i = 1; i < N; i++){
		// cout << i << endl;
		if(seen[i]) continue;
		succes = succes and bfs(i,N);
	}
	if(succes){
		vector<int> ans = topological_sort();
		cout << ans[0];
		for(int i = 1; i < ans.size(); i++){
			cout << " " << ans[i];
		}
		cout << endl;
	} else {
		cout << "impossible" << endl;
	}
	return 0;
}