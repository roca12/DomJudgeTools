#include <bits/stdc++.h>
using namespace std;

using vi = vector<int>;

void dfs(int u, vector<string> &b, vi &s, vi &vis) {
	vis[u] = 1;
	for (int v = 0; v < (int)b.size(); ++v)
		if (b[u][v] == '1' && vis[v] < 0)
			dfs(v, b, s, vis);
	s.push_back(u);
}

int main() {
	int n;
	cin >> n;
	vector<string> b(n);
	for (string &s : b) cin >> s;

	vi s, vis(n, -1);
	dfs(0, b, s, vis);

	if (s.size() < b.size())
		cout << "impossible" << endl;
	else for (int i = 0; i < n; ++i)
		cout << s[i] << " \n"[i+1 == n];
}
