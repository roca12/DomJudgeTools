import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Joshua {
    Scanner s = new Scanner(System.in);
    private String[] beats;
    private boolean[] seen;
    private List<Integer> solution;
    int n;

    public static void main(String[] args) {
        (new Joshua()).solve();
    }

    private void dfs(int i) {
        seen[i] = true;
        for (int j = 0; j < n; j++)
            if (beats[i].charAt(j) == '1' && !seen[j])
                dfs(j);

        solution.add(i);
    }

    void solve() {
        n = Integer.parseInt(s.nextLine());
        beats = new String[n];
        seen = new boolean[n];
        solution = new LinkedList<Integer>();
        for (int i = 0; i < n; i++) {
            beats[i] = s.nextLine();
        }

        dfs(0);

        if (solution.size() == n) {
            Iterator<Integer> it = solution.iterator();

            System.out.print(it.next());
            while (it.hasNext()) {
                System.out.print(' ');
                System.out.print(it.next());
            }
            System.out.println();
        } else {
            System.out.println("impossible");
        }
    }
}