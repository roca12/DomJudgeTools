#include <bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;
	vector<string> b(n);
	for (string &s : b) cin >> s;

	vector<bool> seen(n, false);
	queue<int> work;
	vector<int> solution;

	seen[0] = true;
	work.push(0);
	solution.push_back(0);

	while(!work.empty()){
		int c = work.front();
		work.pop();

		for(int j = 0; j < n; ++j){
			if(b[c][j] == '1' && !seen[j]){
				seen[j] = true;
				work.push(j);
				solution.push_back(j);
			}
		}
	}

	if (solution.size() == n)
		for (int i = n-1; i >= 0; --i)
			cout << solution[i] << " \n"[i == 0];
	else
		cout << "impossible" << endl;
}
