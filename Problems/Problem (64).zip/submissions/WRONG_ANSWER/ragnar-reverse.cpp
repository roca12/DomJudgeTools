#include <array>
#include <cassert>
#include <iostream>
#include <vector>
using namespace std;
array<array<bool, 1000>, 1000> a;
int n;
using I = vector<int>::iterator;
void merge(I lb, I le, I rb, I re, vector<int> &out) {
	if(lb == le || rb == re) {
		out.insert(out.end(), lb, le);
		out.insert(out.end(), rb, re);
		return;
	}
	assert(a[*lb][*rb]);
	auto x = prev(le);
	while(a[*rb][*x]) --x;
	out.insert(out.end(), lb, ++x);
	merge(rb, re, x, le, out);
}

vector<int> dfs(int u, vector<bool> &done) {
	done[u] = true;
	vector<int> path;
	path.push_back(u);
	for(int v = 0; v < n; ++v)
		if(a[u][v] && !done[v]) {
			auto p2 = dfs(v, done);
			vector<int> merged;
			merge(path.begin(), path.end(), p2.begin(), p2.end(), merged);
			swap(path, merged);
		}
	return path;
}

int main() {
	cin >> n;
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j) {
			char c;
			cin >> c;
			a[i][j] = c != '0';
		}
	vector<bool> done(n, false);
	auto path = dfs(0, done);
	if(path.size() == n)
		for(int i = 0; i < n - 1; ++i) cout << path[i] << " \n"[i == n - 1];
	else
		cout << "impossible\n";
	cout << " 0";
	return 0;
}
