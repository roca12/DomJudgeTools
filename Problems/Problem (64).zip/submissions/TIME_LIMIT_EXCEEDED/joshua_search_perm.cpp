#include <algorithm>
#include <cassert>
#include <functional>
#include <iostream>
#include <numeric>
#include <vector>

/* Searches for a valid permutation.
more than exponential complexity.
Why did I even program this ;D?!
*/

using namespace std;

int main()
{
    int n;
    cin >> n;

    // adjacency matrix
    vector<vector<bool>> beats(n, vector<bool>(n, false));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            char c;
            cin >> c;
            if (c == '1')
                beats[i][j] = true;
        }
    }

    vector<int> solution(n);
    iota(solution.begin(), solution.end(), 0); // 0-based

    function<bool()> simulate = [&]() {
        int king = solution[0];

        for (int i = 1; i < n; ++i) {
            int challenger = solution[i];
            if (beats[challenger][king])
                king = challenger;
        }

        return king == 0; // Henk wins
    };

    do {
        if (simulate()) {
            cout << solution[0];
            for (int i = 1; i < n; ++i) {
                cout << ' ' << solution[i];
            }
            cout << endl;
            return 0;
        }
    } while (next_permutation(solution.begin(), solution.end()));

    cout << "impossible" << endl;
}
