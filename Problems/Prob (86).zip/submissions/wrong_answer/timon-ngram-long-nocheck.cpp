#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;
using ll = long long;
using ld = long double;
using ii = pair<ll, ll>;
using vi = vector<ll>;
using vvi = vector<vi>;
using vii = vector<ii>;
using vvii = vector<vii>;

template<class T>
using min_heap = priority_queue<T, vector<T>, greater<T>>;
template<class TIn, class TOut = null_type>
using order_tree = tree<TIn, TOut, less<TIn>, rb_tree_tag,
	tree_order_statistics_node_update>;

constexpr int INF = 2000000010;
constexpr ll LLINF = 9000000000000000010LL;

void add(unordered_map<string, int> &m, const string &s, int c) {
	auto it = m.find(s);
	if (it == m.end())
		m[s] += c;
	else {
		it->second += c;
		if (it->second == 0)
			m.erase(it);
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	
	string S;
	getline(cin, S);

	int ans = 0;
	constexpr int NGRAM = 5;
	unordered_map<string, int> cnt[NGRAM];
	int l = 0, r = (int)S.length()-1;
	while (l < r) {
		int slen = -1;
		for (int len = 1; l + len - 1 < r - len + 1; ++len) {
			bool empt = true;
			for (int nlen = 1; nlen <= min(NGRAM, len); ++nlen) {
				add(cnt[nlen-1], S.substr(l + len - 1 - (nlen - 1), nlen), 1);
				add(cnt[nlen-1], S.substr(r - len + 1, nlen), -1);
				empt = empt && cnt[nlen-1].empty();
			}
			if (empt) {
				slen = len;
				ans += 2;
				break;
			}
		}
		if (slen < 0) break; else l += slen, r -= slen;
	}

	if (l <= r) ++ans;

	cout << ans << endl;
	
	return 0;
}
