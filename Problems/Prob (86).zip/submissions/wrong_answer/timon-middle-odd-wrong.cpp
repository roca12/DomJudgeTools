#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;
using ll = long long;
using ld = long double;
using ii = pair<ll, ll>;
using vi = vector<ll>;
using vvi = vector<vi>;
using vii = vector<ii>;
using vvii = vector<vii>;

template<class T>
using min_heap = priority_queue<T, vector<T>, greater<T>>;
template<class TIn, class TOut = null_type>
using order_tree = tree<TIn, TOut, less<TIn>, rb_tree_tag,
	tree_order_statistics_node_update>;

constexpr int INF = 2000000010;
constexpr ll LLINF = 9000000000000000010LL;

inline ll chr(char c) { return ll(c-'0'); }

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	
	string S;
	getline(cin, S);

	constexpr ll P = 29ULL, M = 1e9+9;
	ll lh = 0ULL, rh = 0ULL, re = 1ULL;
	size_t l = 0, r = S.length()-1;
	int ans = 0;

	while (l < r) {
		lh = (lh * P + chr(S[l++])) % M;
		rh = (rh + re * chr(S[r--])) % M;
		re = (re * P) % M;

		if (lh == rh) {
			ans += 2;
			lh = rh = 0LL;
			re = 1LL;
		}
	}

	if (lh != 0LL || rh != 0LL)
		++ans;

	cout << ans << endl;
	
	return 0;
}
