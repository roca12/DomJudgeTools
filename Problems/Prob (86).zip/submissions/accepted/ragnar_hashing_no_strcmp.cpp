#include <algorithm>
#include <iostream>
int main() {
	std::string s;
	std::cin >> s;
	auto l = s.begin(), r = s.end(), i = l, j = r;
	long long ans = -2, p = 1003, pp = 1, m = 1e9 + 7, L = 0, R = 0;
	for(; i <= j; L = (L + pp * *i++) % m, R = (*--j + p * R) % m, pp = pp * p % m)
		if(L == R) ans += 2, l = i, r = j, L = 0, R = 0, pp = 1;
	return std::cout << ans + (l != r) << "\n", 0;
}
