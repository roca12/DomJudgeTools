#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;

using ll = long long;
using vi = vector<ll>;

constexpr ll P = 29ULL, M = 1e9+9;

inline ll chr(char c) { return ll(c-'0'); }

ll normalized_hash(const vi &pw, const vi &ph, int l, int r) {
	ll h = ph[r];
	if (l > 0)
		h = (h + M - ph[l - 1] * pw[r - l + 1] % M) % M;
	return h;
}

bool equal(const string &S, const vi &pw, const vi &ph,
		int l1, int r1, int l2, int r2) {
	if (l1 > r1 || r1 - l1 != r2 - l2)
		return false;
	if (normalized_hash(pw, ph, l1, r1) != normalized_hash(pw, ph, l2, r2))
		return false;
	for (int i = 0; i <= r1 - l1; ++i)
		if (S[l1 + i] != S[l2 + i])
			return false;
	return true;
}

int solve(const string &S, const vi &pw, const vi &ph, int l, int r) {
	if (l == r) return 1;
	if (l >  r) return 0;

	for (int i = 0; l+i < r-i; ++i)
		if (equal(S, pw, ph, l, l+i, r-i, r))
			return 2 + solve(S, pw, ph, l+i+1, r-i-1);
	return 1;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	
	string S;
	getline(cin, S);
	int N = (int)S.length();

	vi pw(N, 1LL), ph(N, chr(S[0]));
	for (int i = 1; i < N; ++i)
		pw[i] = (P * pw[i - 1]) % M,
		ph[i] = (P * ph[i - 1] + chr(S[i])) % M;

	cout << solve(S, pw, ph, 0, N-1) << endl;

	return 0;
}
