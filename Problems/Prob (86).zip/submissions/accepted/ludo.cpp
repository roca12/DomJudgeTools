#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second
#define pb push_back
#define eb emplace_back
#define rep(i,a,b) for(auto i = (a); i != (b); ++i)
#define REP(i,n) rep(i,0,n)
#define all(v) (v).begin(), (v).end()

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;

const int mod = 1e9 + 7;
string S;

int P = 1e5 + 1;

bool isprime(int N)
{
	for (int i = 2; i  * i <= N; i++) if (N % i == 0) return false;
	return true;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	while (!isprime(P)) P += 2;

	getline(cin, S);

	int ret = 0, i, j;
	ll hl = 0, hr = 0, pr = 1;
	for (i = 0, j = (int) S.size() - 1; i < j; i++, j--) {
		hl = (P * hl + S[i]) % mod;
		hr = (hr + pr * S[j]) % mod;
		pr = (pr * P) % mod;

		if (hl == hr) {
			ret += 2;
			hl = hr = 0;
			pr = 1; // reset
		}
	}
	if (i == j || hl != hr) ret++;

	cout << ret << endl;
	return 0;
}
