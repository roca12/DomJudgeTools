import java.util.ArrayList;
import java.util.Scanner;

public class Palindrome_HarryACC {

	
	
	
	static int a = 100000007;
	static int m = 100000009;
	
	static long pow(long x, long y)
	{
        if (y == 0) return 1;

        long p = pow(x, y / 2) % m;
        p = (p * p) % m;

        if (y % 2 == 0) return p;
        else return (x * p) % m;
	}
	
	
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		int ans = 0;
		
		
		int n = s.length();
		
		long hash = 0, hashrev = 0; int length = 0;
		for(int i = 0; i < n/2; i++)
		{
			hash = (hash + (s.charAt(i) * pow(a, length)) % m) % m;
			hashrev = ((a * hashrev) % m + s.charAt(n - 1 - i)) % m;
			length++;
			
			if(hash == hashrev)
			{
				Boolean match = true;
				for(int j = 0; j < length; j++)
					if(s.charAt(i - length + j + 1) != s.charAt(n - 1 - i + j)) match = false;
				
				if(match)
				{
					ans += 2;
					hash = 0;
					hashrev = 0; 
					length = 0;
				}
			}		
		}
		
		if(n % 2 != 0 || length != 0) ans++;
		
		System.out.println(ans);
		
	}

}
