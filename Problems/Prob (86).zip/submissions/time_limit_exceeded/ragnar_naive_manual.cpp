#include <algorithm>
#include <iostream>
using it             = std::string::iterator;
long long count      = 0;
long long real_count = 0;
bool equal(it l, it i, it j, it r) {
	count += i - l;
	it s = l;
	for(; l != i; ++l, ++j)
		if(*l != *j) {
			real_count += l - s;
			return false;
		}
	return true;
}
int main() {
	std::string s;
	std::cin >> s;
	int ans = -2;
	auto l = s.begin(), r = s.end(), i = l, j = r;
	for(; i <= j; ++i, --j) {
		if(equal(l, i, j, r)) ans += 2, l = i, r = j;
	}
	// std::cerr << count << "\n";
	// std::cerr << real_count << "\n";
	return std::cout << ans + (l != r) << "\n", 0;
}
