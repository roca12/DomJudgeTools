#include <algorithm>
#include <iostream>
#include <vector>
using it        = std::string::iterator;
long long count = 0;
bool equal(it l, it i, it j, it r) {
	count += i - l;
	return std::equal(l, i, j);
}
int main() {
	std::string s;
	std::cin >> s;
	int ans = -2;
	auto l = s.begin(), r = s.end(), i = l, j = r;
	for(; i <= j; ++i, --j) {
		if(equal(l, i, j, r)) ans += 2, l = i, r = j;
	}
	// std::cerr << count << "\n";
	return std::cout << ans + (l != r) << "\n", 0;
}
