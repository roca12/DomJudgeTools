#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;
using ll   = long long;
using ld   = long double;
using ii   = pair<ll, ll>;
using vi   = vector<ll>;
using vvi  = vector<vi>;
using vii  = vector<ii>;
using vvii = vector<vii>;

template <class T>
using min_heap = priority_queue<T, vector<T>, greater<T>>;
template <class TIn, class TOut = null_type>
using order_tree = tree<TIn, TOut, less<TIn>, rb_tree_tag, tree_order_statistics_node_update>;

constexpr int INF  = 2000000010;
constexpr ll LLINF = 9000000000000000010LL;

template <class T>
void add(unordered_map<T, int> &m, const T &s, int c) {
	auto it = m.find(s);
	if(it == m.end())
		m[s] += c;
	else {
		it->second += c;
		if(it->second == 0) m.erase(it);
	}
}

int combine(char c1, char c2) { return int(c1 - '0') + 10 * int(c2 - '0'); }

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	string S;
	getline(cin, S);

	int ans = 0;
	unordered_map<char, int> cnt1;
	unordered_map<int, int> cnt2;
	int l = 0, r = (int)S.length() - 1;
	while(l < r) {
		bool ok = false;
		for(int i = 0; l + i < r - i; ++i) {
			add(cnt1, S[l + i], 1);
			add(cnt1, S[r - i], -1);
			if(i > 0) {
				add(cnt2, combine(S[l + i - 1], S[l + i]), 1);
				add(cnt2, combine(S[r - i], S[r - i + 1]), -1);
			}
			if(cnt1.empty() && cnt2.empty()) {
				bool eq = true;
				for(int j = 0; j <= i && eq; ++j) eq = eq && S[l + j] == S[r - i + j];
				if(eq) {
					l += i + 1;
					r -= i + 1;
					ans += 2;
					ok = true;
					break;
				}
			}
		}
		if(!ok) break;
	}

	if(l <= r) ++ans;

	cout << ans << endl;

	return 0;
}
