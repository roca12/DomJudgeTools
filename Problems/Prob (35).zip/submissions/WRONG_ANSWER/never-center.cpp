// Faulty 'solution' to problem Amsterdam Distance
// By Mees
//
// Expected answer: WRONG ANSWER
// Always goes along a canal.

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <climits>
#include <cmath>

using namespace std;

int main() {
    int M,N,am,an,bm,bn,tmp;
    double r;
    cin >> M >> N >> r >> am >> an >> bm >> bn;

    printf("%.8lf\n",r*abs(bn-an)/N + M_PI*r*min(an,bn)/N*abs(bm-am)/M);
    return 0;
}
