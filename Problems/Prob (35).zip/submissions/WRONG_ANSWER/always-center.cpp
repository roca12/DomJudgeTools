// Faulty 'solution' to problem Amsterdam Distance
// By Mees
//
// Expected answer: WRONG ANSWER
// Always goes through central station.

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <climits>

using namespace std;

int main() {
    int M,N,am,an,bm,bn,tmp;
    double r;
    cin >> M >> N >> r >> am >> an >> bm >> bn;

    printf("%.8lf\n",r*(bn+an)/N);
    return 0;
}
