// Solution to the Amsterdam Distance problem
// By Boas Kluiving
//
// This solution uses a single for loop to iterate over all possible 
// Manhattan paths
//
// EXPECTED RESULT: CORRECT

import java.util.*;
import java.lang.*;

public class Distance {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int m = scanner.nextInt();
        int n = scanner.nextInt();
        double r = scanner.nextDouble();

        int ax = scanner.nextInt();
        int ay = scanner.nextInt();
        int bx = scanner.nextInt();
        int by = scanner.nextInt();
        
        scanner.close();

        double ySegSize = r / n;

        int xDifference = Math.abs(ax - bx);

        double min_distance = 99999999;

        for(int i=0; i<n+1; i++) {
            
            double xSegSize = (Math.PI * (ySegSize * i)) / m;

            double distance = 0;
            distance += xSegSize * xDifference;
            distance += (Math.abs(i - ay) + Math.abs(i - by)) * ySegSize;

            min_distance = Math.min(min_distance, distance);
        }

        System.out.println(min_distance);


    }
}
