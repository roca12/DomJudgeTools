#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
using namespace std;
int main() {
	int m, n;
	long double r, d1, a0, a1, b0, b1;
	cin >> m >> n >> r >> a0 >> b0 >> a1 >> b1;
	d1 = abs(b0 - b1) + M_PIl * min(b0, b1) * abs(a0 - a1) / m;
	cout << setprecision(15) << min(d1, b0 + b1) * r / n << endl;
	return 0;
}
