#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

double pi = acos(-1);

int main(){
	int M, N;
	double R;
	cin >> M >> N >> R;
	int ax, ay, bx, by;
	cin >> ax >> ay >> bx >> by;
	double ans = (1<<30);
	for(int i = 0; i <= min(ay,by); i++){
		double posans = 0;
		posans += (abs(ay - i) / (double) N) * R;
		posans += (abs(by - i) / (double) N) * R;
		posans += (i / (double) N) * R * pi * (abs(ax - bx) / (double) M);
		ans = min(ans,posans);
	}
	cout << fixed << setprecision(8) << ans << endl;

	return 0;
}