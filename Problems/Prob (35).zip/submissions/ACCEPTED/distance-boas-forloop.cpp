// Solution to the Amsterdam Distance problem
// By Boas Kluiving
//
// This solution uses a single for loop to iterate over all possible 
// Manhattan paths
//
// EXPECTED RESULT: CORRECT

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
using namespace std;

int main() {
    int m, n, ax, ay, bx, by;
    double r;

    cin >> m >> n >> r;
    cin >> ax >> ay >> bx >> by;

    double ySegSize = r / n;

    int xDifference = abs(ax - bx);

    double min_distance = 99999999;

    for(int i=0; i<n+1; i++) {
        
        double xSegSize = (M_PI * (ySegSize * i)) / m;

        double distance = 0;
        distance += xSegSize * xDifference;
        distance += (abs(i - ay) + abs(i - by)) * ySegSize;

        min_distance = min(min_distance, distance);
    }

    cout << fixed << setprecision(8) << min_distance << endl;

    return 0;
}
