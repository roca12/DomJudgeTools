// Solution of Raymond van Bommel
// Problem: Amsterdam distance

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int ax, ay, bx, by;
double R, M, N;

int main () {
	cin >> M >> N >> R >> ax >> ay >> bx >> by;
	double pi = atan(1)*4;
	double opt1 = (ay + by) * R / N;
	double opt2 = (ay + by - 2*min(ay, by)) * R / N + pi*(abs(ax-bx) / M)* (R*min(ay,by) / N);
	cout << fixed << setprecision(6) << min(opt1, opt2) << '\n';
	return 0;
}
