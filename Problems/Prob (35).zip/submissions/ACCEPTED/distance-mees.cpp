// Solution to problem Amsterdam Distance
// By Mees
//
// Expected answer: ACCEPTED

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <climits>
#include <cmath>

using namespace std;

int main() {
    int M,N,am,an,bm,bn,tmp;
    double r;
    cin >> M >> N >> r >> am >> an >> bm >> bn;

    // For simplicity, assume that point a is further from the center and further
    // west than point b.
    if(am > bm) {
        tmp = am;
        am = bm;
        bm = tmp;
    }
    if(an > bn) {
        tmp = an;
        an = bn;
        bn = tmp;
    }

    // Either walk straight to the ring of point n, then walk to n via the that ring;
    // or walk straight to the city center, then walk straight to n. One of these is 
    // always optimal.
    if(M_PI*(bm - am) < 2.0*M) {
        printf("%.8lf\n",r*(bn-an)/N + M_PI*r*an/N*(bm-am)/M);
    }
    else {
        printf("%.8lf\n",r*(bn+an)/N);
    }
    return 0;
}
