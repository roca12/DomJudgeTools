using System;

namespace ACCEPTED {
    class Program {
        static void Main(string[] args) {
			var input = Console.ReadLine();
			var inputs = input.Split(' ');
			int m = int.Parse(inputs[0]), n = int.Parse(inputs[1]);
			double r = double.Parse(inputs[2]);

			input = Console.ReadLine();
			inputs = input.Split(' ');
			int ax = int.Parse(inputs[0]), ay = int.Parse(inputs[1]);
			int bx = int.Parse(inputs[2]), by = int.Parse(inputs[3]);
			
			double y = r / n;
			int dx = Math.Abs(ax - bx);
			var md = double.MaxValue;

			for (var i = 0; i < n + 1; i++) {
				double x = (Math.PI * (y * i)) / m;
				var d = 0d;

				d += x * dx;
				d += (Math.Abs(i - ay) + Math.Abs(i - by)) * y;

				md = Math.Min(md, d);
			}

			Console.WriteLine($"{md}");
		}
	}
}
