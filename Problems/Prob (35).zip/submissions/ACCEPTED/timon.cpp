#include <bits/stdc++.h>
using namespace std;

int main() {
	int M, N, ax, bx, ay, by;
	double R;
	cin >> M >> N >> R >> ax >> ay >> bx >> by;

	double ans = 1e300;
	for (int h = 0; h <= min(ay, by); ++h)
		ans = min(ans, (ay + by - 2 * h) / double(N)
			+ abs(ax - bx) / double(M) * h / double(N) * acos(-1));

	printf("%.10lf\n", ans * R);
}
