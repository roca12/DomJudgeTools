#include "validation.h"

int main(int argc, char **argv) {
	std::ifstream in(argv[1]);
	OutputValidator v(argc, argv);

	int input;
	in >> input;

	if(input % 2 == 0){
		v.test_string("Alice");
		v.newline();
		v.read_long_long(1, input-1);
		v.newline();
	} else {
		v.test_string("Bob");
		v.newline();
	}
}
