#include<bits/stdc++.h>
using namespace std;
int main() {
	int m;
	cin >> m;
	if (m %  2 == 0) {
		cout << "Alice" << endl << m << endl;
	} else {
		cout << "Bob" << endl;
	}
}
