print(["Alice 1", "Bob"][input()%2])
