import java.util.Scanner;

public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        if(m % 2 == 0) {
            System.out.println("Alice");
            System.out.println("1");
        }
        else {
            System.out.println("Bob");
        }
	}
}
