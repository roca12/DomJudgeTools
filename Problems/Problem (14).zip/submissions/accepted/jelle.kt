fun main() {
    println(if(readLine()!!.toInt() % 2 == 0) "Alice 1" else "Bob")
}