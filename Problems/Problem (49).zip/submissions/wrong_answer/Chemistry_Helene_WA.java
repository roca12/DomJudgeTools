import java.util.Scanner;

public class Chemistry_Helene_WA {

	public static int[] readMolecule(String mol) {
		int[] count = new int[26];
		int i = 0;
		while (i < mol.length()){
			char c = mol.charAt(i++);
			if (i >= mol.length() || !Character.isDigit(mol.charAt(i))) {
				count[c-'A'] += 1;
			} else {
				int j = i;
				while (j < mol.length() && Character.isDigit(mol.charAt(j)))
					j++;
				count[c-'A'] += Integer.parseInt(mol.substring(i,j));
				i = j;
			}
		}
		return count;
	}
	public static void main(String[] args){
		// read file
		Scanner reader = new Scanner(System.in);
		int[] input = readMolecule(reader.next());
		int multiplicator = reader.nextInt();
		int[] output = readMolecule(reader.next());
		reader.close();
		
		// compute min of max number proportions
		int res = Integer.MAX_VALUE;
		for(int j = 0; j < 26; j++) {
			if (output[j] != 0)
				res = Math.min(res,  (input[j] / output[j]) * multiplicator);
		}

		// output number molecules
		System.out.println(res);
	}


}
