#include <iostream>
#include <map>
#include <string>

using namespace std;

map<char, int> get_atoms(string s) {
    map<char, int> atoms;
    int i = 0;
    while(i < s.length()) {
        char atom = s[i];
        i++;

        int am, j = 0;
        while(i + j < s.length() && s[i+j] >= '0' && s[i+j] <= '9')
            j++;
        if(j == 0)
            am = 1;
        else
            am = stoi(s.substr(i, j));

        if(atoms.find(atom) != atoms.end())
            atoms[atom] += am;
        else
            atoms[atom] = am;

        i += j;
    }
    return atoms;
}

int main() {
    string source, target; 
    int amount;
    cin >> source >> amount >> target;
    auto source_atoms = get_atoms(source);
    auto target_atoms = get_atoms(target);

    int best = 2000000000;
    for(auto p : target_atoms) {
        char atom = p.first;
        if(source_atoms.find(atom) == source_atoms.end()) {
            best = 0;
            break;
        }
        best = min(best, (source_atoms[atom]*amount)/target_atoms[atom]);
    }

    cout << best << endl;
    return 0;
}
