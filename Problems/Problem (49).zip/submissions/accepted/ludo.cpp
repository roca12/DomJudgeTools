#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second
#define pb push_back
#define eb emplace_back
#define rep(i,a,b) for(auto i = (a); i != (b); ++i)
#define REP(i,n) rep(i,0,n)
#define all(v) (v).begin(), (v).end()

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;

map<char, int> countString(const string &S)
{
	char curVal = '\0';
	int curNum = 0;
	map<char, int> ret;

	assert(S[0] < '0' || S[0] > '9');
	for (char ch : S) {
		if ('0' <= ch && ch <= '9') {
			curNum = curNum * 10 + (ch - '0');
		} else {
			if (curVal == '\0' && curNum == 0) {
				curVal = ch;
				continue;
			}
			
			// if we could have e.g. CH2 possibilities:
			if (curNum == 0) curNum++;

			// wrap up last character
			ret[curVal] += curNum;
			curNum = 0;
			curVal = ch;
		}
	}
	if (curNum == 0) curNum++;
	ret[curVal] += curNum;
	return ret;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	int n;
	string S, T;
	cin >> S >> n >> T;

	map<char, int> cs = countString(S), ct = countString(T);
	int ret = 1e9;
	for (auto it : ct) {
		auto it2 = cs.find(it.x);
		if (it2 == cs.end()) {
			ret = 0;
			continue;
		}
		int weHave = it2->y * n;
		ret = min(ret, weHave / it.y); // floor
	}
	cout << ret << endl;
 	return 0;
}
