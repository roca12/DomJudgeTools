#include <iostream>
#include <array>
#include <sstream>
using namespace std;

bool is_char(char c){ return 'A' <= c && c <= 'Z'; }
array<int, 26> read(){
	array<int, 26> a;
	a.fill(0);
	char c;
	cin >> ws;
	cin >> noskipws;
	while(cin >> c){
		if(c == ' ' || c == '\n') break;
		int k = 0;
		cin >> k;
		if(k == 0) k = 1, cin.clear(); // Clear the failbit if nothing was read.
		a[c-'A'] += k;
	}
	cin >> skipws;
	return a;
}

int main(){
	auto m1 = read();
	int n;
	cin >> n;
	auto m2 = read();
	int m = 1e9;
	for(int i = 0; i < 26; ++i)
		if(m2[i] != 0)
			m = min(m, n*m1[i] / m2[i]);
	cout << m << '\n';
	return 0;
}
