#define _GLIBCXX_DEBUG
#include <iostream>
#include <array>
using namespace std;

bool is_char(char c){ return 'A' <= c && c <= 'Z'; }
array<int, 26> read(){
	string s; cin >> s;
	array<int, 26> a;
	a.fill(0);
	for(int i = 0; i < s.size();){
		int j = i+1;
		while(j < s.size() && !is_char(s[j]))
			++j;
		if(j == i+1)
			++a[s[i] - 'A'];
		else
			a[s[i] - 'A'] += stoi(string(s.begin()+i+1, s.begin()+j));
		i = j;
	}
	return a;
}

int main(){
	auto m1 = read();
	int n;
	cin >> n;
	auto m2 = read();
	int m = 1e9;
	for(int i = 0; i < 26; ++i)
		if(m2[i] != 0)
			m = min(m, n*m1[i] / m2[i]);
	cout << m << '\n';
	return 0;
}
