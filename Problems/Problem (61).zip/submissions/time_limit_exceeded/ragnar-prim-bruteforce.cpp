#include <bits/stdc++.h>
using namespace std;
struct E {
	int u, v, weight;
};
int main() {
	int n, k, count = 0;
	cin >> n >> k;
	vector<string> dna(n);
	for(auto &x : dna) cin >> x;
	vector<bool> done(n, false);
	done[0] = true;
	vector<E> ans;
	for(int i = 0; i < n - 1; ++i) {
		vector<int> left;
		left.reserve(n - i - 1);
		for(int u = 0; u < n; ++u)
			if(!done[u]) left.push_back(u);
		E e{0, 0, numeric_limits<int>::max()};
		for(int u = 0; u < n; ++u)
			if(done[u])
				for(auto v : left) {
					int d = 0;
					for(int i = 0; i < k; ++i) d += dna[u][i] != dna[v][i];
					if(d < e.weight) e = {u, v, d};
				}
		done[e.v] = true;
		ans.push_back(e);
	}
	cout << accumulate(ans.begin(), ans.end(), 0, [](int w, E e) { return w + e.weight; }) << '\n';
	for(auto e : ans) cout << e.u << ' ' << e.v << '\n';
	return 0;
}
