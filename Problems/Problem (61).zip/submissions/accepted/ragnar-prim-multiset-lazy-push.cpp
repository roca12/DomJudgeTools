#include <bits/stdc++.h>
using namespace std;
struct E { int u, v, weight; };
bool operator<(const E& l, const E& r){ return l.weight < r.weight; }
int main() {
	int n, k, count = 0;
	cin >> n >> k;
	vector<string> dna(n);
	for(auto &x : dna) cin >> x;
	vector<bool> done(n, false);
	multiset<E> q;
	vector<E> ans;
	vector<int> best(n, numeric_limits<int>::max());
	q.insert({-1,0,0});
	while(true){
		const auto &e = *q.begin();
		int u = e.v;
		if(done[u]){ q.erase(q.begin()); continue; }
		if(e.u >= 0) ans.push_back(e);
		if(++count == n) break;
		q.erase(q.begin());
		done[u] = true;
		for(int v = 0; v < n; ++v)
			if(!done[v]){
				int d = 0;
				for(int i = 0; i < k; ++i) d += dna[u][i] != dna[v][i];
				if(d < best[v]) q.insert({u, v, best[v] = d});
			}
	}
	cout << accumulate(ans.begin(), ans.end(), 0, [](int w, E e){return w+e.weight;}) << '\n';
	for(auto e : ans)
		cout << e.u << ' ' << e.v << '\n';
	return 0;
}
