#include <bits/stdc++.h>
using namespace std;
struct E { int u, v, weight; };
bool operator<(const E &l, const E &r) { return l.weight < r.weight; }
int main() {
	int n, k;
	cin >> n >> k;
	vector<string> dna(n);
	for(auto &x : dna) cin >> x;
	vector<E> edges, ans;
	ans.reserve(n-1);
	edges.reserve(n*(n-1)/2);
	for(int i = 0; i < n; ++i)
		for(int j = i+1; j < n; ++j) {
			edges.push_back({i, j, 0});
			for(int l = 0; l < k; ++l) edges.back().weight += dna[i][l] != dna[j][l];
		}
	sort(edges.begin(), edges.end());
	vector<int> c(n);
	iota(c.begin(), c.end(), 0);
	for(auto &e : edges) {
		if(c[e.u] != c[e.v]) {
			replace(c.begin(), c.end(), int(c[e.v]), c[e.u]);
			ans.push_back(e);
			if(ans.size() == n - 1) break;
		}
	}
	cout << accumulate(ans.begin(), ans.end(), 0, [](int w, E e){return w+e.weight;}) << '\n';
	for(auto e : ans)
		cout << e.u << ' ' << e.v << '\n';
	return 0;
}
