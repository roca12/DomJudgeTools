import java.util.Scanner;
import java.util.Arrays;

public class Evolution_Helene_unionfind {

	public static class Edge {
		public int vertex1, vertex2, weight;
		public Edge(int v1, int v2, String s1, String s2) {
			this.vertex1 = v1;
			this.vertex2 = v2;
			this.weight = 0;
			for (int i = s1.length()-1; i >= 0; i--){
				if (s1.charAt(i) != s2.charAt(i))
					this.weight += 1;
			}
		}
		public static int compareWeight(Edge e1, Edge e2){
			return e1.weight - e2.weight;
		}
		public static int compareVertex(Edge e1, Edge e2){
			if (e1.vertex1 != e2.vertex2)
				return e1.vertex1 - e2.vertex1;
			else 
				return e1.vertex2 - e2.vertex2;
		}
	}
	
	public static class UF {
		private int[] id;
		public UF(int n) {
			id = new int[n];
			for (int i = 0; i < n; i++)
				id[i] = i;
		}
		public boolean connectIfNot(int p, int q){
			int pid = id[p];
			int qid = id[q];
			if (pid != qid){
				for(int i= 0; i<id.length; i++){
					if(id[i] == pid) 
						id[i]=qid;
				}
				return true;
			} else 
				return false;	
		}
	}


	public static void main(String[] args){
		// read file
		Scanner reader = new Scanner(System.in);
		int n = reader.nextInt();
		int k = reader.nextInt();
		String[] vertex = new String[n];
		for(int i = 0; i < n; i++){
			vertex[i] = reader.next("[a-zA-Z]+");
		}
		reader.close();
		
		// create edges
		Edge[] edges = new Edge[n*(n-1)/2];
		int idx = 0;
		for(int i = 0; i < n; i++){
			for (int j = i + 1; j < n; j++){
				edges[idx] = new Edge(i,j,vertex[i],vertex[j]);
				idx += 1;
			}
		}

		// sorting following the hash (O(nlogn) basic sorting from java)
		Arrays.sort(edges, Edge::compareWeight);

		int cost = 0;
		int select = 0;
		idx = 0;
		Edge[] selected = new Edge[n-1];
		UF uf = new UF(n);
		while (select < n-1){
			if (uf.connectIfNot(edges[idx].vertex1, edges[idx].vertex2)){
				selected[select] = edges[idx];
				cost += edges[idx].weight;
				select += 1;
			}
			idx += 1;
		}
		
		//Arrays.sort(selected, Edge::compareVertex);
		// output MST
		System.out.println(cost);
		for (int i = 0; i < n-1; i++)
			System.out.println(selected[i].vertex1 + " " + selected[i].vertex2);
		
	}


}
