#include <bits/stdc++.h>
using namespace std;
struct E { int u, v, weight; };
int main() {
	int n, k, count = 0;
	cin >> n >> k;
	vector<string> dna(n);
	for(auto &x : dna) cin >> x;
	vector<vector<int>> d(n, vector<int>(n, 0));
	for(int u = 0; u < n; ++u)
		for(int v = 0; v < n; ++v)
			for(int l = 0; l < k; ++l) d[u][v] += dna[u][l] != dna[v][l];

	vector<bool> done(n, false);
	done[0] = true;
	vector<E> ans;
	for(int i = 0; i < n-1; ++i){
		vector<int> left;
		left.reserve(n-i-1);
		for(int u = 0; u < n; ++u) if(!done[u]) left.push_back(u);
		E e{0,0,numeric_limits<int>::max()};
		for(int u = 0; u < n; ++u)
			if(done[u])
				for(auto v : left){
					int di = d[u][v];
					if(di < e.weight)
						e = {u,v,di};
				}
		done[e.v] = true;
		ans.push_back(e);
	}
	cout << accumulate(ans.begin(), ans.end(), 0, [](int w, E e){return w+e.weight;}) << '\n';
	for(auto e : ans)
		cout << e.u << ' ' << e.v << '\n';
	return 0;
}
