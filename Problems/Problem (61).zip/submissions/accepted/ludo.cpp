#include<bits/stdc++.h>

using namespace std;

#define x first
#define y second
#define pb push_back
#define eb emplace_back
#define rep(i,a,b) for(auto i = (a); i != (b); ++i)
#define REP(i,n) rep(i,0,n)
#define all(v) (v).begin(), (v).end()

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<ii> vii;

const int maxn = 1000;

int N, K, D[maxn], P[maxn];
string S[maxn];

int sim(int a, int b) {
	int r = 0;
	REP(i, K) r += S[a][i] != S[b][i];
	return r;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	cin >> N >> K;
	REP(i, N) cin >> S[i];

	REP(i, N) D[i] = sim(0, i);
	D[0] = -1; // used.

	vii ret;
	int sum = 0;

	REP(i, N - 1) {
		int nxt = -1, nxtD = 1e8;
		REP(j, N)
			if (D[j] >= 0 && D[j] < nxtD) nxtD = D[nxt = j];
		assert(nxt >= 0 && D[nxt] == nxtD);

		ret.eb(nxt, P[nxt]);
		sum += D[nxt];
		D[nxt] = -1;

		// update distances
		REP(j, N)
			if (D[j] >= 0) {
				int alt = sim(nxt, j);
				if (alt < D[j])
					D[j] = alt, P[j] = nxt;
			}
	}

	cout << sum << endl;
	for (ii pr : ret) cout << pr.x << " " << pr.y << endl;

	return 0;
}
