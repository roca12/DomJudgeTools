#include <bits/stdc++.h>
using namespace std;
struct E { int u, v, weight; };
bool operator<(const E& l, const E& r){ return l.weight < r.weight; }
int main() {
	int n, k; cin >> n >> k;
	vector<string> dna(n);
	for(auto &x : dna) cin >> x;
	vector<int> w(n, 0);
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			for(int l=0;l<k;++l)
				w[i] += dna[i][l] != dna[j][l];
	int r = min_element(w.begin(), w.end()) - w.begin();
	cout << w[r] << '\n';
	for(int i = 0; i < n; ++i)
		if(i != r)
			cout << r << ' ' << i << '\n';
	return 0;
}
