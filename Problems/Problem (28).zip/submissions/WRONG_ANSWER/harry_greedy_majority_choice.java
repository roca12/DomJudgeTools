import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class harry_greedy_majority_choice {
	
	static boolean[][] adj; // I opt for the "less-than-optimal" O(N^3) (instead of O(VE)).
	
	static int[] prev;
	static int R, B;
	static int total;
	
	
	public static void main(String[] args) {
		
		
		int[] xpos, ypos;
		int target;
		// Input reading.
		
		Scanner sc = new Scanner(System.in);
		target = sc.nextInt();
		B = sc.nextInt();
		R = sc.nextInt();
		
		// I swapped R and B. Sorry.
		xpos = new int[R + B];
		ypos = new int[R + B];
		
		for(int i = 0; i < B; i++)
		{
			xpos[i + R] = sc.nextInt();
			ypos[i + R] = sc.nextInt();
			assert(xpos[i + R] <= 10000 && xpos[i + R] >= -10000 && ypos[i + R] <= 10000 && ypos[i + R] >= -10000);
		}
		for(int i = 0; i < R; i++)
		{
			xpos[i] = sc.nextInt();
			ypos[i] = sc.nextInt();
			assert(xpos[i] <= 10000 && xpos[i] >= -10000 && ypos[i] <= 10000 && ypos[i] >= -10000);
		}	
		
		
		double minDist = 0, maxDist = 1000000;
		double precision = Math.pow(10.0, -9);
		while(maxDist - minDist > precision)
		{
			// Reset whatever is necessary.
			adj = new boolean[R][B];
			double dist = (minDist + maxDist) / 2;
			total = 0;
			
			// Build the graph.
			for(int i = 0; i < R; i++)
				for(int j = R; j < R + B; j++)
				{
					int xdist = xpos[i] - xpos[j], ydist = ypos[i] - ypos[j];
					if(xdist * xdist + ydist * ydist < dist * dist)
						adj[i][j - R] = true;
				}
			
			
		
			// Find the matching.
			
			Queue<Integer> queue = new LinkedList<Integer>();
			boolean[] visited = new boolean[R + B];

			
			for(int i = 0; i < R + B; i++)
	        	if(!visited[i])
	        	{
	        		queue.add(i);
	        		int red_nodes = 0, blue_nodes = 0;
	        		visited[i] = true;
	        	
			
					while(!queue.isEmpty())
					{
						int cur = queue.remove();
			            
						if(cur < R)
			            {
							red_nodes++;
			            	for(int j = R; j < R + B; j++)
			            		if(adj[cur][j - R] && !visited[j])
			            		{
			            			visited[j] = true;
			            			queue.add(j);
			            		}
			            }
			            else 
			            {
			            	blue_nodes++;
			            	for(int j = 0; j < R; j++)
			            		if(adj[j][cur - R] && !visited[j])
			            		{
			            			visited[j] = true;
			            			queue.add(j);
			            		}
			            }
						
					}
					
					total += Math.max(red_nodes, blue_nodes);					
	        	}
			
			if(total >= target) // We can hide enough eggs, so we should increase the minimal distance.
				minDist = dist;
			else maxDist = dist;	
			
			
		}
		
		System.out.println((minDist + maxDist) / 2);
		}	
}
