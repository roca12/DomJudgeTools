#include <algorithm>
#include <cassert>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <queue>
#include <tuple>
#include <vector>
using namespace std;

struct P {
	int x, y;
};
int dist(P &l, P &r) { return (l.x - r.x) * (l.x - r.x) + (l.y - r.y) * (l.y - r.y); }
struct D {
	int b, r, dist;
	bool operator<(const D &x) { return tie(dist, b, r) < tie(x.dist, x.b, x.r); }
};

template <typename F>
void subset(vector<int>::iterator &b, vector<int>::iterator &e, int k, vector<int> &out, F f) {
	if(k == 0) {
		f(out);
		return;
	}
	if(k > e - b) return;
	out.push_back(*b);
	++b;
	subset(b, e, k - 1, out, f);
	out.pop_back();
	subset(b, e, k, out, f);
	--b;
}

int main() {
	int n, b, r;
	cin >> n >> b >> r;
	vector<P> ps(b + r);
	for(auto &p : ps) cin >> p.x >> p.y;
	vector<int> is(b + r), out;
	iota(is.begin(), is.end(), 0);
	int best = 0;
	auto be = is.begin(), e = is.end();
	subset(be, e, n, out, [&](const vector<int> &is) {
		int d = 1e9;
		for(auto a = is.begin(); *a < b; ++a)
			for(auto e = is.rbegin(); *e >= b; ++e) d = min(d, dist(ps[*a], ps[*e]));
		best                                          = max(best, d);
	});
	cout << fixed << setprecision(11) << sqrt(double(best)) << endl;
	return 0;
}
