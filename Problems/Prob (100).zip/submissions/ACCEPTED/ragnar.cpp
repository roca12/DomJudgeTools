#include <cmath>
#include <iomanip>
#include <iostream>
#include <unordered_map>
using namespace std;
int main() {
	int n;
	cin >> n;
	unordered_map<string, pair<bool, long double>> m;
	m["pink"] = {true, 0};
	while(n--) {
		string s, t;
		long double r;
		cin >> t >> s >> r;
		if(m[s].first)
			m[t] = {true,
			        m[t].first ? max(m[t].second, log(r) + m[s].second) : log(r) + m[s].second};
	}
	cout << fixed << setprecision(15)
	     << (m["blue"].first ? exp(min(m["blue"].second, log(10.L))) : 0) << endl;
	return 0;
}
