import java.io.*;
import java.util.TreeMap;

public class Solution{
    public int N, L = 0;
    public TreeMap<String,Double> bestRate = new TreeMap<String, Double>();

    public double getRate(String name) {
        if (bestRate.get(name) == null) 
            bestRate.put(name, Double.NEGATIVE_INFINITY);
        return bestRate.get(name);
    }

    public void solve() throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String[] words;
        words = br.readLine().split("\\s");
        N = Integer.parseInt(words[0]);
        bestRate.put("pink", 0.0);
        String O, W;
        double R;
        for (int i = 0; i < N; i++) {
            words = br.readLine().split("\\s");
            O = words[0];
            W = words[1];
            R = Double.parseDouble(words[2]);
            double newRate = Math.max(getRate(O), getRate(W) + Math.log(R));
            bestRate.put(O, newRate);
        }
        double ans = getRate("blue");
        if (ans < -1000.0)
            System.out.println("0.000000");
        else if (ans > Math.log(10)) {
            System.out.println("10.000000");
        } else {
            double number = Math.exp(ans);
            System.out.println(number);
            //cout << setprecision(7) << fixed << number << '\n';
        }
    }

    public static void main(String args[]) throws IOException {
        Solution d = new Solution();
        d.solve();
    }
}
