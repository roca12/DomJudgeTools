// @EXPECTED_RESULTS@: ACCEPTED, TIMELIMIT

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/*
When using BigDecimals this code runs in O(n^2),
because multiplication is linear in the length of a number
and the length is logarithmic in the value, but the value is exponential in the input.
*** BUT by specifying an accuracy for each operation, it is fast enough.
 */

public class LemonadeBigDec2 {
    private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    private Map<String, BigDecimal> m = new HashMap<>();

    public static void main(String[] args) throws IOException {
        (new LemonadeBigDec2()).solve();
    }

    void solve() throws IOException {
        String[] words = br.readLine().split("\\s");
        int N = Integer.parseInt(words[0]);

        m.put("pink", BigDecimal.ONE);
        // 400 decimals per operation, is that enough?
        // Probably much more than what you get when adding logs of doubles
        MathContext mc = new MathContext(400, RoundingMode.HALF_EVEN);

        while (N-- > 0) {
            words = br.readLine().split("\\s");
            String t = words[0];
            String s = words[1];
            BigDecimal r = new BigDecimal(words[2], mc);

            BigDecimal ms = m.get(s);
            if (ms != null) {
                BigDecimal newval = ms.multiply(r, mc);
                m.merge(t, newval, BigDecimal::max);
            }
        }

        BigDecimal mb = m.get("blue");
        DecimalFormat dm = new DecimalFormat("#0.000000000000000000000000000000000000000");
        if (mb != null) {
            if(mb.compareTo(BigDecimal.valueOf(10)) > 0) {
                System.out.println(dm.format(10));
            } else {
                System.out.println(dm.format(mb));
            }
        } else {
            System.out.println(dm.format(0));
        }
    }
}
