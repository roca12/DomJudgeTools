// Solution to: Lemonade Trade
// By: Raymond van Bommel

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cctype>
#include <climits>
#include <cassert>

#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <list>
#include <set>
#include <map>
#include <string>

#include <iostream>
#include <iomanip>
#include <sstream>

#include <utility>
#include <functional>
#include <limits>
#include <numeric>
#include <algorithm> 

using namespace std;

#define MaxN 1000000
int N, L = 0;
map<string,double> bestRate;

double getRate(string name) {
	if (bestRate.find(name) == bestRate.end())
		bestRate[name] = -numeric_limits<double>::infinity();
	return bestRate[name];
}

int main () {
	cin >> N;
	bestRate["pink"] = 0.0;
	string O, W;
	double R;
	for (int i = 0; i < N; i++) {
		cin >> O >> W >> R;
		double newRate = max(getRate(O), getRate(W) + log(R));
		bestRate[O] = newRate;
		//cerr << "bestRate[" << O << "] = " << getRate(O) << '\n';
	}
	double ans = getRate("blue");
	if (ans < -1000.0)
		cout << "0.000000\n";
	else if (ans > log(10)) {
		cout << "10.000000\n";
	} else {
		double number = exp(ans);
		cout << setprecision(7) << fixed << number << '\n';
	}
	return 0;
}
