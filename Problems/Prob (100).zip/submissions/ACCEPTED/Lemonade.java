import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class Lemonade {
    private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    private Map<String, Double> m = new HashMap<>();

    public static void main(String[] args) throws IOException {
        (new Lemonade()).solve();
    }

    void solve() throws IOException {
        String[] words = br.readLine().split("\\s");
        int N = Integer.parseInt(words[0]);

        m.put("pink", (double) 0);

        while (N-- > 0) {
            words = br.readLine().split("\\s");
            String t = words[0];
            String s = words[1];
            double r = Double.parseDouble(words[2]);

            Double ms = m.get(s);
            if (ms != null) {
                Double newval = Math.log(r) + ms;
                m.merge(t, newval, Double::max);
            }
        }

        Double mb = m.get("blue");
        DecimalFormat dm = new DecimalFormat("#0.000000");
        if (mb != null) {
            System.out.println(dm.format(Math.exp(Double.min(mb, Math.log(10)))));
        } else {
            System.out.println(dm.format(0));
        }
    }
}
