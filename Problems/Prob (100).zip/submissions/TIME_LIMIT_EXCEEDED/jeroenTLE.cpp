#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

struct T {
	int o, w;
	double r;
};

bool isIn(set<string> s, string a){
	return(s.find(a) != s.end());
}

int main(){
	
	int N;
	cin >> N;
	set<string> cs;
	cs.insert("pink");
	cs.insert("blue");
	map<string,int> mcs;
	mcs["pink"] = 0;
	mcs["blue"] = 1;
	int cnt = 2;
	vector<T> ts (N);
	for(int i = 0; i < N; i++){
		string a, b;
		double r;
		cin >> a >> b >> r;
		if(!isIn(cs,a)){ cs.insert(a); mcs[a] = cnt; cnt++; }
		if(!isIn(cs,b)){ cs.insert(b); mcs[b] = cnt; cnt++; }
		ts[i] = {mcs[a],mcs[b],r};
		// clog << mcs[a] << " " << mcs[b] << " " << r << endl;
	}
	int M = cs.size();
	vector<vector<double> > ans (N+1, vector<double> (M,0.0) );

	ans[0][0] = 1.0;
	int i = 1;
	for(; i < N+1; i++){
		for(int j = 0; j < M; j++){
			ans[i][j] = ans[i-1][j];
		}
		T cur = ts[i-1];
		ans[i][cur.o] = max(ans[i][cur.o],cur.r * ans[i][cur.w]);
		if(ans[i][1] > 10.0) break;
	}
	if(i == N+1) i--;
	if(ans[i][1] > 10.0) cout << 10.000000 << endl;
	else cout << fixed << setprecision(8) << ans[i][1] << endl;

	return 0;
}