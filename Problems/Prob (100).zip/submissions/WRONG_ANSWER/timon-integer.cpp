#include <bits/stdc++.h>
using namespace std;

using ll = long long;
constexpr ll M = 1e6;

int main() {
	int n;
	cin >> n;

	unordered_map<string, ll> best;
	best["pink"] = M;
	best["blue"] = 0LL;

	while (n--) {
		string o, w;
		long double _f;
		cin >> o >> w >> _f;
		ll f = ll(_f * M + 0.5);
		best[o] = max(best[o], (best[w] * f + (M / 2)) / M);
	}

	printf("%.10lf\n", min(10.0, double(best["blue"]) / double(M)));
}
