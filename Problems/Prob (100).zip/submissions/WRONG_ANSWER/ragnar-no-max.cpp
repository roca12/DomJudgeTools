#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <unordered_map>
using namespace std;
struct S {
	long double v;
	S(long double v = -10000000) : v(v) {}
	operator long double() { return v; }
};
int main() {
	int n;
	cin >> n;
	unordered_map<string, S> m;
	m["pink"] = 0;
	while(n--) {
		string s, t;
		long double r;
		cin >> t >> s >> r;
		m[t] = log(r) + m[s];
	}
	cout << fixed << setprecision(15) << exp(min(m["blue"].v, log(10.L))) << endl;
	return 0;
}
