// Solution to: Lemonade Trade

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cctype>
#include <climits>
#include <cassert>

#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <list>
#include <set>
#include <map>
#include <string>

#include <iostream>
#include <iomanip>
#include <sstream>

#include <utility>
#include <functional>
#include <limits>
#include <numeric>
#include <algorithm> 

using namespace std;

#define MaxN 1000000
int N, L = 0;
map<string,double> bestRate;

double getRate(string name) {
	if (bestRate.find(name) == bestRate.end())
		bestRate[name] = 0.0;
	return bestRate[name];
}

int main () {
	cin >> N;
	bestRate["pink"] = 1.0;
	string O, W;
	double R;
	for (int i = 0; i < N; i++) {
		cin >> O >> W >> R;
		bestRate[O] = max(getRate(O), getRate(W)*R);
	}
	if (getRate("blue") > 10.0) {
		cout << setprecision(7) << fixed << "10.00000\n";
	} else {
		cout << setprecision(7) << fixed << getRate("blue") << '\n';
	}
	return 0;
}
