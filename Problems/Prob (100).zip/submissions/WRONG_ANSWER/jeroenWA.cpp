#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>

using namespace std;

double INF = (1<<30);

struct T {
	int o, w;
	double r;
};

bool isIn(set<string> &s, string a){
	return(s.find(a) != s.end());
}

int main(){
	ios::sync_with_stdio(false); cin.tie(nullptr);
	int N;
	cin >> N;
	set<string> cs;
	cs.insert("pink");
	cs.insert("blue");
	map<string,int> mcs;
	mcs["pink"] = 0;
	mcs["blue"] = 1;
	int cnt = 2;
	vector<T> ts (N);
	for(int i = 0; i < N; i++){
		string a, b;
		double r;
		cin >> a >> b >> r;
		if(!isIn(cs,a)){ cs.insert(a); mcs[a] = cnt; cnt++; }
		if(!isIn(cs,b)){ cs.insert(b); mcs[b] = cnt; cnt++; }
		ts[i] = {mcs[a],mcs[b],r};
	}

	int M = cs.size();
	vector<double> maxans (M,0.0);
	maxans[0] = log2(1.0);
	
	for(int i = 0; i < N; i++){
		T cur = ts[i];
		//if(maxans[cur.w] == -INF) continue;
		maxans[cur.o] = max(maxans[cur.o],log2(cur.r) + maxans[cur.w]);
		if(maxans[1] > log2(10.0)) break;
	}
	if(maxans[1] > log2(10.0)) cout << 10.000000 << endl;
	else cout << fixed << setprecision(8) << pow(2,maxans[1]) << endl;

	return 0;
}