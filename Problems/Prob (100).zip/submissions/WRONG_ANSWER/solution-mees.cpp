// Problem: Lemonade Trade
// Author: Mees
//
// Expected answer: WRONG ANSWER

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <climits>
#include <cmath>

using namespace std;

int main() {
    int N; cin >> N;
    map<string, double> cbest;
    cbest["pink"] = log(1.0);
    for(int i = 0; i < N; i++) {
        string O, W; double R;
        cin >> O >> W >> R;
        cerr << "hier1" << endl;
        cerr << "O: " << O << " W: " << W << " R: " << R << endl;
        if(cbest.find(W) == cbest.end()) {
            cerr << "We cannot have what they want. Continue." << endl;
            continue;
        }
        cerr << "We could have what they want." << endl;
        if(cbest.find(O) != cbest.end()) {
            cerr << "hier: offered hebben we" << endl;
            cbest[O] = log(R) + cbest[W];
        }
        else {
            cerr << "hier: offered hebben we nog niet" << endl;
            cbest[O] = max(log(R) + cbest[W], cbest[O]);
        }
    }
    if(cbest.find("blue") == cbest.end())
        printf("%.8lf\n",0.0);
    else
        printf("%.8lf\n",exp(cbest["blue"]));
    return 0;
}
