#include <bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;

	unordered_map<string, long double> best;
	best["pink"] = 1.0;
	best["blue"] = 0.0;

	while (n--) {
		string o, w;
		long double f;
		cin >> o >> w >> f;
		best[o] = max(best[o], best[w] * f);
	}

	printf("%.10lf\n", min(10.0, double(best["blue"])));
}
