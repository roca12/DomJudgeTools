#include "validation.h"
#include <cmath>

// Read 2 <= m <= n.
// Check gcd(n, m) = 1
// Check m squarefree.

long long gcd(long long a, long long b) { return b == 0 ? a : gcd(b, a%b); }

bool squarefree(long long n){
    if(n == 1)
        return true;
	for(long long i = 2; i < 1000000; ++i) {
		if(n % i == 0) {
            n /= i;
            if(n % i == 0)
                return false;
            else if(n == 1)
                return true;
        }
    }
    double sr = sqrt(n);
    long long i_sr = sr + 0.5;
	return i_sr*i_sr != n;
}


int main(int argc, char **argv) {
	// Set up the input and answer streams.
	std::ifstream in(argv[1]);
	OutputValidator v(argc, argv);

	long long n;
	in >> n;

	long long m = v.read_long_long(2, n);
	v.newline();

	v.check(gcd(n, m) == 1, "GCD of ",n," and ",m," is not 1.");
	v.check(squarefree(m), m, " is not squarefree itself.");
}
