#include <vector>
#include <iostream>
using namespace std;

using ll = long long;

// Finds b^e % m in O(lg n) time, ensure that b < m to avoid overflow!
template<typename T=long long>
constexpr T powmod(T b, ll e, T m) {
	T p = e<2 ? T{1} : powmod((b*b)%m,e/2,m);
	return e&1 ? p*b%m : p;
}

vector<ll> p1 = {2,7,61};					// <= 2^32
vector<ll> p2 = {2,13,23,1662803};		// <= 1.1e12
vector<ll> p3 = {2,3,5,7,11,13,17,19,23};	// <= 3.8e18, v <= 2^64
vector<ll> p4 = {2,325,9375,28178,450775,9780504,1795265022};
using lll = __int128;
bool miller_rabin(const lll n){	// true when prime
	if(n > -1ull) return false;
	if(n<2) return false;		
	if(n%2==0) return n==2;
	ll s = 0, d = n-1; // n-1 = 2^s * d
	while(~d&1) s++, d/=2;
	const vector<ll>& primes = n <= -1u ? p1 : (n <= 1e12 ? p2 : p3);
	for(auto a : primes){
		if(a > n-2) break;
		lll x = powmod<lll>(a,d,n);
		if(x == 1 || x == n-1) continue;
		for (int i = 0; i < s - 1; ++i) {
			x = x*x%n;
			if(x==1) return false;
			if(x==n-1) goto next_it;
		}
		return false;
next_it:;
	}
	return true;
}

int main(){
	ll n; cin >> n;
	for(ll m = (n-1)/2; m >= 2; --m){
		if(miller_rabin(m)){
			cout << m << endl;
			return 0;
		}
	}
}
