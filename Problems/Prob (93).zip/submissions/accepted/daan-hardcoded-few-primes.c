#include <stdio.h>

// assumes 2 < n < 2^32
const int p[16] = { 
	2, 3, 5, 7,		// <= 2^3
	11, 13,			// 2 in [2^3,2^4) 
	17, 23,			// 2 in [2^4,2^6)
	67, 71,			// 2 in [2^6,2^8)
	257, 263,		// 2 in [2^8,2^12)
	4099, 4111,		// 2 in [2^12,2^16)
	65537, 65539	// 2 in [2^16,2^24)
};

int main() {
	int n, i;
	scanf( "%d", &n );
	for( int i = 0; i < 16 && p[i] < n; ++i ) {
		if( n % p[i] != 0 ) {
			printf( "%d\n", p[i] );
			return 0;
		}
	}
	printf( "Impossible\n" );
}