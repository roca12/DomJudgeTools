#include <iostream>
using namespace std;

bool squarefree(long long n){
	for(long long k = 2; k <= n; ++k)
		if(n%(k*k)==0) return false;
	return true;
}

int main(){
	int n;
   	cin >> n;
	int m = 2;
	while(!squarefree(m*n)) ++m;
	cout << m << endl;
}
