#include <iostream>
#include <numeric>

using namespace std;

long long gcd(long long a, long long b){ return b==0?a:gcd(b, a%b); }

int main() {
    unsigned long long n;
    cin >> n;

    for (unsigned long long m = 2; m < n; m++) {
        if (gcd(n, m) == 1) {
            cout << m << endl;
            break;
        }
    }

    return 0;
}
