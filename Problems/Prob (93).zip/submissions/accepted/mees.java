import java.util.Scanner;
import java.lang.Math;

public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        long n = sc.nextLong();
        for(long m = 2; m < n; m++) {
            boolean squarefree = true;
            for(long k = 2; k < n; k++) {
                if((m*n) % (k*k) == 0) {
                    squarefree = false;
                    break;
                }
            }
            if(squarefree) {
                System.out.println(m);
                break;
            }
        }
	}
}
