#include <iostream>
#include <cmath>

using namespace std;

bool squareFree(unsigned long long nm) {
    for (unsigned long long i = 2; i <= sqrt(nm); i++) {
        if (nm % (i * i) == 0) {
            return false;
        }
    }

    return true;
}

int main() {
    int n;
    cin >> n;

    for (int m = 2; m < n; m++) {
        if (squareFree(n * m)) {
            cout << m << endl;
            break;
        }
    }

    return 0;
}