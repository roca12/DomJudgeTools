#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ll n;
	cin >> n;
	pair<string, ll> b[n];
	for (ll i = 0; i < n; ++i) cin >> b[i].first >> b[i].second;
	sort(b, b + n, [](auto &a, auto &b) {
			return (a.second * a.second * (a.first == "cube" ? 1 : M_PI)) < (b.second * b.second * (b.first == "cube" ? 1 : M_PI));
		});
	for (ll i = 1; i < n; ++i) {
		if (b[i].first == b[i - 1].first) continue;
		if (b[i].first == "cylinder" && b[i - 1].second > b[i].second * sqrt(2)) {
			cout << "impossible" << endl;
			return 0;
		}
		if (b[i].first == "cube" && b[i - 1].second * 2 > b[i].second) {
			cout << "impossible" << endl;
			return 0;
		}
	}
	for (auto x : b) cout << x.first << " " << x.second << endl;
	return 0;
}
