#!/usr/bin/env pypy3

from collections import deque

import sys

if __name__ == "__main__":
    n = int(sys.stdin.readline())
    lines = [line.split(" ") for line in (sys.stdin.readline() for _ in range(n))]
    cylinder = deque(sorted((int(a), x) for x, a in lines if x == "cylinder"))
    cubes = deque(sorted((int(a), x) for x, a in lines if x == "cube"))
    stack = []

    while cylinder or cubes:
        if not cylinder:
            stack += cubes
            break
        elif not cubes:
            stack += cylinder
            break
        elif cubes[0][0] ** 2 <= 2 * cylinder[0][0] ** 2:
            stack += [cubes.popleft()]
        elif cylinder[0][0] * 2 <= cubes[0][0]:
            stack += [cylinder.popleft()]
        else:
            print("impossible")
            sys.exit(0)

    print("\n".join("{0} {1:d}".format(x, a) for a, x in stack))
