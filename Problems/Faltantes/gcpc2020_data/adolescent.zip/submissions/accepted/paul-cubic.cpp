#include <bits/stdc++.h>
using namespace std;

int main() {
	int n; cin >> n;

	vector<string> type(n);
	vector<int> size(n);
	for (int i = 0; i < n; i++) {
		cin >> type[i] >> size[i];
	}

	auto fits_inside = [&](int i, int j) {
		if (type[i] == type[j]) return size[i] <= size[j];
		if (type[i] == "cube") return size[i]/sqrt(2) <= size[j];
		return 2*size[i] <= size[j];
	};
	
	vector<bool> used(n);
	vector<int> res;
	for (int k = 0; k < n; k++) {
		bool found = false;
		for (int i = 0; i < n; i++) if (!used[i]) {
			bool ok = true;
			for (int j = 0; j < n; j++) {
				if (!used[j] && !fits_inside(i,j)) {
					ok = false;
				}
			}
			if (ok) {
				found = true;
				used[i] = true;
				res.push_back(i);
				break;
			}
		}
		if (!found) {
			cout << "impossible" << endl;
			return 0;
		}
	}
	
	for (int i: res) cout << type[i] << " " << size[i] << endl;
}
