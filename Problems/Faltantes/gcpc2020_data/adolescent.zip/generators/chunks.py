#!/usr/bin/python3
import random
import sys

# cube 100 1 1000
# cylinder 100 1 1000
# cube 50 1 300 cylinder 50

s = int(sys.argv[1])
random.seed(s)

assert len(sys.argv) % 4 == 2

blocks = []
for k in range(2,len(sys.argv),4):
    shape = sys.argv[k]
    cnt, lo, hi = map(int, sys.argv[k+1:k+4])
    blocks += [(shape,random.randint(lo,hi)) for _ in range(cnt)]

random.shuffle(blocks)

print(len(blocks))
for shape, size in blocks:
    print(shape + ' ' + str(size))
