#!/usr/bin/python3
import random
import sys

n, s = map(int, sys.argv[1:3])

random.seed(s)

print(n)
for _ in range(n):
    shape = random.choice(['cube', 'cylinder'])
    size = random.randint(1,1000)
    print(shape + ' ' + str(size))
