#!/usr/bin/env python3
from math import ceil, sqrt
import random
import sys

s = int(sys.argv[1])
random.seed(s)

n = 20 + random.randint(0,10)
k = random.randint(5,n-1)

conv = [[1.0, 2.0], [1/sqrt(2), 1.0]]

shape = random.randint(0,1)
size = random.randint(1,3)
blocks = [(shape,size)]

for i in range(n):
    nshape = 1-shape if i == k else random.randint(0,1)
    nsize = ceil(size * conv[shape][nshape])
    nsize += -1 if i == k else random.randint(0,3)
    size, shape = nsize, nshape
    blocks.append((shape,size))

random.shuffle(blocks)

print(n+1)
for shape, size in blocks:
    print(['cylinder','cube'][shape], size)

