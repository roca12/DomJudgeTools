#include <bits/stdc++.h>
using namespace std;

const int N = 100, M = 1000;

const double factor[2][2] = {{1.0, sqrt(2)}, {0.5, 1.0}};

int main(int argc, char **argv) {
	assert(argc >= 2);
	int seed = atoi(argv[1]);

	mt19937 gen(seed);

	auto rand_int = [&](int from, int to) {
		return uniform_int_distribution<int>(from,to)(gen);
	};
	auto rand_double = [&](double from, double to) {
		return uniform_real_distribution<double>(from,to)(gen);
	};

	// A tower of blocks is built from bottom to top.
	// The next block is always selected randomly, according to some parameters:

	// The probability that the next block has a different type (cube/cylinder).
	double prob_change = rand_double(0.25, 0.75);
	
	// The size of the range from which the next block size is randomly drawn.
	int size_range = exp(rand_double(0, log(M)));

	vector<pair<int,int>> blocks;
	blocks.emplace_back(rand_int(0,1), M);

	while (blocks.size() <= N) {
		auto [is_cube, size] = blocks.back();
		int next_is_cube = is_cube;
		if (rand_double(0,1) < prob_change) {
			next_is_cube = !next_is_cube;
		}

		int max_next_size = min(1000, (int) (factor[is_cube][next_is_cube] * size));
		int min_next_size = max(1, max_next_size - size_range);

		if (min_next_size > max_next_size) break;

		int next_size = rand_int(min_next_size, max_next_size);
		blocks.emplace_back(next_is_cube, next_size);
	}

	blocks.erase(begin(blocks));

	// Sometimes add some random blocks, which likely creates an 'impossible' case.
	if (rand_int(0,7) == 0) {
		int count = 3;
		while (count--) {
			if (blocks.size() == N) break;
			blocks.emplace_back(rand_int(0,1), rand_int(1,N));
		}
	}

	shuffle(begin(blocks), end(blocks), gen);
	
	cout << blocks.size() << endl;
	for (auto [is_cube, size]: blocks) {
		cout << (is_cube ? "cube" : "cylinder") << " " << size << endl;
	}
}
