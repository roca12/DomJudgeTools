Schwierigkeit: 5% ungelöst

Lösung:
  
  Sortiere nach Fläche, überprüfe die Bedingungen mit einfachen Formeln.

Komplexität:
  
  O(n*log n) fürs sortieren, aber bei so einfachen Aufgaben kann man die
  Constraints auch gerne mal kleiner setzen als nötig.

Variante:

  Füge Bausteine mit dreieckiger Grundfläche hinzu. Erhöht die Schwierigkeit
  um einiges, weil man mehr Formeln finden muss und dabei auch mehr Fehler machen
  kann. Zudem sind die Formeln schwieriger herzuleiten, etwa:
  https://www.quora.com/How-long-is-the-side-of-the-largest-equilateral-triangle-that-can-be-inscribed-in-a-square-whose-side-has-length-1/answer/Doug-Dillon-1
