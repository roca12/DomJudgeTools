#!/usr/bin/python3
import random
import sys

random.seed(int(sys.argv[1]))

t = random.randint(1,10**6)
s = random.randint(1,10**6)
n = random.randint(1,min(1000,t-1))

times = sorted(random.sample(range(1,t), n))

print(f'{t} {s} {n}')
print(' '.join(map(str, times)))
