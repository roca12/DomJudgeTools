#include <bits/stdc++.h>
using namespace std;

int main() {
	int t, s, n;
	cin >> t >> s >> n;

	vector<bool> flip(t);
	while (n--) {
		int a; cin >> a;
		flip[a] = 1;
	}

	int up = 0, dn = s;
	for (int k = 0; k < t; k++) {
		if (flip[k]) swap(up,dn);
		up--, dn++;
	}
	cout << up << endl;
}
