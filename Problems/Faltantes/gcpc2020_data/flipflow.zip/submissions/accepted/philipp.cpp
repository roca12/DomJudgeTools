#include <bits/stdc++.h>
using namespace std;

int main() {
	int t, s, n;
	cin >> t >> s >> n;
	vector<int> flips;
	while(n--) {
		int time;
		cin >> time;
		flips.push_back(time);
	}
	flips.push_back(t);
	flips.push_back(t);

	int upper = 0;
	int prevtime = 0;
	for(int time : flips) {
		int interval = time - prevtime;
		upper = max(0, upper - interval);
		upper = s - upper;
		prevtime = time;
	}

	cout << upper << endl;
}
