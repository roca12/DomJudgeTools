#!/usr/bin/env pypy3

import sys
from collections import deque

if __name__ == "__main__":
    t, s, _ = map(int, sys.stdin.readline().split(" "))
    flips = deque(map(int, sys.stdin.readline().split(" ")))
    top, bot = 0, s
    time = 0
    while flips:
        flip = flips.popleft()
        diff = flip - time
        flow = min(top, diff)
        top, bot = bot + flow, top - flow
        time = flip
    print(max(top - (t - time), 0))
