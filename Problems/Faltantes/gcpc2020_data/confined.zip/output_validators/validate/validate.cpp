#include <bits/stdc++.h>
#include "validate.h"

using namespace std;

int n;
vector<pair<int,int>> player;
pair<int,int> ai;

string mode; //random, flee, flee1, flee2, stay, distsum
int seed;

int dist(pair<int,int> a, pair<int,int> b) {
	return abs(a.first - b.first) + abs(a.second - b.second);
}

void read_player() {
	vector<pair<int,int>> read(2);
	if(!(author_out >> read[0].first >> read[0].second >> read[1].first >> read[1].second)) {
		wrong_answer("lacking output\n");
	}
	for(int i = 0; i < 2; i++) {
		if(dist(player[i], read[i]) > 1) {
			wrong_answer("moved invalid distance\n");
		}
		if(read[i].first < 1 || read[i].first > n || read[i].second < 1 || read[i].second > n) {
			wrong_answer("moved outside the grid\n");
		}
	}
	player = read;
}

bool player_won() {
	return player[0] == ai || player[1] == ai;
}

void collect_valid_moves(vector<pair<int,int>>& moves) {
	vector<pair<int,int>> dirs = {{0,1}, {0,-1}, {-1,0}, {1,0}, {0,0}};
	for(pair<int,int> dir : dirs) {
		pair<int,int> move = {ai.first + dir.first, ai.second + dir.second};
		if(move.first < 1 || move.first > n || move.second < 1 || move.second > n || move == player[0] || move == player[1]) {
			continue;
		}
		moves.push_back(move);
	}
}

void set_ai() {
	if(mode == "stay") {
		return;
	}

	vector<pair<int,int>> moves;
	collect_valid_moves(moves);

	if(mode == "random") {
		ai = moves[rand() % moves.size()];
		return;
	}

	if(mode == "flee") {
		set<int> best{0,0};
		vector<pair<int,int>> bestmoves;
		for(pair<int,int> move : moves) {
			set<int> candidate{dist(move, player[0]), dist(move, player[1])};
			if(candidate > best) {
				best = candidate;
				bestmoves.clear();
			}
			if(candidate == best) {
				bestmoves.push_back(move);
			}
		}
		ai = bestmoves[rand() % bestmoves.size()];
		return;
	}

	if(mode == "flee1") {
		pair<int,int> best{0,0};
		vector<pair<int,int>> bestmoves;
		for(pair<int,int> move : moves) {
			pair<int,int> candidate{dist(move, player[0]), dist(move, player[1])};
			if(candidate > best) {
				best = candidate;
				bestmoves.clear();
			}
			if(candidate == best) {
				bestmoves.push_back(move);
			}
		}
		ai = bestmoves[rand() % bestmoves.size()];
		return;
	}

	if(mode == "flee2") {
		pair<int,int> best{0,0};
		vector<pair<int,int>> bestmoves;
		for(pair<int,int> move : moves) {
			pair<int,int> candidate{dist(move, player[1]), dist(move, player[0])};
			if(candidate > best) {
				best = candidate;
				bestmoves.clear();
			}
			if(candidate == best) {
				bestmoves.push_back(move);
			}
		}
		ai = bestmoves[rand() % bestmoves.size()];
		return;
	}

	if(mode == "distsum") {
		int best = 0;
		vector<pair<int,int>> bestmoves;
		for(pair<int,int> move : moves) {
			int candidate = dist(move, player[0]) + dist(move, player[1]);
			if(candidate > best) {
				best = candidate;
				bestmoves.clear();
			}
			if(candidate == best) {
				bestmoves.push_back(move);
			}
		}
		ai = bestmoves[rand() % bestmoves.size()];
		return;
	}
}

int main(int argc, char **argv) {
	init_io(argc, argv);
	player.resize(2);

	judge_in >> n;
	cout << n << endl;
	judge_in >> player[0].first >> player[0].second >> player[1].first >> player[1].second;
	cout << player[0].first << ' ' << player[0].second << ' ' << player[1].first << ' ' << player[1].second << endl;
	judge_in >> ai.first >> ai.second;
	cout << ai.first << ' ' << ai.second << endl;

	judge_in >> mode >> seed;
	srand(seed);

	for(int i = 1; i <= 600; i++) {
		read_player();
		if(player_won()) {
			cout << "0 0" << endl;
			break;
		}
		set_ai();
		cout << ai.first << ' ' << ai.second << endl;
		if(i > 590) judge_message("%d %d %d %d %d %d\n", player[0].first, player[0].second, player[1].first, player[1].second, ai.first, ai.second);
	}
	if(!player_won()) {
		wrong_answer("player did not catch ai within 600 turns\n");
	}

	/* Check for trailing output. */
	string trash;
	if (author_out >> trash) {
		wrong_answer("Trailing output\n");
	}

	/* Yay! */
	accept();
}
