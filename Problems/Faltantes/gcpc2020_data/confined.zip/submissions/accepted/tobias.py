#!/usr/bin/env pypy3

import sys


def approach1(bx, by):
    if ax == bx:
        if ay == by:
            return bx, by
        return bx, by + 1 if by < ay else by - 1
    return bx + 1 if bx < ax else bx - 1, by

def approach2(bx, by):
    if ay == by:
        if ax == bx:
            return bx, by
        return bx + 1 if bx < ax else bx - 1, by
    return bx, by + 1 if by < ay else by - 1


if __name__ == "__main__":
    n = int(sys.stdin.readline())
    x1, y1, x2, y2 = map(int, sys.stdin.readline().split(" "))

    while True:
        ax, ay = map(int, sys.stdin.readline().split(" "))
        if (ax, ay) == (0, 0):
            break
        x1, y1 = approach1(x1, y1)
        x2, y2 = approach2(x2, y2)
        sys.stdout.write(f"{x1:d} {y1:d} {x2:d} {y2:d}\n")
        sys.stdout.flush()
