#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ll n, x1, y1, x2, y2, x, y;
	cin >> n >> x1 >> y1 >> x2 >> y2 >> x >> y;
	while (x > 0) {
		if (x1 == x) y1 -= (y1 > y) - (y1 < y);
		else x1 -= (x1 > x) - (x1 < x);
		if (y2 == y) x2 -= (x2 > x) - (x2 < x);
		else y2 -= (y2 > y) - (y2 < y);
		cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
		cin >> x >> y;
	}
	return 0;
}
