#include <bits/stdc++.h>
using namespace std;

int n;
vector<pair<int,int>> own;
pair<int,int> ai;

bool inposition() {
	return own[0].first == 1 && own[0].second == n && own[1].first == n && own[1].second == 1;
}

void printi() {
	cout << own[0].first << ' ' << own[0].second << ' ' << own[1].first << ' ' << own[1].second << endl;
}

bool readi() {
	cin >> ai.first >> ai.second;
	return !ai.first;
}

int main() {
	cin >> n;
	own.resize(2);
	cin >> own[0].first >> own[0].second >> own[1].first >> own[1].second;
	cin >> ai.first >> ai.second;
	while(!inposition()) {
		if(own[0].first > 1) {
			own[0].first--;
		} else if(own[0].second < n) {
			own[0].second++;
		}
		if(own[1].first < n) {
			own[1].first++;
		} else if(own[1].second > 1) {
			own[1].second--;
		}
		printi();
		if(readi()) {
			goto done;
		}
	}
	while(true) {
		for(int i = 0; i < 2; i++) {
			int xdiff = ai.first - own[i].first, ydiff = ai.second - own[i].second;
			if(abs(xdiff) > abs(ydiff) || abs(xdiff) == abs(ydiff) && i == 0) {
				own[i].first += xdiff / abs(xdiff);
			} else {
				own[i].second += ydiff / abs(ydiff);
			}
		}
		printi();
		if(readi()) {
			goto done;
		}
	}

done:
	exit(0);
}
