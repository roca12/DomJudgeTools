#include <iostream>
using namespace std;

int align(int cur, int target)
{
	if (cur < target) return cur + 1;
	else if (cur > target) return cur - 1;
	return cur;
}

int main()
{
	int n; cin >> n;
	int x1, y1, x2, y2; cin >> x1 >> y1 >> x2 >> y2;
	int x,y; cin >> x >> y; 
	while (x != 0 || y != 0)
	{
		if (x1 != x) x1 = align(x1,x);
		else y1 = align(y1,y);
		if (y2 != y) y2 = align(y2,y);
		else x2 = align(x2,x);
		cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl << flush;
		cin >> x >> y;
	}
}
