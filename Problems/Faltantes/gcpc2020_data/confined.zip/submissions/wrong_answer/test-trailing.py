#!/usr/bin/env pypy3

import sys


def approach(bx, by):
    if ax == bx:
        if ay == by:
            return bx, by
        return bx, by + 1 if by < ay else by - 1
    return bx + 1 if bx < ax else bx - 1, by


if __name__ == "__main__":
    n = int(sys.stdin.readline())
    x1, y1, x2, y2 = map(int, sys.stdin.readline().split(" "))

    while True:
        ax, ay = map(int, sys.stdin.readline().split(" "))
        x1, y1 = approach(x1, y1)
        x2, y2 = approach(x2, y2)
        sys.stdout.write(f"{x1:d} {y1:d} {x2:d} {y2:d}\n")
        sys.stdout.flush()
