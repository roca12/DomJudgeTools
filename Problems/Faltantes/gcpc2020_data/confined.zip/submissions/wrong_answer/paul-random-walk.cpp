#include <bits/stdc++.h>
using namespace std;

const int dx[] = {-1,0,0,0,1};
const int dy[] = {0,-1,0,1,0};

pair<int,int> random_move(int x, int y, int n) {
	int dir = rand() % 5;
	int nx = x + dx[dir], ny = y + dy[dir];
	if (nx >= 1 && nx <= n && ny >= 1 && ny <= n) return {nx,ny};
	return random_move(x, y, n);
}

int main() {
	int n, ax, ay, bx, by, x, y;
	cin >> n >> ax >> ay >> bx >> by;

	while (true) {
		cin >> x >> y;
		if (x == 0) break;
		
		tie(ax,ay) = random_move(ax,ay,n);
		tie(bx,by) = random_move(bx,by,n);

		cout << ax << " " << ay << " " << bx << " " << by << endl;
	}
}
