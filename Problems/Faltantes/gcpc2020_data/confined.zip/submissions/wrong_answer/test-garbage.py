#!/usr/bin/env pypy3

import sys
import random

if __name__ == "__main__":
    modes = {"offset", "large", "small", "string", "crash"}
    if len(sys.argv) <= 1:
        mode = None
    else:
        mode = sys.argv[1]
    if mode is None or mode not in modes:
        mode = random.choice(list(modes))

    n = int(sys.stdin.readline())
    x1, y1, x2, y2 = map(int, sys.stdin.readline().split(" "))

    while True:
        if mode == "offset":
            x1 = x1 + 2
            if x1 > n:
                x1 = x1 - 2
        elif mode == "large":
            x1 = n + 1
        elif mode == "small":
            x1 = 0
        elif mode == "string":
            x1 = "garbage"
        elif mode == "crash":
            sys.exit(1)
        ax, ay = map(int, sys.stdin.readline().split(" "))
        sys.stdout.write(f"{x1} {y1:d} {x2:d} {y2:d}\n")
        sys.stdout.flush()
