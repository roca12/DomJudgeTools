#!/usr/bin/env pypy3

import sys

if __name__ == "__main__":
    n = int(sys.stdin.readline())
    x1, y1, x2, y2 = map(int, sys.stdin.readline().split(" "))

    while True:
        ax, ay = map(int, sys.stdin.readline().split(" "))
        sys.stdout.write(f"{x1:d} {y1:d} {x2:d} {y2:d}\n")
        sys.stdout.flush()
