Interactive problem.
You're playing a board game on a square grid. You have two pieces, the opponent has one. Catch the opponent in a limited amount of turns.
You can move both pieces independently each turn.
Movement options for all pieces are moving up, down, left, or right to a neighboring cell (if there is one) as well as staying in the current cell.

Solution:
Move your pieces to opposite corners and then move them towards the opponent from opposite directions.
Important thing #1: For each piece, prioritize the axis that takes up the larger part of the distance to the opponent piece (instead of just taking any direction that lowers the overall distance).
Important thing #2: In case of a tie between x axis distance and y axis distance, don't use the same for both pieces.

Constraints:
Size 100² and turn limit 600 -> possible to move pieces to predetermined corners from anywhere (<200) + go to opponent (<200) + follow it to edge (<100) + follow it to corner (<100).

Estimated difficulty:
60% unsolved
