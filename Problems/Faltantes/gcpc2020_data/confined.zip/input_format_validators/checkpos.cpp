#include <bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;
	vector<pair<int,int>> pos(3);
	for(auto& pii : pos) {
		cin >> pii.first >> pii.second;
	}
	if(pos[0] == pos[2] || pos[1] == pos[2]) {
		exit(43);
	}
	exit(42);
}
