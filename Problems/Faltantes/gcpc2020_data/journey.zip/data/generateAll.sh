#!/bin/bash

X=10
Y=10
S=42

g++ generate.cpp -o gen
g++ ../submissions/accepted/gregor.cpp -o sol

for i in $(seq 1 5) ; do
	echo Generating $X $Y Nr $i
	S=$(( $(./generateOne.sh $X $Y $S) + 1 ))
done

X=100
Y=100

for i in $(seq 1 5) ; do
	echo Generating $X $Y Nr $i
	S=$(( $(./generateOne.sh $X $Y $S) + 1 ))
done

X=1000
Y=1000

for i in $(seq 1 5) ; do
	echo Generating $X $Y Nr $i
	S=$(( $(./generateOne.sh $X $Y $S) + 1 ))
done


X=2000
Y=2000

for i in $(seq 1 5) ; do
	echo Generating $X $Y Nr $i
	S=$(( $(./generateOne.sh $X $Y $S) + 1 ))
done


