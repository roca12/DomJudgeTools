#!/bin/bash

S=$3

X=$(printf "%04d" $1)
Y=$(printf "%04d" $2)
SS=$(printf "%03d" $S)


while true ; do
	cp secret/random-$X-$Y-$SS.in temp.in
	#echo $1 $2 $S | ./gen > temp.in
	./sol < temp.in > temp.ans

	if [[ $(cat temp.ans | wc -w) != 0 ]] ; then
		break
	fi

	S=$(($S + 1))

done

mv temp.in secret/random-$X-$Y-$SS.in
mv temp.ans secret/random-$X-$Y-$SS.ans

echo $S
