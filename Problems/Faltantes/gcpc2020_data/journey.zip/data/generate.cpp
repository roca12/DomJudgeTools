#include <bits/stdc++.h>

using namespace std;

const int oo = 0x3f3f3f3f;
const double eps = 1e-9;
const double PI = 2.0 * acos(0.0);


typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<string> vs;

#define sz(c) int((c).size())
#define all(c) (c).begin(), (c).end()
#define FOR(i,a,b) for (int i = (a); i < (b); i++)
#define FORS(i,a,b,s) for (int i = (a); i < (b); i=i+(s))
#define FORD(i,a,b) for (int i = int(b)-1; i >= (a); i--)
#define FORIT(i,c) for (__typeof__((c).begin()) i = (c).begin(); i != (c).end(); i++)


int main(){
	int N,M,S; cin >> N >> M >> S;
	srand(S);

	set<pii> glades;

	cout << N << " " << M << endl;

	FOR(i,0,N){
		pii np;
		do {
			np.first = (rand() % 2000) - 1000;
			np.second = (rand() % 2000) - 1000;
		} while (glades.count(np));
		cout << np.first << " " << np.second << endl;
		glades.insert(np);
	}

	vector<pair<pii,int>> circles;
	
	// slow, but does not matter for generating
	FOR(i,0,M){
		pii c;
		int r;
		do {
			c.first = (rand() % 2000) - 1000;
			c.second = (rand() % 2000) - 1000;
			r = 1 + (rand() % 500);

			bool bad = false;
			for (pii g : glades){
				int dx = c.first - g.first;
				int dy = c.second - g.second;
				int dist = dx*dx + dy*dy;

				if (dist <= r*r) {
					bad = true;
					break;
				}
			}

			if (bad) continue;

			for (auto h : circles){
				int dx = c.first - h.first.first;
				int dy = c.second - h.first.second;
				int dist = dx*dx + dy*dy;

				if (dist <= (r + h.second) * (r + h.second)) {
					bad = true;
					break;
				}
			}

			if (bad) continue;
			
			cout << c.first << " " << c.second << " " << r << endl;

			circles.push_back(make_pair(c,r));
			
			break;

		} while (true);
	
	}

}
