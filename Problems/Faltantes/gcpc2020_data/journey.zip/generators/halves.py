#!/usr/bin/env python3
import math
import sys

n = int(sys.argv[1])
m = int(math.sqrt(n))

print(f'{n} {n}')

for i in range(2*n):
    x, y = divmod(i,m)
    if i < n:
        print(f'{10*x} {10*y}')
    else:
        print(f'{10*x} {10*y} 3')
