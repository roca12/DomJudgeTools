#!/usr/bin/env python3
import math
import sys

n = int(sys.argv[1])

print(f'{n} {n}')

for i in range(2*n):
    x = i*10
    y = int(i*10 + (i+1)*i/2)
    if i < n:
        print(f'{x} {y}')
    else:
        print(f'{x} {y} 3')
