#!/usr/bin/env python3
import math
import sys

n = int(sys.argv[1])

print(f'{n} {n}')

for i in range(2*n):
    j = i % n
    x = j*10
    y = int(j*10 + (j+1)*j/2)
    if i < n-1:
        print(f'{x} {y}')
    elif i == n-1:
        print(f'{5*n+n*1500} {int(5*n + n*(n+1)/2)}')
    else:
        print(f'{x+10} {y} {7}')
