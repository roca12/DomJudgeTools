#include <bits/stdc++.h>
using namespace std;

const double tau = 4*acos(0);

struct point {
	long x, y;
};

point operator+(point a, point b) { return {a.x+b.x, a.y+b.y}; }
point operator-(point a, point b) { return {a.x-b.x, a.y-b.y}; }
long  operator*(point a, point b) { return a.x*b.x + a.y*b.y; }  // dot product

double normalize(double x) { return fmod(x+tau, tau); }
double angle(point a) { return normalize(atan2(a.y, a.x)); }
double abs(point a) { return sqrt(a*a); }

const int N = 12340;
bool reach[N], blocked[N];
vector<int> adj[N];

void dfs(int i, int w) {
	reach[i] = true;
	for (int j: adj[i]) {
		if (!reach[j]) dfs(j,w);
	}
}

int main() {
	int n, m;
	cin >> n >> m;

	vector<point> node(n);
	for (auto &p: node) cin >> p.x >> p.y;

	vector<point> center(m);
	vector<long> radius(m);
	for (int i = 0; i < m; i++) {
		cin >> center[i].x >> center[i].y >> radius[i];
	}

	for (int i = 0; i < n; i++) {
		vector<tuple<double,double,int>> events;
		set<double> blocked;

		for (int j = 0; j < n; j++) if (j != i) {
			point v = node[j]-node[i];
			events.emplace_back(angle(v), abs(v), j);
		}

		sort(begin(events), end(events));
		auto it = unique(begin(events), end(events), [&](auto a, auto b) {
			return abs(get<0>(a) - get<0>(b)) < 1e-12;
		});
		events.erase(it, end(events));
		
		for (int k = 0; k < m; k++) {
			point v = center[k]-node[i];
			double alpha = angle(v);
			double beta = asin(radius[k]/abs(v)) + 1e-12;

			double lo = normalize(alpha-beta), hi = normalize(alpha+beta);
			double dist = sqrt(v*v - radius[k]*radius[k]);

			events.emplace_back(lo, dist, -1);
			events.emplace_back(hi, dist, -2);

			if (hi < lo) {
				blocked.insert(dist);
			}
		}

		sort(begin(events), end(events));

		for (auto [alpha,dist,j]: events) {
			if (j < 0) {
				if (j == -1) blocked.insert(dist);
				else blocked.erase(dist);
			} else if (blocked.empty() || dist < *begin(blocked)) {
				adj[i].push_back(j);
			}
		}
	}
	
	int s = n-1;
	for (int w = 0; w < n; w++) if (w != s) {
		memset(reach,0,sizeof reach);
		reach[w] = true;
		dfs(s,w);
		for (int i = 0; i < n; i++) {
			if (!reach[i]) blocked[i] = true;
		}
	}

	bool first = true;
	for (int i = 0; i < n; i++) {
		if (i != s && !blocked[i]) {
			if (first) first = false;
			else cout << " ";
			cout << i + 1;
		}
	}
	cout << endl;
}
