#include <bits/stdc++.h>
using namespace std;

struct point { long x, y; };

point operator+(point a, point b) { return {a.x+b.x, a.y+b.y}; }
point operator-(point a, point b) { return {a.x-b.x, a.y-b.y}; }
long  operator*(point a, point b) { return a.x*b.x + a.y*b.y; }  // dot product
long  operator%(point a, point b) { return a.x*b.y - a.y*b.x; }  // cross product

// check if point p lies strictly inside the segment a-b
bool on_segment(point p, point a, point b) {
	return (b-a)%(p-a) == 0 && (a-p)*(b-p) < 0;
}

// check if the segment a-b intersects the circle (c,r)
bool intersectSC(point a, point b, point c, long r) {
	if ((c-a)*(b-a) < 0) return (a-c)*(a-c) <= r*r;
	if ((c-b)*(a-b) < 0) return (b-c)*(b-c) <= r*r;
	__int128 area = abs((c-a)%(b-a)), len2 = (b-a)*(b-a);
	return area*area <= len2*r*r;
}

const int N = 12340;
bool reach[N], blocked[N];
vector<int> adj[N];

void dfs(int i, int w) {
	reach[i] = true;
	for (int j: adj[i]) {
		if (!reach[j]) dfs(j,w);
	}
}

int main() {
	int n, m;
	cin >> n >> m;

	vector<point> node(n);
	for (auto &p: node) cin >> p.x >> p.y;

	vector<point> center(m);
	vector<long> radius(m);
	for (int i = 0; i < m; i++) {
		cin >> center[i].x >> center[i].y >> radius[i];
	}
	
	for (int i = 0; i < n; i++) {
		for (int j = i+1; j < n; j++) {
			bool ok = true;
			for (int k = 0; k < m; k++) {
				if (intersectSC(node[i], node[j], center[k], radius[k])) {
					ok = false;
					break;
				}
			}
			if (!ok) continue;
			for (int k = 0; k < n; k++) {
				if (on_segment(node[k], node[i], node[j])) {
					ok = false;
					break;
				}
			}
			if (ok) {
				adj[i].push_back(j);
				adj[j].push_back(i);
			}
		}
	}
	
	int s = n-1;
	for (int w = 0; w < n; w++) if (w != s) {
		memset(reach,0,sizeof reach);
		reach[w] = true;
		dfs(s,w);
		for (int i = 0; i < n; i++) {
			if (!reach[i]) blocked[i] = true;
		}
	}

	bool first = true;
	for (int i = 0; i < n; i++) {
		if (i != s && !blocked[i]) {
			if (first) first = false;
			else cout << " ";
			cout << i + 1;
		}
	}
	cout << endl;
}

