#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <cfloat>
#include <climits>
#include <numeric>
#include <iomanip>

using namespace std;

const int oo = 0x3f3f3f3f;
const double eps = 1e-8;
const double PI = acos(-1.0);


typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<ll> vll;
typedef vector<int> vi;
typedef vector<string> vs;

#define sz(c) int((c).size())
#define all(c) (c).begin(), (c).end()
#define FOR(i,a,b) for (int i = (a); i < (b); i++)
#define FORS(i,a,b,s) for (int i = (a); i < (b); i=i+(s))
#define FORD(i,a,b) for (int i = int(b)-1; i >= (a); i--)
#define FORIT(i,c) for (__typeof__((c).begin()) i = (c).begin(); i != (c).end(); i++)


int sig(double d) {
		return (d > eps) - (d < -eps);
}

int n, m;
pair<ll,ll> b[10500];

ll px[10500];
ll py[10500];
ll pr[10500];


pair<double,pair<ll, ll> > an[40000];

bool doubleCMP(pair<double,pair<ll, ll> > & a, pair<double,pair<ll, ll> > & b){
		if (a.first < b.first - eps) return true;
		if (a.first > b.first + eps) return false;
		if (a.second.first < 0 || a.second.first > 2*n ||
				b.second.first < 0 || b.second.first > 2*n){
					if (a.second < b.second) return true;
		} else {
			if (a.second.second < b.second.second - eps) return true;
		}
		return false;
}

double norm(double a){
		while (sig(a) < 0) a += 2*PI;
		while ((2*PI - a) < 0) a -= 2*PI;
		return a;
}

void era(multiset<double> & s, double e){
		if (!s.count(e)) return;
		s.erase(s.find(e));
}


vll adj[10500]; // input: adj list
ll pre[10500]; // temp: preorder nums
ll lo[10500]; // temp: lowlink nums
ll curpre; // temp: next preorder num
set<ll> arti; // output: articulation nodes
set<ll> blocks[10500];

void dfs(ll a) {
		bool isan = false;
		pre[a] = curpre++;
		lo[a] = pre[a];
		ll cc = 0;
		FOR(i, 0, sz(adj[a])) {
				ll b = adj[a][i];
				if (pre[b] == -1) {
						cc++;
						dfs(b);
						lo[a] = min(lo[a], lo[b]);
						if (pre[a] != 0 && lo[b] >= pre[a])
								isan = true;
				}
				else
						lo[a] = min(lo[a],pre[b]);
		}
		blocks[a].insert(sz(arti));
		if (isan || (pre[a] == 0 && cc >= 2)){
			arti.insert(a);
			blocks[a].insert(sz(arti));
		}
}

ll articulation(ll n) {
		FOR(i, 0, n)
				pre[i] = -1;
		curpre = 0;
		arti.clear();
		dfs(n-1); // start in the component in which the initial node lies
		return arti.size();
}


set<ll> safe_spots;
ll visi[10500];

void find_safe_spots(int n, int i){
	if (visi[i]) return;
	visi[i] = true;
	if (i != n-1) safe_spots.insert(i);

	if (i != n-1 && arti.count(i)) return;
	FORIT(j, adj[i]) find_safe_spots(n,*j);
}


int main(){
		cin >> n >> m;

		FOR(i,0,n) cin >> b[i].first >> b[i].second;
		FOR(i,0,m) cin >> px[i] >> py[i] >> pr[i];

		// construct the graph
		FOR (i,0,n) {
				int idx = 0;
				//compute angles for the other beacons
				FOR(j,0,n) if (i != j){
						ll ox = b[j].first - b[i].first;
						ll oy = b[j].second - b[i].second;
						an[idx++] = make_pair(norm(atan2(oy,ox)),make_pair(j,ox*ox+oy*oy));
				}


				// peaks
				FOR(j,0,m){
						ll ox = px[j] - b[i].first;
						ll oy = py[j] - b[i].second;
						ll d = ox*ox + oy*oy;
						double angle = norm(atan2(oy,ox));
						double rad = asin(pr[j]/sqrt(d));
						double a1 = angle - rad;
						double a2 = angle + rad;
						while (sig(a1) < 0) a1 += 2*PI, a2 += 2*PI;
						d -= pr[j] * pr[j];

						if (sig(a2 - 2*PI) <= 0) {
								an[idx++] = make_pair(a1,make_pair(-2*n-j,d));
								an[idx++] = make_pair(a2,make_pair(2*n+j,d));
						} else {
								an[idx++] = make_pair(a1,make_pair(-2*n-j,d));
								an[idx++] = make_pair(2*PI,make_pair(2*n+j,d));
								an[idx++] = make_pair(0.0,make_pair(-2*n-j,d));
								an[idx++] = make_pair(a2-2*PI,make_pair(2*n+j,d));
						}
				}

				sort(an,an+idx,doubleCMP);
				// build
				multiset<double> c;
				//cout << endl << endl << "ROUND " << endl;
				FOR(j,0,idx){
						//cout << an[j].first << " Object: " << an[j].second.first << " Distance: " << an[j].second.second;
						//cout << " " << sz(c) << " " << an[j].second.second - *c.begin() << endl;
						if (an[j].second.first <= -2*n) c.insert(an[j].second.second);
						else if (an[j].second.first >= 2*n) era(c,an[j].second.second);
						else if (!sz(c) || 0 > an[j].second.second - *c.begin()) {
								// these are sorted by distance, so take only the first one
								if (j && fabs(an[j-1].first - an[j].first) < 1e-6 &&
												an[j-1].second.first >-2*n &&
												an[j-1].second.first < 2*n) continue;
								int b = an[j].second.first;
								cerr << "E " << i << " " << b << endl;
								adj[i].push_back(b);
						}
				}

		}

		articulation(n);
		FOR(i,0,n) visi[i] = false;
		find_safe_spots(n,n-1);
		FORIT(ss,safe_spots) cout << (ss == safe_spots.begin() ? "" : " ") << 1 + *ss;
		cout << endl;
		return 0;
}
