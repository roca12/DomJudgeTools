#!/usr/bin/env bash

g++ -std=c++17 -O2 preprocess.cpp -o preprocess

for file in ../data/*/*.in; do
	echo $(basename $file)
	./preprocess < $file | cat $file - | asy visualize.asy -f png -o ${file%.in}.png
done

rm preprocess
