Problem: God save the queen
Difficulty: 95%


Idea: Given a set of points and circles. Two points are connected, iff the direct path between them does not intersect any of the circles.
	For the resulting undirected graph G, and two given nodes s and t, determine all vertices that are contained in every path from s to t.

Solution:
	- first build the graph. Since the number of points and circles is huge (~1000), use angular sorting for each point to determine which other points are reachable. The direct intersection test is N^3, and thus TLE
	
	- every vertex -- except it is an articulation point -- can be avoided, i.e. there is a path from s to t without it.
	- find any path from s to t, then a node is part of the output iff we switch blocks using it.


Note: the graph theoretic part can also be brute-forced since there are only N=1000	vertices
