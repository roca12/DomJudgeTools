--Crane Scheduling--
Check the problem statement (it is story-free).

--Solution--
Check the solution outlines

--Difficulty--
85% unsolved
