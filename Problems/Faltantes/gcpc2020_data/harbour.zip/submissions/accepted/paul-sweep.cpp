// This solution is an optimization of the simpler solution `paul-no-sweep.cpp`.
// It uses a sweep line approach to achieve a time complexity of O(a*b*n*log(n)).

#include <bits/stdc++.h>
using namespace std;

void self_min(int &x, int y) { x = min(x,y); }

const int N = 2005;

vector<int> events[N];

struct dp_row {
	int from, to, val[N];
	vector<tuple<int,int,int>> intervals;

	dp_row(int from, int to): from(from), to(to) {
		memset(val,0x3f,sizeof val);
	}

	// At each index i (from <= i <= to), we want to update the minimum value
	// with max(|i-a|, b) + c. So the update value is b+c on the interval from
	// a-b to a+b, and increases in steps of 1 outside of that interval. We
	// store these intervals for later processing.
	void add_update(int a, int b, int c) {
		intervals.emplace_back(max(from,a-b), min(to,a+b), b+c);
	}

	// To process the updates efficiently, we sweep over indices from <= i <= to
	// while maintaining the set of intervals containing i. This way we can find
	// the minimal value for each index if only the constant interval of each
	// update is considered. For the full updates, we do two more sweeps, one
	// left-to-right and one right-to-left.
	void process_updates() {
		for (auto [i,j,v]: intervals) {
			events[i].push_back(v);
			events[j+1].push_back(~v);
		}

		multiset<int> active;
		for (int i = from; i <= to; i++) {
			for (int v: events[i]) {
				if (v >= 0) active.insert(v);
				else active.erase(active.find(~v));
			}
			if (!active.empty()) {
				self_min(val[i], *begin(active));
			}
			events[i].clear();
		}
		events[to+1].clear();

		for (int i = from+1; i <= to; i++) {
			self_min(val[i], val[i-1]+1);
		}
		for (int i = to-1; i >= from; i--) {
			self_min(val[i], val[i+1]+1);
		}
	}

	int &operator[](int i) { return val[i]; }
};

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> p(a), q(b);
	for (int &x: p) cin >> x;
	for (int &y: q) cin >> y;
	p.push_back(1), q.push_back(n);

	/* Find the minimal number of steps needed to get to certain configurations:
	 * 
	 * dpa[i][j][y]: A last visited p[i], B last visited q[j], A is at p[i], B is at y
	 * dpb[i][j][x]: A last visited p[i], B last visited q[j], A is at x, B is at q[j]
	 */

	vector<vector<dp_row>> dpa(a+1), dpb(a+1);
	for (int i = 0; i <= a; i++) {
		for (int j = 0; j <= b; j++) {
			dpa[i].emplace_back(p[i]+1, n);
			dpb[i].emplace_back(1, q[j]-1);
		}
	}
	
	dpa[0][0][n] = dpb[0][0][1] = 1;
	
	for (int i = 0; i < a; i++) {
		for (int j = 0; j < b; j++) {
			dpa[i][j].process_updates();
			for (int y = p[i]+1; y <= n; y++) {
				int goa = abs(p[i+1]-p[i]) + 1, gob = abs(q[j+1]-y) + 1;
				
				dpa[i+1][j].add_update(y, goa, dpa[i][j][y]);

				dpb[i][j+1].add_update(p[i], gob, dpa[i][j][y]);

				self_min(dpa[i+1][j+1][q[j+1]], dpa[i][j][y] + max(goa,gob));
			}
			
			dpb[i][j].process_updates();
			for (int x = 1; x < q[j]; x++) {
				int goa = abs(p[i+1]-x) + 1, gob = abs(q[j+1]-q[j]) + 1;
			
				dpa[i+1][j].add_update(q[j], goa, dpb[i][j][x]);

				dpb[i][j+1].add_update(x, gob, dpb[i][j][x]);

				self_min(dpa[i+1][j+1][q[j+1]], dpb[i][j][x] + max(goa,gob));
			}
		}
	}

	cout << dpa[a-1][b-1][n] << endl;
}
