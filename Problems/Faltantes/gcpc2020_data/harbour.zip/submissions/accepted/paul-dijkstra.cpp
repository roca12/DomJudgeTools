#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> p(a), q(b);
	for (int &x: p) cin >> x;
	for (int &y: q) cin >> y;
	p.push_back(1);
	q.push_back(n);

	auto approachB = [&](int x, int y, int goal, int dt) {
		int ymin = max(x+1, y-dt), ymax = y+dt;
		return goal < ymin ? ymin : goal > ymax ? ymax : goal;
	};

	auto approachA = [&](int x, int y, int goal, int dt) {
		int xmin = x-dt, xmax = min(y-1, x+dt);
		return goal < xmin ? xmin : goal > xmax ? xmax : goal;
	};

	map<tuple<int,int,int,int>,int> dist;
	set<tuple<int,int,int,int,int>> pq;

	auto add = [&](int i, int j, int x, int y, int t) {
		auto tpl = make_tuple(i,j,x,y);
		if (dist.count(tpl) && dist[tpl] <= t) return;
		pq.erase({dist[tpl],i,j,x,y});
		dist[tpl] = t;
		pq.insert({dist[tpl],i,j,x,y});
	};

	add(1, 1, 1, n, 1);

	while (!pq.empty()) {
		auto [t,i,j,x,y] = *begin(pq);
		pq.erase(begin(pq));
		if (i < a) {
			int dt = abs(p[i]-x);
			int nj = j, ny = approachB(p[i], y, q[j], dt);
			if (ny == q[j]) nj = min(j+1,b);
			else ny = approachB(p[i], y, q[j], dt+1);
			add(i+1, nj, p[i], ny, t+dt+1);
		}
		if (j < b) {
			int dt = abs(q[j]-y);
			int ni = i, nx = approachA(x, q[j], p[i], dt);
			if (nx == p[i]) ni = min(i+1,a);
			else nx = approachA(x, q[j], p[i], dt+1);
			add(ni, j+1, nx, q[j], t+dt+1);
		}
	}
	
	cout << dist[{a,b,1,n}] << endl;
}
