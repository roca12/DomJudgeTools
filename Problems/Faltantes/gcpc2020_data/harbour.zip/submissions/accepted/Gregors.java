import java.util.Scanner;

public class Gregors
{
    static final int TASKS = 51;
    static final int LEN = 2001;
    static final int INF = 100_000_000;
    static int[][][] dpA = new int[TASKS][TASKS][LEN];
    static int[][][] dpB = new int[TASKS][TASKS][LEN];
    static int[] taskA = new int[TASKS];
    static  int[] taskB = new int[TASKS];

    static void init(int n, int a, int b)
    {
        for (int i = 0; i < a+1; ++i)
            for (int j = 0; j < b+1; ++j)
                for (int k = 0; k < n+1; ++k)
                    dpA[i][j][k] = dpB[i][j][k] = INF;
    }

    static void performTaskA(int i, int j, int posA, int posB, int val)
    {
        int stepsA = Math.abs(posA - taskA[i+1]) + 1;
        int targetB = taskB[j+1] <= taskA[i+1] ? taskA[i+1]+1 : taskB[j+1];
        int stepsB = Math.min(stepsA, Math.abs(posB - targetB));
        int nxtB = posB < targetB ? posB + stepsB : posB - stepsB;
        dpA[i+1][j][nxtB] = Math.min(dpA[i+1][j][nxtB], val + stepsA);
    }

    static void performTaskB(int i, int j, int posA, int posB, int val)
    {
        int stepsB = Math.abs(posB - taskB[j+1]) + 1;
        int targetA = taskA[i+1] >= taskB[j+1] ? taskB[j+1]-1 : taskA[i+1];
        int stepsA = Math.min(stepsB, Math.abs(posA - targetA));
        int nxtA = posA < targetA ? posA + stepsA : posA - stepsA;
        dpB[i][j+1][nxtA] = Math.min(dpB[i][j+1][nxtA], val + stepsB);
    }

    static void performTaskAB(int i, int j, int posA, int posB, int val)
    {
        int nxtA = taskA[i+1];
        int nxtB = taskB[j+1];
        if (nxtA >= nxtB) return;
        int stepsA = Math.abs(posA - nxtA) + 1;
        int stepsB = Math.abs(posB - nxtB) + 1;
        if (stepsA != stepsB) return;
        dpA[i+1][j+1][nxtB] = Math.min(dpA[i+1][j+1][nxtB], val + stepsA);
        dpB[i+1][j+1][nxtA] = Math.min(dpB[i+1][j+1][nxtA], val + stepsA);
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a = sc.nextInt();
        int b = sc.nextInt();

        for (int i = 0; i < a; ++i)
            taskA[i] = sc.nextInt();
        for (int i = 0; i < b; ++i)
            taskB[i] = sc.nextInt();
        taskA[a] = 1;
        taskB[b] = n;
        init(n,a,b);
        dpA[0][0][n] = 1;
        dpB[0][0][1] = 1;
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                for (int posB = taskA[i] + 1; posB <= n; ++posB) {
                    int posA = taskA[i];
                    int val = dpA[i][j][posB];
                    performTaskA(i, j, posA, posB, val);
                    performTaskB(i, j, posA, posB, val);
                    performTaskAB(i, j, posA, posB, val);
                }
                for (int posA = 1; posA < taskB[j]; ++posA) {
                    int posB = taskB[j];
                    int val = dpB[i][j][posA];
                    performTaskA(i, j, posA, posB, val);
                    performTaskB(i, j, posA, posB, val);
                    performTaskAB(i, j, posA, posB, val);
                }
            }
        }
        System.out.println(Math.min(dpA[a - 1][b - 1][n], dpB[a - 1][b - 1][1]));
    }
}




