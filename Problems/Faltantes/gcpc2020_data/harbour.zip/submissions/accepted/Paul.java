import java.util.*;

public class Paul {
	int n, a, b;
	int[] p, q;
	int[][][] dpa, dpb;

	int approachA(int x, int y, int goal, int dt) {
		int xmin = x-dt, xmax = Math.min(x+dt, y-1);
		return goal < xmin ? xmin : goal > xmax ? xmax : goal;
	}

	int approachB(int x, int y, int goal, int dt) {
		int ymin = Math.max(y-dt, x+1), ymax = y+dt;
		return goal < ymin ? ymin : goal > ymax ? ymax : goal;
	}

	void completeA(int i, int j, int x, int y, int t) {
		int dt = Math.abs(p[i+1]-x);
		int nj = j, ny = approachB(p[i+1], y, q[j+1], dt);
		if (ny == q[j+1]) nj = Math.min(j+1,b-1);
		else ny = approachB(p[i+1], y, q[j+1], dt+1);
		dpa[i+1][nj][ny] = Math.min(dpa[i+1][nj][ny], t+dt+1);
	}

	void completeB(int i, int j, int x, int y, int t) {
		int dt = Math.abs(q[j+1]-y);
		int ni = i, nx = approachA(x, q[j+1], p[i+1], dt);
		if (nx == p[i+1]) ni = Math.min(i+1,a-1);
		else nx = approachA(x, q[j+1], p[i+1], dt+1);
		dpb[ni][j+1][nx] = Math.min(dpb[ni][j+1][nx], t+dt+1);
	}

	void run() {
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		a = sc.nextInt();
		b = sc.nextInt();
		
		p = new int[a+1];
		for (int i = 0; i < a; i++) {
			p[i] = sc.nextInt()-1;
		}
		p[a] = 0;
		
		q = new int[b+1];
		for (int j = 0; j < b; j++) {
			q[j] = sc.nextInt()-1;
		}
		q[b] = n-1;
		
		dpa = new int[a][b][n];
		dpb = new int[a][b][n];
		for (int[][] u: dpa) for (int[] v: u) Arrays.fill(v, (int)1e6);
		for (int[][] u: dpb) for (int[] v: u) Arrays.fill(v, (int)1e6);
		
		dpa[0][0][n-1] = dpb[0][0][0] = 1;

		for (int i = 0; i < a; i++) {
			for (int j = 0; j < b; j++) {
				for (int y = p[i]+1; y < n; y++) {
					if (i+1 < a) completeA(i, j, p[i], y, dpa[i][j][y]);
					if (j+1 < b) completeB(i, j, p[i], y, dpa[i][j][y]);
				}
				for (int x = 0; x < q[j]; x++) {
					if (i+1 < a) completeA(i, j, x, q[j], dpb[i][j][x]);
					if (j+1 < b) completeB(i, j, x, q[j], dpb[i][j][x]);
				}
			}
		}

		int res = Math.min(dpa[a-1][b-1][n-1], dpb[a-1][b-1][0]);
		System.out.println(res);
	}

	public static void main(String[] args) {
		new Paul().run();
	}
}
