import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;

class Pair<T1,T2>
{
    T1 first;
    T2 second;
    Pair(T1 first, T2 second)
    {
        this.first = first;
        this.second = second;
    }
}

class Triple<T1,T2,T3>
{
    T1 first;
    T2 second;
    T3 third;
    Triple(T1 first, T2 second, T3 third)
    {
        this.first = first;
        this.second = second;
        this.third = third;
    }
}

class MultiSet
{
    private TreeMap<Integer,Integer> map = new TreeMap<>();
    public void insert(int k)
    {
        if (map.containsKey(k)) map.put(k, map.get(k)+1);
        else map.put(k,1);
    }
    public void remove(int k)
    {
        if (map.get(k) == 1) map.remove(k);
        else map.put(k, map.get(k)-1);
    }
    public boolean isEmpty()
    {
        return map.isEmpty();
    }
    public int firstKey()
    {
        return map.firstKey();
    }
}

public class GregorsSweep
{
    static final int TASKS = 55;
    static final int LEN = 2005;
    static final int INF = 100_000_000;
    static int[][][] dpA = new int[TASKS][TASKS][LEN];
    static int[][][] dpB = new int[TASKS][TASKS][LEN];
    static ArrayList<ArrayList<ArrayList<Triple<Integer,Integer,Integer>>>> intervalsA;
    static ArrayList<ArrayList<ArrayList<Triple<Integer,Integer,Integer>>>> intervalsB;
    static ArrayList<ArrayList<Integer>> events;

    static void init(int n, int a, int b)
    {
        //dpA = new int[a+1][b+1][n+1];
       // dpB = new int[a+1][b+1][n+1];
        intervalsA = new ArrayList<>(a+1);
        intervalsB = new ArrayList<>(a+1);
        for (int i = 0; i < a+1; ++i) {
            intervalsA.add(new ArrayList<>(b+1));
            intervalsB.add(new ArrayList<>(b+1));
            for (int j = 0; j < b+1; ++j)
            {
                intervalsA.get(i).add(new ArrayList<>());
                intervalsB.get(i).add(new ArrayList<>());
                for (int k = 0; k < n+1; ++k)
                {
                    dpA[i][j][k] = INF;
                    dpB[i][j][k] = INF;
                }
            }
        }
        events = new ArrayList<>();
        for (int i = 0; i <= n+1; ++i)
            events.add(new ArrayList<>());
    }

    static void updateDP(int[] dp, ArrayList<Triple<Integer,Integer,Integer>> intervals, int from, int to)
    {
        for (Triple<Integer,Integer,Integer> t : intervals)
        {
            events.get(t.first).add(t.third);
            events.get(t.second+1).add(-t.third);
        }
        MultiSet active = new MultiSet();
        for (int i = from; i <= to; i++)
        {
            for (int v: events.get(i))
            {
                if (v > 0)
                    active.insert(v);
                else
                    active.remove(-v);
            }
            if (!active.isEmpty())
                dp[i] = Math.min(dp[i], active.firstKey());
        }
        for (int i = from+1; i <= to; i++)
            dp[i] = Math.min(dp[i], dp[i-1]+1);
        for (int i = to-1; i >= from; i--)
            dp[i] = Math.min(dp[i], dp[i+1]+1);
        for (int i = from; i <= to+1; ++i)
            events.get(i).clear();
    }

    static Pair limitRange(int low, int high, int a, int b)
    {
        return new Pair<>(Math.max(low,a-b),Math.min(high,a+b));
    }

    static void performTaskA(int n, int i, int j, int posA, int posB, int nxtA, int val)
    {
        int stepsA = Math.abs(nxtA - posA) + 1;
        Pair<Integer,Integer> range = limitRange(nxtA+1, n, posB, stepsA);
        intervalsA.get(i+1).get(j).add(new Triple(range.first, range.second, val + stepsA));
    }

    static void performTaskB(int i, int j, int posA, int posB, int nxtB, int val)
    {
        int stepsB = Math.abs(nxtB - posB) + 1;
        Pair<Integer,Integer> range = limitRange(1, nxtB-1, posA, stepsB);
        intervalsB.get(i).get(j+1).add(new Triple(range.first, range.second, val + stepsB));
    }

    static void performTaskAB(int i, int j, int posA, int posB, int nxtA, int nxtB, int val)
    {
        if (nxtA > nxtB)
            return;
        int stepsA = Math.abs(nxtA - posA) + 1;
        int stepsB = Math.abs(nxtB - posB) + 1;
        dpA[i+1][j+1][nxtB] = Math.min(dpA[i+1][j+1][nxtB], val + Math.max(stepsA,stepsB));
        dpB[i+1][j+1][nxtA] = Math.min(dpB[i+1][j+1][nxtA], val + Math.max(stepsA,stepsB));
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a = sc.nextInt();
        int b = sc.nextInt();
        int[] taskA = new int[a+1];
        int[] taskB = new int[b+1];
        for (int i = 0; i < a; ++i)
            taskA[i] = sc.nextInt();
        for (int i = 0; i < b; ++i)
            taskB[i] = sc.nextInt();
        taskA[a] = 1;
        taskB[b] = n;
        init(n,a,b);
        dpA[0][0][n] = 1;
        dpB[0][0][1] = 1;
        for (int i = 0; i < a; i++)
        {
            for (int j = 0; j < b; j++)
            {
                updateDP(dpA[i][j], intervalsA.get(i).get(j), taskA[i]+1, n);
                updateDP(dpB[i][j], intervalsB.get(i).get(j), 1, taskB[j]-1);
                for (int posB = taskA[i]+1; posB <= n; posB++)
                {
                    performTaskA(n, i, j, taskA[i], posB, taskA[i+1], dpA[i][j][posB]);
                    performTaskB(i, j, taskA[i], posB, taskB[j+1], dpA[i][j][posB]);
                    performTaskAB(i, j, taskA[i], posB, taskA[i+1], taskB[j+1], dpA[i][j][posB]);
                }
                for (int posA = 1; posA < taskB[j]; posA++)
                {
                    performTaskA(n, i, j, posA, taskB[j], taskA[i+1], dpB[i][j][posA]);
                    performTaskB(i, j, posA, taskB[j], taskB[j+1], dpB[i][j][posA]);
                    performTaskAB(i, j, posA, taskB[j], taskA[i+1], taskB[j+1], dpB[i][j][posA]);
                }
            }
        }
        System.out.println(dpA[a-1][b-1][n]);
    }
}
