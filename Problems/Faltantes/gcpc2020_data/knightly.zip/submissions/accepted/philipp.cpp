#include <bits/stdc++.h>
using namespace std;

int main() {
	int m, c;
	cin >> m >> c;
	if(!m || !c) {
		cout << "0 0\n0" << endl;
		return 0;
	}

	map<int,int> potx, poty;
	while(m--) {
		int x, y;
		cin >> x >> y;
		potx[x]++;
		poty[y]++;
	}

	map<int,int> xcnt, ycnt;
	set<pair<int,int>> points;
	while(c--) {
		int x, y;
		cin >> x >> y;
		if(potx[x] > 1 || poty[y] > 1) {
			continue;
		}
		xcnt[x]++;
		ycnt[y]++;
		points.emplace(x,y);
	}

	pair<int,int> loc = {0,0};
	int mighty = 0;
	for(auto p : potx) {
		if(p.second != 1) {
			continue;
		}
		for(auto q : poty) {
			if(q.second != 1) {
				continue;
			}
			pair<int,int> thisloc = {p.first, q.first};
			int thisres = xcnt[p.first] + ycnt[q.first];
			if(points.count(thisloc)) {
				thisres--;
			}
			if(thisres > mighty) {
				mighty = thisres;
				loc = thisloc;
			}
		}
	}

	cout << loc.first << ' ' << loc.second << endl;
	cout << mighty << endl;
}
