#include <bits/stdc++.h>

using namespace std;

const int MAX = 1000000; // used to shift everything in positive direction.

long long id(int x, int y) {
	return ((long long) x) * (MAX * 3) + (long long)y;
}

int main() {
	// countings
	vector<int> msX(2 * MAX + 5), msY(2 * MAX + 5), csX(2 * MAX + 5), csY(2 * MAX + 5);
	int m, c;
	cin >> m >> c;
	int x, y;
	while (m--) {
		cin >> x >> y;
		msX[x+MAX]++; msY[y+MAX]++;
	}
	vector<int> bestXs, bestYs;
	unordered_set<long long> cs;
	
	int curBestX = 0, curBestY = 0;
	while (c--) {
		cin >> x >> y;
		x += MAX; y += MAX;
		if (msX[x] >= 2 || msY[y] >= 2) continue; // already mighty
		cs.insert(id(x, y));
		if (msX[x] == 1) {
			csX[x]++;
			if (csX[x] == curBestX) bestXs.push_back(x);
			else if (csX[x] > curBestX) {
				curBestX++;
				bestXs.clear();
				bestXs.push_back(x);
			}
		}
		if (msY[y] == 1) {
			csY[y]++;
			if (csY[y] == curBestY) bestYs.push_back(y);
			else if (csY[y] > curBestY) {
				curBestY++;
				bestYs.clear();
				bestYs.push_back(y);
			}
		}
	}
	if (curBestX + curBestY == 0) {
		cout << "0 0\n0" << endl;
	} else if (curBestX == 0) {
		cout << "0 " << bestYs[0]-MAX << "\n" << curBestY << endl;
	} else if (curBestY == 0) {
		cout << bestXs[0]-MAX << " 0\n" << curBestX << endl;
	} else {
		// check all possibilites (at most c different are non-optimal)
		for (int x : bestXs) for (int y : bestYs) {
			if (cs.find(id(x, y)) == cs.end()) { // optimal
				cout << x-MAX << " " << y-MAX << endl;
				cout << curBestX + curBestY << endl;
				return 0;
			}
		}
		cout << bestXs[0]-MAX << " " << bestYs[0]-MAX << endl;
		cout << curBestX + curBestY - 1<< endl;
	}
}
