#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ll m, c, _x, _y;
	cin >> m >> c;
	map<ll, ll> xm, ym, xc, yc;
	set<pair<ll, ll>> ms, cs;
	for (ll i = 0; i < m; ++i) {
		cin >> _x >> _y;
		++xm[_x];
		++ym[_y];
		ms.insert({_x, _y});
	}
	for (ll i = 0; i < c; ++i) {
		cin >> _x >> _y;
		if (xm[_x] < 2 && ym[_y] < 2) {
			++xc[_x];
			++yc[_y];
		}
		cs.insert({_x, _y});
	}
	ll max = -1;
	set<ll> xs;
	for (auto e : xc) if (e.second >= max && xm[e.first] == 1) 
		max = e.second, xs.insert(e.first);
	max = -1;
	set<ll> ys;
	for (auto e : yc) if (e.second >= max && ym[e.first] == 1) 
		max = e.second, ys.insert(e.first);
	if (xs.empty()) xs.insert(0);
	if (ys.empty()) ys.insert(0);
	max = -1;
	ll maxx = 0, maxy = 0, tmp;
	for (auto x : xs) for (auto y : ys) {
		tmp = xc[x] + yc[y];
		if (xm[x] != 1) tmp -= xc[x];
		if (ym[y] != 1) tmp -= yc[y];
		if (cs.find({x, y}) != cs.end()) --tmp;
		if (tmp > max) max = tmp, maxx = x, maxy = y;
	}
	if (max < 0) max = 0;
	cout << maxx << " " << maxy << endl << max << endl;
	return 0;
}
