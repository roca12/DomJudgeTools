/**
 * GCPC 2020 - Knightly Knowledge
 *
 * Count ordinary churches in each row and column,
 * place monument at location with maximal total count.
 */

#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_set>

#define MAX_NUM   1000
#define MAX_POS   1000000
#define POS_RANGE 2000001

using namespace std;

struct int2d { int x, y; };

int2d mpos[MAX_NUM], cpos[MAX_NUM];
short mnumx[POS_RANGE], mnumy[POS_RANGE];
short cnumx[POS_RANGE], cnumy[POS_RANGE];

vector<int> cids;
unordered_set<long long> clocs;

int main()
{
  // Read data
  int m, c;
  cin >> m >> c;
  for (int i = 0; i < m; i++)
    cin >> mpos[i].x >> mpos[i].y;
  for (int i = 0; i < c; i++)
    cin >> cpos[i].x >> cpos[i].y;

  // Adapt coordinates
  for (int i = 0; i < m; i++) {
    mpos[i].x += MAX_POS;
    mpos[i].y += MAX_POS;
  }
  for (int i = 0; i < c; i++) {
    cpos[i].x += MAX_POS;
    cpos[i].y += MAX_POS;
  }

  // Evaluate horizontal and vertical lines
  memset(mnumx, 0, POS_RANGE*sizeof(short));
  memset(mnumy, 0, POS_RANGE*sizeof(short));
  memset(cnumx, 0, POS_RANGE*sizeof(short));
  memset(cnumy, 0, POS_RANGE*sizeof(short));
  for (int i = 0; i < m; i++) {
    mnumx[mpos[i].x]++;
    mnumy[mpos[i].y]++;
  }
  for (int i = 0; i < c; i++) {
    int cx = cpos[i].x, cy = cpos[i].y;
    short nx = mnumx[cx], ny = mnumy[cy];
    if (nx < 2 && ny < 2 && (nx > 0 || ny > 0)) {
      cnumx[cx]++;
      cnumy[cy]++;
      cids.push_back(i);
      clocs.insert((long long)cx*(long long)POS_RANGE+(long long)cy);
    }
  }
  if (cids.empty()) {
    cout << 0 << " " << 0 << endl << 0 << endl;
    return 0;
  }

  // Find best locations
  vector<int> maxx, maxy;
  short maxnx = 0, maxny = 0;
  for (int i : cids) {
    int cx = cpos[i].x, cy = cpos[i].y;
    if (cnumx[cx] > maxnx) {
      maxx.clear();
      maxx.push_back(cx);
      maxnx = cnumx[cx];
    } else if (cnumx[cx] == maxnx) {
      maxx.push_back(cx);
    }
    if (cnumy[cy] > maxny) {
      maxy.clear();
      maxy.push_back(cy);
      maxny = cnumy[cy];
    } else if (cnumy[cy] == maxny) {
      maxy.push_back(cy);
    }
  }

  // Return location without ordinary church
  bool found = false;
  for (int x : maxx) {
    if (mnumx[x] == 0) continue;
    for (int y : maxy) {
      if (mnumy[y] == 0) continue;
      long long loc = (long long)x*(long long)POS_RANGE+(long long)y;
      if (clocs.find(loc) == clocs.end()) {
        cout << x-MAX_POS << " " << y-MAX_POS << endl;
        cout << cnumx[x]+cnumy[y] << endl;
        return 0;
      }
    }
  }

  // Return any location otherwise
  if (!found) {
    int x = maxx[0], y = maxy[0];
    cout << x-MAX_POS << " " << y-MAX_POS << endl;
    cout << cnumx[x]+cnumy[y]-1 << endl;
  }
  return 0;
}
