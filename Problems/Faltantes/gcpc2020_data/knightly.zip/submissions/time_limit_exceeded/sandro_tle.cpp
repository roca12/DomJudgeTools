/**
 * GCPC 2020 - Knightly Knowledge
 *
 * Exhaustive search for best location, check each
 * coordinate and evaluate number of ordinary churches
 * on horizontal and vertical line through that location.
 */

#include <stdlib.h>
#include <iostream>

#define MAX_NUM   1000
#define MAX_POS   1000000
#define POS_RANGE 2000001

using namespace std;

struct int2d { int x, y; };

int2d mpos[MAX_NUM], cpos[MAX_NUM];

int main()
{
  // Read data
  int m, c;
  cin >> m >> c;
  for (int i = 0; i < m; i++)
    cin >> mpos[i].x >> mpos[i].y;
  for (int i = 0; i < c; i++)
    cin >> cpos[i].x >> cpos[i].y;

  // Check all coordinates
  int xmax = 0, ymax = 0, cmax = 0;
  for (int x = -MAX_POS; x <= MAX_POS; x++) {
    for (int y = -MAX_POS; y <= MAX_POS; y++) {
      int mx = 0, my = 0;
      for (int i = 0; i < m && mx < 2; i++)
        if (mpos[i].x == x)
          mx++;
      for (int i = 0; i < m && my < 2; i++)
        if (mpos[i].y == y)
          my++;
      int cx = 0, cy = 0;
      if (mx == 1) {
        for (int i = 0; i < c; i++)
          if (cpos[i].x == x)
            cx++;
      }
      if (my == 1) {
        for (int i = 0; i < c; i++)
          if (cpos[i].y == y)
            cy++;
      }
      int c = cx + cy;
      if (mx == 1 && my == 1) {
        for (int i = 0; i < c; i++) {
          if (cpos[i].x == x && cpos[i].y == y) {
            c--; break; 
          }
        }
      }
      if (c > cmax) {
        xmax = x; ymax = y; cmax = c;
      }
    }
  }

  // Output solution
  cout << xmax << " " << ymax << endl << cmax << endl;
  return 0;
}
