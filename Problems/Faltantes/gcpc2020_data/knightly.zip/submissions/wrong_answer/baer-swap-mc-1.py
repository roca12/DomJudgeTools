#!/bin/python3
import sys

c, m = map(int, input().split(" "))
ms = [tuple(map(int, input().split(" "))) for _ in range(m)]
cs = [tuple(map(int, input().split(" "))) for _ in range(c)]

monsX = {}
monsY = {}

for x, y in ms:
	if x not in monsX:
		monsX[x] = 0
	if y not in monsY:
		monsY[y] = 0
	monsX[x] += 1
	monsY[y] += 1

gainX = {123456: 0}
gainY = {123456: 0}
for x, y in cs:
	# already magic
	if (x in monsX and monsX[x] >= 2) or (y in monsY and monsY[y] >= 2):
		continue
	if x in monsX and monsX[x] == 1:
		if x not in gainX:
			gainX[x] = 0
		gainX[x] += 1
	if y in monsY and monsY[y] == 1:
		if y not in gainY:
			gainY[y] = 0
		gainY[y] += 1
		
rows = [(gainX[row], row) for row in gainX]
cols = [(gainY[col], col) for col in gainY]

rows = list(reversed(sorted(rows)))
cols = list(reversed(sorted(cols)))

def get(x, y):
#	if (x, y) in ms:
#		return None
	g = gainX[x] + gainY[y]
	if (x, y) in cs and monsX[x] == 1 and monsY[y] == 1:
		g -= 1
	return g

def found(x, y, res):
	print(x, y)
	print(res)
	sys.exit(0)

# try all best combinations
# there are at most m+c non-perfect
ri = 0
nearly = None
while ri < len(rows) and rows[ri][0] == rows[0][0]:
	ci = 0
	while ci < len(cols) and cols[ci][0] == cols[0][0]:
		res = get(rows[ri][1], cols[ci][1])
		if res != None:
			if res == rows[ri][0] + cols[ci][0]:
				found(rows[ri][1], cols[ci][1], res)
			elif res == rows[ri][0] + cols[ci][0] - 1:
				nearly = (rows[ri][1], cols[ci][1], res)
		ci += 1
	ri += 1

if nearly != None:
	found(nearly[0], nearly[1], nearly[2])
