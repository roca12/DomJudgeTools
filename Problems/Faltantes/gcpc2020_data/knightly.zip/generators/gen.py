#!/bin/python3

import random

MIN_CO = -1e6
MAX_CO = 1e6

MAX_C = 1000
MAX_M = 1000

random.seed(53)

def write(fn, ms, cs):
	random.shuffle(ms)
	random.shuffle(cs)
	with open("../data/secret/%s.in" % fn, "w") as outf:
		outf.write("%d %d\n" % (len(ms), len(cs)))
		for x in ms + cs:
			outf.write("%d %d\n" % x)

config = [
	{"coord": MAX_CO, "c": MAX_C, "m": MAX_M, "count": 2, "name": "20-rnd_%02d_max"},
	{"coord": MAX_CO, "c": 5, "m": 5, "count": 2, "name": "21-rnd_%02d_maxsparse"},
	{"coord": 1000, "c": MAX_C, "m": MAX_M, "count": 2, "name": "22-rnd_%02d_dense"},
	{"coord": 200, "c": MAX_C, "m": MAX_M, "count": 2, "name": "23-rnd_%02d_dense2"},
	{"coord": 200, "c": MAX_C, "m": 5, "count": 2, "name": "24-rnd_%02d_manyc"},
	{"coord": 200, "c": 5, "m": MAX_M, "count": 2, "name": "25-rnd_%02d_manym"},
	{"coord": 200, "c": 5, "m": 5, "count": 1, "name": "26-rnd_%02d_05"},
	{"coord": 200, "c": 10, "m": 10, "count": 1, "name": "27-rnd_%02d_10"},
	{"coord": 200, "c": 50, "m": 50, "count": 1, "name": "28-rnd_%02d_50"}
]

for c in config:
	print(c["name"])
	for ci in range(c["count"]):
		fn = c["name"] % (ci+1)
		ms = []
		while len(ms) < c["m"]:
			a = random.randint(-c["coord"], c["coord"])
			b = random.randint(-c["coord"], c["coord"])
			if (a, b) not in ms:
				ms += [(a, b)]
		cs = []
		while len(cs) < c["c"]:
			a = random.randint(-c["coord"], c["coord"])
			b = random.randint(-c["coord"], c["coord"])
			if (a, b) not in ms and (a, b) not in cs:
				cs += [(a, b)]
		write(fn, ms, cs)
