Given:
----------
m (artificial) landmarks (2D points)
p points of interest (2D points)
A point is 'magical' if it lines on the infinite straight horizontal or vertical line that runs through at least two landmarks 

Task:
----------
Build exactly one landmark to maximize the number of magical points of interest.
(landmarks can be placed on top of points of interest to keep it simple)


Sample:
---------
landmarks:
0/0, 1/0, 3/1
points:
0/1, 1/2, 1/3, 1/-1
Solution: 1/1 to get 4 magical POIs


Solution:
----------
For each row / column find the number of landmarks and POIs.
  * landmarks >= 2: POIs already magical
  * landmarks = 0: POIs cannot become magical as no line will exist with only 1 additional landmark
  * landmarks = 1: we can increase number of magical POIs by #POIs when placing a landmark in this row / column
Now, take the cross point of the best row and best column.
Pitfall: If there is a POI at this cross point, it is counted twice -> check all best rows / columns or subtract 1 from solution

Difficulty:
5-10% unsolved depending on samples

Complexity:
Several ways / datastructures to compute the solution exist.
I suggest to
  * forbid trying every possible position
  * maybe forbid iterating over all rows/columns even if they are empty (-> large coordinates)
  * allow other non-optimal implementations.
Best I can think of at the moment is about n * log(n) with n = p + m, and I would allow at least n^2*log(n).
