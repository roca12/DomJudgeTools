#include <bits/stdc++.h>
#include "validate.h"
using namespace std;

int main(int argc, char **argv) {
	init_io(argc,argv);
	
	int m, c; judge_in >> m >> c;
	
	set<pair<int, int>> ms;
	set<pair<int, int>> cs;
	map<int, int> gainX, gainY; // churches in this row / column
	map<int, int> monsX; // monuments in this row
	map<int, int> monsY; // monuments in this column
	
	// Read monuments
	for (int i = 0; i < m; i++) {
		int x, y;
		judge_in >> x >> y;
		ms.insert(make_pair(x, y));
		monsX[x]++;
		monsY[y]++;
	}
	// Read churches
	for (int i = 0; i < c; i++) {
		int x, y;
		judge_in >> x >> y;
		cs.insert(make_pair(x, y));
		if (monsX[x] == 1 && monsY[y] < 2) gainX[x]++;
		if (monsY[y] == 1 && monsX[x] < 2) gainY[y]++;
	}

	int x, y, count;
	author_out >> x >> y >> count;
	if (!author_out) {
		wrong_answer("Wrong answer: Missing numbers");
	}
	
	if (x < -1e6 || x > 1e6 || y < -1e6 || y > 1e6) {
		wrong_answer("Wrong answer: Coordinates out of range");
	}

	/*if (ms.find(make_pair(x, y)) != ms.end()) {
		wrong_answer("Wrong answer: New monument coincides with an existing monument");
	}*/
	
	int solx, soly, solCount;
	judge_ans >> solx >> soly >> solCount;
	
	if (solCount < count) {
		wrong_answer("Wrong answer: Team found a 'better' solution with %d at (%d, %d)", count, x, y);
	} else if (solCount > count) {
		wrong_answer("Wrong answer: Team did not find the best answer");
	}

	assert(solCount == count);
	
	int gain = 0;
	for (auto & p : cs) {
		if (monsX[p.first] < 2 && monsY[p.second] < 2) { // not magic before
			if ((monsX[p.first] == 1 && x == p.first) || (monsY[p.second] == 1 && y == p.second)) {
				gain++;
			}
		}
	}

	int gain2 = gainX[x] + gainY[y];
	if (cs.find(make_pair(x, y)) != cs.end() && monsX[x] == 1 && monsY[y] == 1) {
		gain2--; // counted twice
	}
	assert(gain == gain2);
	if (gain < count) {
		wrong_answer("Wrong answer: Team counted too much");
	} else if (gain > count) {
		wrong_answer("Wrong answer: Team counted too less");
	}
	
	string junk;
	if (author_out >> junk) {
		wrong_answer("Wrong answer: found trailing output.\n");
	}

	accept();
}

