Task:
Given an arrangement of n Domino pieces without numbers, find a way to assign numbers to each side of each piece (or print impossible). You may use all integer numbers (not just 1 to 6), but each only twice.
A numbering is valid if each side is adjacent to a side of another piece with the same number.


Complexity and Limits:
n <= 5000
Expected runtime: O(n²)


Solution:
The problem can be transformed to a graph. Each side of each Domino piece is a node and there is an edge between two nodes if they are adjacent (i.e. Manhattan distance = 1) and don't belong to the same piece.
The graph is bipartite: Imagine a (large) checker board laid over the coordinate grid. The graph can be partitioned into black and white nodes with each edge connecting a black and a white node.
Find a perfect bipartite matching on this graph. When matched nodes are assigned the same number, this results in a valid numbering.

Note that each valid numbering corresponds to such a perfect matching. Therefore, whenever a solution exists, this algorithm will find one.


Difficulty:
80%


Sources etc.:
This problem is similar to the disjoint cycle cover problem.
