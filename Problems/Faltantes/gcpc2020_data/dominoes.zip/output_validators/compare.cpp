#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

constexpr int CORRECT = 42;
constexpr int INCORRECT = 43;

struct position {
    ll x, y;
};

position operator+(position a, position b)
{
    return {a.x + b.x, a.y + b.y};
}

bool operator<(position a, position b)
{
    return make_pair(a.x, a.y) < make_pair(b.x, b.y);
}

bool operator==(position a, position b)
{
    return a.x == b.x && a.y == b.y;
}

bool operator!=(position a, position b)
{
    return a.x != b.x || a.y != b.y;
}

typedef pair<position, position> piece;

int main(int argc, char* argv[])
{
    assert(argc == 4);

    ifstream input(argv[1]);
    ifstream answer(argv[2]);
    ofstream debug_output(argv[3] + string("/judgemessage.txt"));

    string possible;
    answer >> possible;
    if (possible == "impossible") {
        string s;
        if (!(cin >> s)) {
            debug_output << "Output is empty." << endl;
            return INCORRECT;
        }
        debug_output << "s: " << s << endl;
        if (s != "impossible") {
            debug_output << "Expected impossible, but got " << s << endl;
            return INCORRECT;
        }

    } else {

        position directions[4] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
        map<position, int> grid;
        map<position, int> pieces;
        map<int, int> numbers_used;

        int n;
        input >> n;
        for (int i = 0; i < 2 * n; ++i) {
            int x, y;
            input >> x >> y;
            position pos = {x, y};
            pieces[pos] = i / 2;
            int color;
            if ((!(cin >> color)) || color < 0 || color > 1000 * 1000) {
                debug_output << "Missing or invalid numbering for stone " << i / 2 << endl;
                return INCORRECT;
            }
            grid[pos] = color;
            ++numbers_used[color];
            if (numbers_used[color] > 2) {
                debug_output << "Label " << color << " used more than twice." << endl;
                return INCORRECT;
            } else if (numbers_used[color] == 2) {
                bool found = false;
                for (position dir: directions) {
                    if (pieces[pos] == pieces[pos + dir]) continue;
                    if (grid[pos] == grid[pos + dir]) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    debug_output << "No matching piece at position (" << pos.x << ", " << pos.y << ")." << endl;
                    return INCORRECT;
                }
            }
        }
        if (numbers_used.size() != n) {
            debug_output << "Some labels were used only once." << endl;
            return INCORRECT;
        }
    }

    char x;
    if (cin >> x) {
        debug_output << "Too much output." << endl;
        return INCORRECT;
    }

    return CORRECT;
}
