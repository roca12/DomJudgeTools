import java.util.*;

class Point
{
    int first;
    int second;
    Point(int first, int second)
    {
        this.first = first;
        this.second = second;
    }
    @Override
    public int hashCode()
    {
        return Objects.hash(first,second);
    }
    @Override
    public boolean equals(Object o)
    {
        Point other = (Point) o;
        return first == other.first && second == other.second;
    }
}

public class Gregors
{
    static Boolean findPath(int i, ArrayList<ArrayList<Integer>> g, ArrayList<Boolean> visited, ArrayList<Integer> match)
    {
        if (visited.get(i)) return false;
        visited.set(i,true);
        for (int j : g.get(i))
        {
            if (match.get(j) == -1 || findPath(match.get(j), g, visited, match))
            {
                match.set(i,j);
                match.set(j,i);
                return true;
            }
        }
        return false;
    }

    static int maxBipartiteMatching(int numLeft, ArrayList<ArrayList<Integer>> g, ArrayList<Integer> match)
    {
        ArrayList<Boolean> visited = new ArrayList<>();
        for (int i = 0; i < g.size(); ++i) match.add(-1);
        int cnt = 0;
        for (int i = 0; i < numLeft; ++i)
        {
            visited.clear();
            for (int j = 0; j < numLeft; ++j) visited.add(false);
            if (findPath(i,g,visited,match)) cnt++;
        }
        return cnt;
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        HashMap<Point,Integer> ids = new HashMap<>();
        ArrayList<Point> points = new ArrayList<>();
        for (int i = 0; i < n; ++i)
        {
            int x1 = sc.nextInt();
            int y1 = sc.nextInt();
            int x2 = sc.nextInt();
            int y2 = sc.nextInt();
            Point p1 = new Point(x1,y1);
            Point p2 = new Point(x2,y2);
            points.add(p1); points.add(p2);
            ids.put(p1,i); ids.put(p2,n+i);
            if ((x1 + y1) % 2 == 1)
            {
                int z1 = ids.get(p1);
                int z2 = ids.get(p2);
                ids.put(p1,z2);
                ids.put(p2,z1);
            }
        }
        ArrayList<ArrayList<Integer>> g = new ArrayList<>();
        for (int i = 0; i < 2*n; ++i) g.add(new ArrayList<>());
        for (Map.Entry<Point, Integer> entry : ids.entrySet())
        {
            Point p = entry.getKey();
            int id = entry.getValue();
            if (id >= n) continue;
            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 1; dy++)
                {
                    Point q = new Point(p.first + dx, p.second + dy);
                    if (Math.abs(dx) != Math.abs(dy) && ids.containsKey(q) && id != ids.get(q) - n)
                        g.get(id).add(ids.get(q));
                }
            }
        }
        int cnt;
        ArrayList<Integer> match = new ArrayList<>();
        cnt = maxBipartiteMatching(n,g,match);
        if (cnt < n) System.out.println("impossible");
        else {
            for (int i = 0; i < points.size(); ++i)
            {
                Point p = points.get(i);
                if (ids.get(p) < n) System.out.print(ids.get(p));
                else System.out.print(match.get(ids.get(p)));
                if (i % 2 == 1) System.out.println("");
                else System.out.print(" ");
            }
        }
    }
}
