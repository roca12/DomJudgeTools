#include <bits/stdc++.h>
using namespace std;

int main() {
	int n; cin >> n;
	
	if (n == 2 || n == 3 || n == 5) {
		printf("impossible\n");
	} else if (n == 1) {
		printf("1 1 1\nA 0 0 U\n");
	} else if (n%2 == 0) {
		printf("%d %d %d\n", n/2-1, 1, n/2);
		printf("A 1 0 U\n");
		for (int i = 0; i < n/2; i++) {
			printf("B 0 %d U\n", i);
			if (i > 0) printf("B 0 %d D\n", i);
		}
	} else {
		int a = (n-5)/2;
		printf("%d %d %d\n", a, 2, 2*a+2);
		printf("A 2 0 U\n");
		printf("A %d 0 U\n", a+2);
		printf("A 2 %d U\n", a);
		printf("A 2 %d D\n", a);
		for (int i = 0; i < (n-3)/2; i++) {
			printf("B 0 %d U\n", 2*i);
			if (i > 0) printf("B 0 %d D\n", 2*i);
		}
	}
}
