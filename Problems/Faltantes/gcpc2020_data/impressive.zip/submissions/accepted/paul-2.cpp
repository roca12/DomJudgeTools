#include <bits/stdc++.h>
using namespace std;

// Finds the smallest solution of the following kind:
// Cut out a q*q triangle from a p*p triangle and replace it with a r*r triangle.

struct solution {
	int a, b, c, p, q, r;

	solution(int p, int q, int r): p(p), q(q), r(r) {
		a = r, b = q;
		int g = gcd(a,b);
		a /= g, b /= g;
		c = p*a;
	}
	
	bool operator<(const solution &s) const { return c < s.c; }

	void print() {
		cout << a << " " << b << " " << c << endl;
		
		for (int i = 0; i < p; i++) {
			for (int j = 0; i+j < p; j++) {
				if (i+j < q) continue;
				cout << "A " << i*a << " " << j*a << " U" << endl;
				if (j > 0) cout << "A " << i*a << " " << j*a << " D" << endl;
			}
		}

		for (int i = 0; i < r; i++) {
			for (int j = 0; i+j < r; j++) {
				cout << "B " << i*b << " " << j*b << " U" << endl;
				if (j > 0) cout << "B " << i*b << " " << j*b << " D" << endl;
			}
		}
	}
};

int main() {
	int n; cin >> n;
	
	solution best(INT_MAX,1,1);

	for (int r = 1; r*r <= n; r++) {
		int m = n - r*r;
		if (m == 0) best = min(best, solution(1,1,r));
		for (int k = 1; k*k < m; k++) if (m%k == 0) {
			int p = (m/k+k)/2, q = (m/k-k)/2;
			if (p*p - q*q + r*r != n) continue;
			best = min(best, solution(p,q,r));
		}
	}
	
	if (best.p == INT_MAX) {
		cout << "impossible" << endl;
	} else {
		best.print();
	}
}
