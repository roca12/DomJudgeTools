#include <bits/stdc++.h>
using namespace std;

void L(int n) {
	for(int i = 0; i < n; i++) {
		if(i % 2 == 0) {
			cout << "B " << i << " 0 U" << endl;
		} else {
			cout << "B " << i-1 << " 2 D" << endl;
		}
	}
}

int main() {
	int n;
	cin >> n;
	if(n == 1) {
		cout << "1 1 1\nA 0 0 U" << endl;
		return 0;
	}
	if(n == 2 || n == 3 || n == 5) {
		cout << "impossible" << endl;
		return 0;
	}

	if(n % 2 == 0) {
		cout << n-2 << " 2 " << n << endl;
		cout << "A 0 2 U" << endl;
		L(n-1);
	} else {
		int size = (n - 5) / 2;
		cout << size << " 2 " << n-3 << endl;
		cout << "A 0 2 U" << endl;
		cout << "A " << size << " 2 U" << endl;
		cout << "A 0 " << 2+size << " U" << endl;
		cout << "A 0 " << 2+size << " D" << endl;
		L(n-4);
	}
}
