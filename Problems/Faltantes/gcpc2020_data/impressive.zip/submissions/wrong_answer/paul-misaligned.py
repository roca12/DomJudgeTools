#!/usr/bin/env python3

n = int(input())

if n == 2 or n == 3 or n == 5:
    print('impossible')
elif n == 1:
    print('1 1 1')
    print('A 0 0 U')
elif n%2 == 0:
    print('{} {} {}'.format(n//2-1, 1, n//2))
    print('A 1 0 U')
    for i in range(n//2):
        print('B 0 {} U'.format(i))
        if i > 0: print('B {} 0 D'.format(i))
else:
    a = (n-5)//2;
    print('{} {} {}'.format(a, 2, 2*a+2))
    print('A 2 0 U')
    print('A {} 0 U'.format(a+2))
    print('A 2 {} U'.format(a))
    print('A 2 {} D'.format(a))
    for i in range((n-3)//2):
        print('B 0 {} U'.format(2*i))
        if i > 0: print('B 0 {} D'.format(2*i))
