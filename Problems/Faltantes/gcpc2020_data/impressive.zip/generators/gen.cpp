#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve(ll n, string s) {
	ofstream out;
	cerr << "writing file secret/generated/" << s << ".in" << endl;
	out.open("secret/generated/" + s + ".in", ios::out | ios::trunc);
	out << n << endl;
	out.close();

	ofstream aout;
	cerr << "writing file secret/generated/" << s << ".ans" << endl;
	aout.open("secret/generated/" + s + ".ans", ios::out | ios::trunc);
	if (n == 1) aout << "1 1 1" << endl << "A 0 0 U" << endl;
	else if (n % 2) {
		if (n < 7) aout << "impossible" << endl;
		else {
			ll x = (2 * (n - 3) - 4) / 2;
			aout << 4 << " " << x << " " << 2 * (n - 3) << endl << "B 0 4 U" << endl << "B " << x << " 4 U" << endl << "B 0 " << x + 4 << " D" << endl << "B 0 " << x + 4 << " U" << endl;
			for (ll i = 0; i < n - 4; ++i) aout << "A " << i / 2 * 4 << (i % 2 ? " 4 D" : " 0 U") << endl;
		}
	} else {
		if (n < 4) aout << "impossible" << endl;
		else {
			aout << 1 << " " << n / 2 - 1 << " " << n / 2 << endl << "B 0 1 U" << endl;
			for (ll i = 0; i < n - 1; ++i) aout << "A " << i / 2 << (i % 2 ? " 1 D" : " 0 U") << endl;
		}
	}
	aout.close();
}

int main() {
	for (ll i = 1; i < 17; ++i) {
		stringstream ss;
		ss << setw(2) << setfill('0') << i << "_" << i; 
		solve(i, ss.str());
	}
	solve(70, "17_70");
	solve(80, "18_80");
	solve(90, "19_90");
	solve(100, "20_100");
	solve(998, "21_998");
	solve(999, "22_999");
	solve(1000, "23_1000");
	mt19937_64 eng;
	uniform_int_distribution<ll> dist(17,997);
	for (ll i = 0; i < 17; ++i) {
		stringstream ss;
		ss << 24 + i << "_rand";
		solve(dist(eng), ss.str());
	}
	return 0;
}
