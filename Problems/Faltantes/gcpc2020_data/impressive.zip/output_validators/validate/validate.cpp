#include <bits/stdc++.h>
#include "validate.h"
using namespace std;
typedef long long ll;
ll n, l[2], c, x, y, i = 0;
__int128 area = 0;

struct Triangle {
	ll s, x, y;
	bool up;

	Triangle(ll _s, ll _x, ll _y, bool _up) : s(_s), x(_x), y(_y), up(_up) {}
};

vector<Triangle> tris;

void check(ll x, ll lo, ll hi) {
	if (x > hi) wrong_answer("Value exceeds limit!");
	if (x < lo) wrong_answer("Value is lower than limit!");
}

bool contained(ll c, ll s, ll x, ll y, bool up) {
	if (up) {
		if (x + y + s <= c) return true;
		else return false;
	} else return contained(c, s, x + s, y - s, true) && y >= s
			&& contained(c, s, x, y, true);
}

bool intersect(ll a, ll ax, ll ay, bool aup, ll b, ll bx, ll by, bool bup) {
	if (aup && bup) return ax < bx + b && ax + a > bx && ay < by + b && ay + a > by && ax + ay + a > bx + by && ax + ay < bx + by + b;
	else if (aup && !bup) return ax < bx + b && ay < by && ax + ay + a > bx + by;
	else if (!aup && !bup) return ax < bx + b && ax + a > bx && ay - a < by && ay > by - b && ax + ay + a > bx + by && ax + ay < bx + by + b;
	else return intersect(b, bx, by, bup, a, ax, ay, aup);
}

int main(int argc, char **argv) {
	init_io(argc, argv);
	char s, d;
	judge_in >> n;
	if (n == 2 || n == 3 || n == 5) {
		string a; 
		author_out >> a;
		transform(begin(a), end(a), begin(a), [](char c) { return tolower(c); });
		if (a == "impossible") {
			string junk;
			if (author_out >> junk) wrong_answer("Trailing output after 'impossible'");
			accept();
		}
		else wrong_answer("Expected impossible");
	}
	author_out >> l[0] >> l[1] >> c;
	check(c, 1, 1e9);
	check(l[0], 1, c);
	check(l[1], 1, c);
	while (author_out >> s >> x >> y >> d) {
		s = toupper(s);
		check(s, 'A', 'B');
		check(x, 0, c);
		check(y, 0, c);
		d = toupper(d);
		if (d != 'U' && d != 'D') wrong_answer("Direction must be either U or D");
		if (++i > n) wrong_answer("Too many triangles!");
		auto t = Triangle(l[s - 'A'], x, y, d == 'U');
		if (!contained(c, t.s, t.x, t.y, t.up)) wrong_answer("Triangle not contained within large triangle!");
		for (auto u : tris) {
			if (intersect(t.s, t.x, t.y, t.up, u.s, u.x, u.y, u.up))
				wrong_answer("Intersecting triangles!");
		}
		tris.push_back(t);
		area += l[s - 'A'] * l[s - 'A'];
	}
	if (i != n) wrong_answer("Too few triangles!");
	if (area != c * c) wrong_answer("Uncovered areas!");
	accept();
}
