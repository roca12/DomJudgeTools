# Problem
Given a positive integer $`n`$, determine if it is "cute".

> A cute number means a positive integer n such that some square admits a dissection into n squares of no more than two different sizes, without other restrictions.[1]

# Solution
> It can be shown that aside from 2,3, and 5, every positive integer is cute.[1]

## Key Insight
Any square can be dissected into 4, 6, or 8 squares as follows:
```
 __ __
|__|__|
|__|__|

 __ __ __
|__|__|__|
|     |__|
|_____|__|

 __ __ __ __
|__|__|__|__|
|        |__|
|        |__|
|________|__|
```

From there, the largest one of the sub-squares can always be dissected into 4 smaller ones, increasing the total number of sub-squares by 3.
Thus any square can be dissected into $`3k+4, 3k+6, 3k+8`$ smaller squares, where the smaller squares have no more than two different sizes.

This covers every positive integer except 2, 3, and 5, which are impossible.

# Difficulty
40-50%

# Constraints
Arbitrarily large numbers are possible for $`n`$, since only a constant time check is necessary.

# Authors
* Nathan Maier <nathan.maier@uni-ulm.de>

# References
1. https://en.wikipedia.org/wiki/Squaring_the_square#No_more_than_two_different_sizes
