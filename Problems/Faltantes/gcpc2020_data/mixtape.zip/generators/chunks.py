#!/usr/bin/python3
import math
import random
import sys

# Split the range [1..n] into k chunks and rearrange them.

n, k, s = map(int, sys.argv[1:4])
random.seed(s)

chunks = [[]]
splits = random.sample(range(n-1), k-1)
for i in range(n):
    chunks[-1].append(i)
    if i in splits:
        chunks.append([])

def rearrange(xs):
    mode = random.randint(0,2)
    if mode == 1:
        xs.reverse()
    if mode == 2:
        random.shuffle(xs)

for xs in chunks:
    rearrange(xs)

rearrange(chunks)

perm = [x+1 for xs in chunks for x in xs]

print(n)
print(' '.join(map(str, perm)))
