#!/usr/bin/python3
import sys

n = int(sys.argv[1])

print(n)
print(' '.join(map(str, range(n,0,-1))))
