#include <bits/stdc++.h>
using namespace std;

template<typename F>
void backtrack(int n, int k, F cont, int i, vector<int> v) {
	if (int(v.size()) == k) {
		cont(v);
		return;
	}

	for (; i < n; i++) {
		v.push_back(i);
		backtrack(n, k, cont, i, v);
		v.pop_back();
	}
}

int main() {
	int n; cin >> n;

	vector<int> perm(n), pos(n);
	for (int &x: perm) cin >> x, x--;
	for (int i = 0; i < n; i++) pos[perm[i]] = i;

	vector<int> base_length(n);
	base_length[0] = 1;
	for (int i = 1; i < n; i++) {
		base_length[i] = base_length[i-1];
		if (pos[i] < pos[i-1]) base_length[i]++;
	}
	
	auto solve = [&](vector<int> jumps) {
		vector<int> length(n);
		int j = 0;
		for (int i = 0; i < n; i++) {
			while (j < int(jumps.size()) && jumps[j] == i) j++;
			length[i] = base_length[i] + j;
		}
		
		vector<string> res(n);
		res[0] = "1" + string(length[perm[0]]-1, '0');

		for (int i = 1; i < n; i++) {
			int x = length[perm[i-1]];
			int y = length[perm[i]];
			
			if (x < y) {
				res[i] = res[i-1] + string(y-x,'0');
			} else {
				res[i] = res[i-1].substr(0,y);
				for (int k = y-1; k >= 0; k--) {
					if (res[i][k]++ == '9') res[i][k] = '0';
					else break;
				}
				if (res[i] == string(y,'0')) return;
			}
		}

		for (string s: res) cout << s << endl;
		exit(0);
	};

	for (int k = 0; ; k++) {
		backtrack(n, k, solve, 0, {});
	}
}
