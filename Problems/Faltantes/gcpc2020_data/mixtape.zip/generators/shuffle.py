#!/usr/bin/python3
import random
import sys

n, s = map(int, sys.argv[1:3])
random.seed(s)

p = list(range(1,n+1))
random.shuffle(p)

print(n)
print(' '.join(map(str, p)))
