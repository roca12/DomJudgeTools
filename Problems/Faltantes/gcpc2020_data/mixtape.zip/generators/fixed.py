#!/usr/bin/python3
import math
import sys

n, k = map(int, sys.argv[1:3])

p, q = [], list(range(1,n+1))

for i in range(n):
    fac = math.factorial(n-1-i)
    j, k = divmod(k, fac)
    p += [q[j]]
    q = q[:j] + q[j+1:]

print(n)
print(' '.join(map(str, p)))
