Schwierigkeit: 15% ungelöst

Lösung:

  Die i-te Zahl setzt sich aus drei Teilen zusammen:

     1   i 0..0
    |-|---|----|
     a  b    c

  a) führende 1, b) i (feste Breite, ggf. mit 0en davor), c) Suffix aus p_i 0en

  Diverse andere Lösungen sind möglich.

Komplexität:
  
  O(n^2), da die Zahlen O(n) Ziffern haben. Constraints sollten hier
  großzügig sein, da es keine TLE-Submissions gibt, die man ausschließen müsste.
