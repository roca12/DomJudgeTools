import java.util.*;

public class Paul {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			System.out.format("1%05d4", i);
			int x = sc.nextInt();
			while (x --> 0) System.out.print('7');
			System.out.println();
		}
	}
}
