#include <bits/stdc++.h>
using namespace std;

int main() {
	int n; cin >> n;

	// add some randomness to put the output checker to the test
	srand(n);
	char c = '1' + rand() % 9, d = '0' + rand() % 10;

	for (int i = 0; i < n; i++) {
		int k; cin >> k;
		printf("%c%02d%s\n", c, i, string(k,d).c_str());
	}
}
