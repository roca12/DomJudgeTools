#!/usr/bin/python3
input()
for i, x in enumerate(input().split()):
    print(f'1{i:02}' + '0'*int(x))
