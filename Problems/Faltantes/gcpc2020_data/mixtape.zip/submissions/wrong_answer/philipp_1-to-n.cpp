#include <bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++) {
		int p;
		cin >> p;
		cout << 1 << i/10 << i%10;
		while(p--) {
			cout << 0;
		}
		cout << ' ';
	}
}
