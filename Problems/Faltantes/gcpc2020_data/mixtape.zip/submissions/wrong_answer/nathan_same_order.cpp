#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ll n, p;
	cin >> n;
	for (ll i = 0; i < n; ++i) {
		cin >> p;
		printf("1%03d%03d\n", i, p);
	}
	return 0;
}
