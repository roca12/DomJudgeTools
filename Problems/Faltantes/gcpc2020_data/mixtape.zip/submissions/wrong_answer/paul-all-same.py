#!/usr/bin/python2
n = int(raw_input())
print(' '.join(['42'] * n))
