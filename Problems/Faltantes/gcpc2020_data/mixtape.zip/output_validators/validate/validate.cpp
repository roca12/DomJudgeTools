#include <bits/stdc++.h>
#include "validate.h"
using namespace std;

const int MAX_DIGITS = 1000;

void read_number(string &num) {
	if (!(author_out >> num)) {
		wrong_answer("Wrong answer: expected more numbers.\n");
	}
	
	for (char c: num) if (c < '0' || c > '9') {
		wrong_answer("Wrong answer: number contains an invalid digit.\n");
	}
	
	if (num[0] == '0') {
		wrong_answer("Wrong answer: number starts with 0.\n");
	}
	
	if (int(num.size()) > MAX_DIGITS) {
		wrong_answer("Wrong answer: number is too large.\n");
	}
}

int main(int argc, char **argv) {
	init_io(argc,argv);
	
	int n; judge_in >> n;
	
	vector<int> p(n);
	for (int i = 0; i < n; i++) {
		judge_in >> p[i]; p[i]--;
	}

	vector<string> ans(n);
	for (string &num: ans) {
		read_number(num);
	}

	if (!is_sorted(begin(ans), end(ans))) {
		wrong_answer("Wrong answer: the numbers need to be given in lexicographic order.\n");
	}

	// sort numbers by value
	sort(begin(ans), end(ans), [&](string a, string b) {
		if (a.size() != b.size()) return a.size() < b.size();
		return a < b;
	});

	for (int i = 0; i+1 < n; i++) {
		if (ans[i] == ans[i+1]) {
			wrong_answer("Wrong answer: the given numbers are not distinct.\n");
		}
	}
	
	map<string,int> rank;
	for (int i = 0; i < n; i++) {
		rank[ans[i]] = i;
	}

	// sort numbers lexicographically
	sort(begin(ans), end(ans));

	vector<int> q(n);
	for (int i = 0; i < n; i++) {
		q[i] = rank[ans[i]];
	}
	
	if (p != q) {
		wrong_answer("Wrong answer: the number sequence does not match the given permutation.\n");
	}

	string junk;
	if (author_out >> junk) {
		wrong_answer("Wrong answer: found trailing output.\n");
	}

	accept();
}

