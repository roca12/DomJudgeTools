--Bookshelf Building--

Check whether $n$ books with different heights and widths (but same depths) can be placed inside a bookshelf. The bookshelf is of rectangular shape with width $x$ and height $y$. You may (but do not have to) put one infinitely thin board horizontally inside the shelf at positions $1,2,...,y-1$. Books cannot be flipped or stacked on top of each other, i.e., their width and height must be aligned with the bookshelf.

If it is possible to place the books in the bookshelf, output the height of the board or -1 if you do not want/need/can use it. Otherwise, output impossible.


--Solution--
- W.l.o.g. place the tallest book in the bottom left corner of the shelf. 
- You can safely install the board at the height of the tallest book. 
- Greedily place all books in the lower section of the shelf that do not fit in the upper section. 
- For the remaining capacity in the lower section, solve a knapsack problem -- the more you fit into the lower section, the more space you have left in the upper section.
- Place all remaining books in the upper section.
- Complexity: O(n x)


--Difficulty--
30% unsolved
