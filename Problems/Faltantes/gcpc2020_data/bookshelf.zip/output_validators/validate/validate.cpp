#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include "validate.h"
using namespace std;

int main(int argc, char **argv) 
{
	init_io(argc,argv);

	string res; judge_ans >> res;
	if(res == "impossible") 
	{
		string teamres; 
		author_out >> teamres;
		if(teamres != "impossible")
			wrong_answer("WA: supposed to be impossible, team says otherwise");
	}
	else
	{
		int judgeres = stoi(res);
		int teamres; 
		author_out >> teamres;
		if(author_out.fail())
			wrong_answer("WA: team did not output an integer");

		// team's output matches exactly the judge's outputs
		if (judgeres == teamres)
			accept();

		// read input
		int n,x,y; judge_in >> n >> x >> y;
		vector<pair<int,int>> books;
		int totalWidth = 0;
		for (int i = 0; i < n; ++i)
		{
			int w,h; judge_in >> w >> h;
			totalWidth += w;
			books.emplace_back(w,h);
		}
		sort(books.begin(), books.end(), [](const pair<int,int> &p1, const pair<int,int> &p2) {return p1.second > p2.second;});

		// team says using the board is unnecessary but it is not
		if (teamres == -1 && totalWidth > x)
			wrong_answer("WA: books are too wide to fit into the bookshelf without using the board");

		//team says that board is unnecessary and this is correct
		if (teamres == -1 && totalWidth <= x)
			accept();

		// board position out of range
		if (teamres < 1 || teamres > y-1)
			wrong_answer("WA: the specified board position is out of range");

		// define the lower section of the shelf to be the taller one
		int h_lower = teamres;
		int h_upper = y - teamres;
		if (h_lower < h_upper)
			swap(h_lower, h_upper);

		// check whether largest book can be placed inside the bookshelf
		if (books.front().second > h_lower)
			wrong_answer("WA: largest book does not fit into shelf"); 

		// check whether large books fit into the lower section of the shelf
		int greedyWidth = 0;
		int k = 0;
		while (k < n && books[k].second > h_upper)
		{
			greedyWidth += books[k].first;
			k++;
		}
		if (greedyWidth > x)
			wrong_answer("WA: the total width of books only fitting in the taller section of the shelf is too large");

		// check whether the remaining books can be placed inside the lower and upper section of the shelf
		int lowCap = x - greedyWidth;
		vector<int> dp(lowCap+1,0);
		for (int i = k; i < n; ++i)
		{
			int wi = books[i].first;
			for (int j = lowCap; j >= wi; --j)
				dp[j] = max(dp[j], dp[j-wi] + wi);
		}
		int lowWidth = greedyWidth + dp[lowCap];
		if (totalWidth - lowWidth > x)
			wrong_answer("WA: books do not fit in the bookshelf with the given baord position");
	}
	// check for trailing output
	string trailing;
	if(author_out >> trailing)
		wrong_answer("WA: trailing output");

	accept();
}
