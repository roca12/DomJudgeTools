import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class IntPair {
    public int first,second;
    public IntPair(int first, int second) {
        this.first = first;
        this.second = second;
    }
}

public class Gregors {
    static void possible(int z) {System.out.println(z); System.exit(0);}
    static void impossible() {System.out.println("impossible"); System.exit(0);}

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int y = sc.nextInt();
        ArrayList<IntPair> books = new ArrayList<IntPair>();
        int totalW = 0;
        for (int i = 0; i < n; ++i) {
            int w = sc.nextInt();
            int h = sc.nextInt();
            if (w > x || h > y) impossible();
            totalW += w;
            books.add(new IntPair(w,h));
        }
        Collections.sort(books, new Comparator<IntPair>() {
            public int compare(IntPair p1, IntPair p2) {
                return p2.second - p1.second;
            }
        });
        int board = books.get(0).second;
        if (board <= y && totalW <= x) possible(-1);
        if (board == y && totalW > x) impossible();
        int greedyW = 0;
        int k = 0;
        while (k < n && books.get(k).second > y - board) {
            greedyW += books.get(k).first;
            k++;
        }
        if (greedyW > x) impossible();
        int cap = x - greedyW;
        ArrayList<Integer> dp = new ArrayList<>();
        for (int i = 0; i < cap+1; ++i)
            dp.add(0);
        for (int i = k; i < n; ++i) {
            int wi = books.get(i).first;
            for (int j = cap; j >= wi; --j)
                dp.set(j,Math.max(dp.get(j), dp.get(j-wi) + wi));
        }
        if (totalW - greedyW - dp.get(cap) > x) impossible();
        possible(board);
    }
}
