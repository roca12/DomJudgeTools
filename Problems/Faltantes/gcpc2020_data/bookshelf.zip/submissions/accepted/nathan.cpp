#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void fail() { cout << "impossible" << endl; exit(0); }
void succ(ll x) { cout << x << endl; exit(0); }

int main() {
	ll n, x, y, tw = 0, tw_ = 0;
	cin >> n >> x >> y;
	ll w[n], h[n];
	for (ll i = 0; i < n; ++i) cin >> w[i] >> h[i], tw += w[i];
	ll h_max = *max_element(h, h + n);
	if (h_max > y) fail();
	if (h_max == y) {
		if (tw > x) fail();
		else succ(-1);
	}
	for (ll i = 0; i < n; ++i) if (h[i] <= y - h_max) tw -= w[i], tw_ += w[i];
	if (tw > x) fail();
	ll dp[x - tw + 1];
	memset(dp, 0, sizeof(dp));
	for (ll i = 0; i < n; ++i) if (h[i] <= y - h_max)
		for (ll j = x - tw; j >= w[i]; --j)
			dp[j] = max(dp[j], dp[j - w[i]] + w[i]);
	if (tw_ - dp[x - tw] > x) fail();
	succ(h_max);
	return 0;
}
