#include <bits/stdc++.h>
using namespace std;

void fail() {
	cout << "impossible" << endl;
	exit(0);
}

int main() {
	int n, W, H;
	cin >> n >> W >> H;
	
	vector<int> w(n), h(n);
	for (int i = 0; i < n; i++) {
		cin >> w[i] >> h[i];
		if (h[i] > H) fail();
	}
	
	int board = *max_element(begin(h), end(h));
	board = min(board, H-board);

	vector<int> dp(W+1);
	dp[0] = 1;
	for (int i = 0; i < n; i++) if (h[i] <= board) {
		for (int j = W; j >= w[i]; j--) {
			dp[j] |= dp[j-w[i]];
		}
	}
	
	int wsum = accumulate(begin(w), end(w), 0);

	bool ok = false;
	for (int j = wsum-W; j <= W; j++) {
		if (dp[j]) ok = true;
	}
	if (!ok) fail();

	// if (board == 0) board = -1; oops
	cout << board << endl;
}
