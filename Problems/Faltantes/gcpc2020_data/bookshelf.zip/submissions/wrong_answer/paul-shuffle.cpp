#include <bits/stdc++.h>
using namespace std;

void fail() {
	cout << "impossible" << endl;
	exit(0);
}

int main() {
	int n, W, H;
	cin >> n >> W >> H;
	
	vector<int> w(n), h(n);
	for (int i = 0; i < n; i++) {
		cin >> w[i] >> h[i];
		if (h[i] > H) fail();
	}
	
	int board = *max_element(begin(h), end(h));
	board = min(board, H-board);

	vector<int> free_books;
	int wtop = 0;
	for (int i = 0; i < n; i++) {
		if (h[i] <= board) free_books.push_back(i);
		else wtop += w[i];
	}
	
	// If `wtop` is the total width of the books that need to be above the
	// board and `wsum` is the total width of all books, we need to find a
	// subset of indices in `free_books` with total width x such that
	// max(wtop+x,wsum-wtop-x) <= W. Equivalently, wsum-wtop-W <= x <= W-wtop.
	// Instead of the knapsack DP, repeatedly shuffle the array of books and
	// greedily fill in the shelf.

	int wsum = accumulate(begin(w), end(w), 0);
	int lo = wsum-wtop-W, hi = W-wtop;

	for (int attempt = 0; attempt < 1000; attempt++) {
		random_shuffle(begin(free_books), end(free_books));
		int x = 0;
		for (int i: free_books) {
			if (x < lo) x += w[i];
		}
		if (x >= lo && x <= hi) {
			if (board == 0) board = -1;
			cout << board << endl;
			return 0;
		}
	}
	
	fail();
}
