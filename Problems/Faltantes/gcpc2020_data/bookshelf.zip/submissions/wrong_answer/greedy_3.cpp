#include <iostream>
#include <vector>
#include <utility>
#include <algorithm>
using namespace std;

void possible(int z) {cout << z << endl; exit(0);}
void impossible() {cout << "impossible" << endl; exit(0);}

int main()
{
	int n,x,y; cin >> n >> x >> y;
	vector<pair<int,int>> books;
	int totalW = 0;
	for (int i = 0; i < n; ++i)
	{
		int w,h; cin >> w >> h;
		if (w > x || h > y) impossible();
		totalW += w;
		books.emplace_back(w,h);
	}
	sort(books.begin(), books.end(), [](auto &p1, auto &p2) {return p1.second > p2.second;});
	int board = books.front().second;
	if (board == y && totalW <= x) possible(-1);
	if (board == y && totalW > x) impossible();
	int low = 0;
	int k = 0;
	while (books[k].second > y - board) 
	{
		low += books[k].first;
		k++;
	}
	sort(books.begin() + k, books.end(), [](auto &p1, auto &p2) {return p1.first > p2.first;});
	for (int i = k; i < n; ++i)
		if (books[i].second > y - board || low + books[i].first <= x)
			low += books[i].first;
	if (low > x || totalW - low > x) impossible();
	possible(board);
}
