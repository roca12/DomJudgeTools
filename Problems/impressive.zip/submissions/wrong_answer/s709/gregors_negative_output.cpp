#include <iostream>
using namespace std;

int main()
{
	int n; cin >> n;
	if (n == 2 || n == 3 || n == 5)
		cout << "impossible" << endl;
	//else if (n == 1)
	//	cout << "1 1 1" << endl << "A 0 0" << endl;
	else
	{
		int a,b,c;
		if (n % 2)
		{
			c = n-3; a = 2; b = (c-2)/2; 
			cout << a << " " << b << " " << c << endl;
			for (int i = a; i < c; i += b)
				for (int j = a; j < c; j += b)
					cout << "B " << i << " " << j << endl;
		}
		else
		{
			c = n/2; a = 1; b = c-1;
			cout << a << " " << b << " " << c << endl;
			cout << "B 1 1" << endl;
		}
		for (int i = 0; i < c; i += a)
			cout << "A " << i << " 0" << endl;
		for (int i = a; i < c; i += a)
			cout << "A 0 " << i << endl; 
	}
}
