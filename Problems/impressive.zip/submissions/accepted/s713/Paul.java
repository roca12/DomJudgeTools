import java.util.*;

public class Paul {
	public static void main(String[] args) {
		int n = new Scanner(System.in).nextInt();
		
		int m = (int) Math.sqrt(n);

		if (m*m == n) {
			System.out.format("1 1 %d\n", m);
			for (int x = 0; x < m; x++) {
				for (int y = 0; x+y < m; y++) {
					System.out.format("A %d %d U\n", x, y);
					if (y > 0) System.out.format("A %d %d D\n", x, y);
				}
			}
		} else if (n <= 5) {
			System.out.println("impossible");
		} else {
			int a = n%2 == 1 ? 2 : 1;
			int b = n%2 == 1 ? (n-5)/2 : (n-2)/2;
			int c = n%2 == 1 ? 2*b+a : b+a;
			System.out.format("%d %d %d\n", a, b, c);
			
			for (int x = 0; x < c; x += a) {
				System.out.format("A %d 0 U\n", x);
				if (x+a < c) System.out.format("A %d %d D\n", x, a);
			}

			for (int x = 0; x < c-a; x += b) {
				for (int y = a; x+y < c; y += b) {
					System.out.format("B %d %d U\n", x, y);
					if (y > a) System.out.format("B %d %d D\n", x, y);
				}
			}
		}
	}
}
