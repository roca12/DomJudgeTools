#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n;

void even() {
	if (n < 4) cout << "impossible" << endl;
	else {
		cout << 1 << " " << n / 2 - 1 << " " << n / 2 << endl << "B 0 1 U" << endl;
		for (ll i = 0; i < n - 1; ++i) cout << "A " << i / 2 << (i % 2 ? " 1 D" : " 0 U") << endl;
	}
}

void odd() {
	if (n < 7) cout << "impossible" << endl;
	else {
		ll x = (2 * (n - 3) - 4) / 2;
		cout << 4 << " " << x << " " << 2 * (n - 3) << endl << "B 0 4 U" << endl << "B " << x << " 4 U" << endl << "B 0 " << x + 4 << " D" << endl << "B 0 " << x + 4 << " U" << endl;
		for (ll i = 0; i < n - 4; ++i) cout << "A " << i / 2 * 4 << (i % 2 ? " 4 D" : " 0 U") << endl;
	}
}

int main() {
	cin >> n;
	if (n == 1) cout << "1 1 1" << endl << "A 0 0 U" << endl;
	else n % 2 ? odd() : even();
	return 0;
}
