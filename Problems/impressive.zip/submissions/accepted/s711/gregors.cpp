#include <iostream>
using namespace std;

int main()
{
	int n; cin >> n;
	if (n == 2 || n == 3 || n == 5)
		cout << "impossible" << endl;
	else if (n == 1)
		cout << "1 1 1" << endl << "A 0 0 U" << endl;
	else
	{
		int a,b,c;
		if (n % 2)
		{
			c = n-3; a = 2; b = (c-2)/2; 
			cout << a << " " << b << " " << c << endl;
			cout << "B 0 2 U" << endl;
			cout << "B " << b << " 2 U" << endl;
			cout << "B 0 " << (a + b) << " D" << endl;
			cout << "B 0 " << (a + b) << " U" << endl;
		}
		else
		{
			c = n/2; a = 1; b = c-1;
			cout << a << " " << b << " " << c << endl;
			cout << "B 0 1 U" << endl;
		}
		for (int i = 0; i < c; i += a)
			cout << "A " << i << " 0 U" << endl;
		for (int i = 0; i < c-a; i += a)
			cout << "A " << i << " " << a << " D" << endl; 
	}
}
