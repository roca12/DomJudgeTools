#include "validation.h"

constexpr long double eps = 1.2e-4l;

struct point {
  long double x, y;
  point operator+=(const point& r) {
    x += r.x, y += r.y;
    return *this;
  }
  point operator*(long double f) const { return {f * x, f * y}; }
};

int main(int argc, char** argv) {
  std::ifstream in(argv[1]);
  OutputValidator v(argc, argv);

  // Read the input.
  int n;
  in >> n;
  point target;
  in >> target.x >> target.y;
  vector<point> points(n);
  for (auto& p : points) in >> p.x >> p.y;

  // Read the team answer.
  long double sum = 0;
  point avg{0, 0};
  for (int i = 0; i < n; ++i) {
    // All input is >= 0
    long double f = v.read_long_double(-1.l, 2.l);
    v.check(f >= -eps, "Weight ", f, " is not >= -eps.");
    sum += f;
    avg += points[i] * f;

    v.newline();
  }

  // Sum of numbers within epsilon from 1.
  v.check(1 - eps <= sum and sum <= 1 + eps,
          "Sum of given weights is not close enough to 1: ", sum);

  // Correct for when the sum is somewhat far from 1.
  avg.x /= sum;
  avg.y /= sum;

  // Average point must be close to target point.
  v.check(target.x - eps <= avg.x and avg.x <= target.x + eps,
          "Weighted average x = ", avg.x, " is too far from wanted ", target.x);
  v.check(target.y - eps <= avg.y and avg.y <= target.y + eps,
          "Weighted average y = ", avg.y, " is too far from wanted ", target.y);
}
