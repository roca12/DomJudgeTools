#include <cassert>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

struct P {
  double x, y;
  P operator-(const P r) const { return {x - r.x, y - r.y}; }
  P operator+(const P r) const { return {x + r.x, y + r.y}; }
  P operator*(double f) const { return {x * f, y * f}; }
};

double cross(P a, P b) { return a.x * b.y - a.y * b.x; }
// c left of the line a->b?
bool left(P a, P b, P c) { return cross(a - b, c - b) < 0; }

int main() {
  int n;
  cin >> n;
  P target;
  cin >> target.x >> target.y;
  vector<P> ps(n);
  for (auto &p : ps) cin >> p.x >> p.y, p = p - target;
  target = target - target;

  // Find the 0,i,i+1 triangle containing target:
  assert(left(ps[0], ps[1], target));
  assert(!left(ps[0], ps[n - 1], target));
  int i = 1;
  while (left(ps[0], ps[i], target)) ++i;
  // 0,i-1,i contains target
  // intersect 0->O with (i-1)->i
  // (alpha*p[i].x + (1-alpha)*p[i-1].x)/(alpha*p[i].y + (1-alpha)*p[i-1].y) =
  // p[0].x / p[0].y p[0].y*(alpha*p[i].x + (1-alpha)*p[i-1].x) =
  // p[0].x*(alpha*p[i].y + (1-alpha)*p[i-1].y) alpha*(p[0].y(p[i].x-p[i-1].x) -
  // p[0].x*(p[i].y - p[i-1].y)) = -p[0].y*p[i-1].x+p[0].x*p[i-1].y
  double alpha =
      (-ps[0].y * ps[i - 1].x + ps[0].x * ps[i - 1].y) /
      (ps[0].y * (ps[i].x - ps[i - 1].x) - ps[0].x * (ps[i].y - ps[i - 1].y));
  cerr << "alpha: " << alpha << endl;
  assert(0 <= alpha and alpha <= 1);
  P avg = ps[i] * alpha + ps[i - 1] * (1 - alpha);
  cerr << "avg:   " << avg.x << " " << avg.y << endl;
  cerr << "ps[0]: " << ps[0].x << " " << ps[0].y << endl;
  // beta * p[0].x + (1-beta)*avg.x == 0
  // beta*(p[0].x - avg.x) = -avg.x
  double beta;
  if (abs(ps[0].y - avg.y) > abs(ps[0].x - avg.x))
    beta = -avg.y / (ps[0].y - avg.y);
  else
    beta = -avg.x / (ps[0].x - avg.x);

  cerr << "beta: " << beta << endl;
  assert(0 <= beta and beta <= 1);
  vector<double> ans(n, 0);
  ans[0] = beta;
  ans[i] = alpha * (1 - beta);
  ans[i - 1] = (1 - alpha) * (1 - beta);
  for (auto x : ans) cout << setprecision(10) << x << endl;
}
