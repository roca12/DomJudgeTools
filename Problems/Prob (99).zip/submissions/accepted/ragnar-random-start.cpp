#include <cassert>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

struct P {
  double x, y;
  P operator-(const P r) const { return {x - r.x, y - r.y}; }
  P operator+(const P r) const { return {x + r.x, y + r.y}; }
  P operator*(double f) const { return {x * f, y * f}; }
};

double cross(P a, P b) { return a.x * b.y - a.y * b.x; }
// c left of the line a->b?
bool left(P a, P b, P c) { return cross(a - b, c - b) < 0; }

int main() {
  int n;
  cin >> n;
  P target;
  cin >> target.x >> target.y;
  vector<P> ps(n);
  for (auto &p : ps) cin >> p.x >> p.y, p = p - target;
  target = target - target;

  // Find the 0,i,i+1 triangle containing target:
  int start = rand() % n;
  int i = (start + 1) % n;
  while (left(ps[start], ps[i], target)) i = (i + 1) % n;
  int j = (i + n - 1) % n;
  cerr << start << ' ' << i << ' ' << j << endl;
  // 0,i-1,i contains target
  // intersect 0->O with (i-1)->i
  // (alpha*p[i].x + (1-alpha)*p[i-1].x)/(alpha*p[i].y + (1-alpha)*p[i-1].y) =
  // p[0].x / p[0].y p[0].y*(alpha*p[i].x + (1-alpha)*p[i-1].x) =
  // p[0].x*(alpha*p[i].y + (1-alpha)*p[i-1].y) alpha*(p[0].y(p[i].x-p[i-1].x) -
  // p[0].x*(p[i].y - p[i-1].y)) = -p[0].y*p[i-1].x+p[0].x*p[i-1].y
  double alpha =
      (-ps[start].y * ps[j].x + ps[start].x * ps[j].y) /
      (ps[start].y * (ps[i].x - ps[j].x) - ps[start].x * (ps[i].y - ps[j].y));
  cerr << "alpha: " << alpha << endl;
  cerr << "psi: " << ps[i].x << ' ' << ps[i].y << endl;
  cerr << "psj: " << ps[j].x << ' ' << ps[j].y << endl;
  P avg = ps[i] * alpha + ps[j] * (1 - alpha);
  cerr << "AVG: " << avg.x << ' ' << avg.y << endl;
  cerr << "p0:  " << ps[start].x << " " << ps[start].y << endl;
  // beta * p[0].x + (1-beta)*avg.x == 0
  // beta*(p[0].x - avg.x) = -avg.x
  double beta;
  if (abs(ps[start].y - avg.y) > abs(ps[start].x - avg.x))
    beta = -avg.y / (ps[start].y - avg.y);
  else
    beta = -avg.x / (ps[start].x - avg.x);
  cerr << "beta: " << beta << endl;
  vector<double> ans(n, 0);
  ans[start] = beta;
  ans[i] = alpha * (1 - beta);
  ans[j] = (1 - alpha) * (1 - beta);
  for (auto x : ans) cout << setprecision(10) << x << endl;
}
