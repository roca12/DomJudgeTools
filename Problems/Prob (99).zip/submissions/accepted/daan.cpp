#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

typedef long long ll;

int main() {
	int n;
	ll Ux, Uy, Ox, Oy, Ax, Ay, Bx, By;
	cin >> n >> Ux >> Uy >> Ox >> Oy >> Ax >> Ay;
	Ux -= Ox; Uy -= Oy;
	Ax -= Ox; Ay -= Oy;
	vector<double> ans(n, 0);
	for( int i = 2; i < n; ++i ) {
		Bx = Ax; By = Ay;
		cin >> Ax >> Ay;
		Ax -= Ox; Ay -= Oy;
		ll den = Ax*By - Bx*Ay;
		ll num[3] = { Ux*By - Uy*Bx, Ax*Uy - Ay*Ux, den - num[0] - num[1] };
		if( den < 0 ) {
			den = -den;
			num[0] = -num[0];
			num[1] = -num[1];
			num[2] = -num[2];
		}
		double d = den;
		if( num[0] >= 0 and num[1] >= 0 and num[2] >= 0 ) {
			ans[i] = num[0]/d;
			ans[i-1] = num[1]/d;
			ans[0] = num[2]/d;
		}
	}
	for(auto x : ans)
		cout << setprecision(10) << x << endl;
}
