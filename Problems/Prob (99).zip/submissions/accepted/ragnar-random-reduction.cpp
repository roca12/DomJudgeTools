#include <algorithm>
#include <array>
#include <cassert>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

struct P {
  long double x, y;
  P operator-(const P r) const { return {x - r.x, y - r.y}; }
  P operator+(const P r) const { return {x + r.x, y + r.y}; }
  P operator*(long double f) const { return {x * f, y * f}; }
};

long double cross(P a, P b) { return a.x * b.y - a.y * b.x; }
// t left of the line a->b?
bool left(P a, P b, P t) { return cross(a - b, t - b) < 0; }
// t left or on of the line a->b?
bool lefton(P a, P b, P t) { return cross(a - b, t - b) <= 0; }

// t inside/edge of triangle?
bool inside(P a, P b, P c, P t) {
  return lefton(a, b, t) and lefton(b, c, t) and lefton(c, a, t);
}

// assume the target is (0,0).
vector<long double> solve(vector<P> ps, P target) {
  int n = ps.size();
  if (ps.size() == 3) {
    int start = 0;
    int j = 1;
    int i = 2;
    long double alpha =
        (-ps[start].y * ps[j].x + ps[start].x * ps[j].y) /
        (ps[start].y * (ps[i].x - ps[j].x) - ps[start].x * (ps[i].y - ps[j].y));
    P avg = ps[i] * alpha + ps[j] * (1 - alpha);
    double beta;
    if (abs(ps[0].y - avg.y) > abs(ps[0].x - avg.x))
      beta = -avg.y / (ps[0].y - avg.y);
    else
      beta = -avg.x / (ps[0].x - avg.x);
    vector<long double> ans(n, 0);
    ans[start] = beta;
    ans[i] = alpha * (1 - beta);
    ans[j] = (1 - alpha) * (1 - beta);
    return ans;
  }

  // find two neighbouring points that can be contracted.
  while (true) {
    int prev = rand() % n;
    int i = (prev + 1) % n;
    int j = (prev + 2) % n;
    int next = (prev + 3) % n;
    if (lefton(ps[prev], ps[j], target) and lefton(ps[i], ps[next], target)) {
      long double alpha = (rand() % 1001) / 1000.l;
      // replace i and j by alpha*i + (1-alpha)*j
      auto ps2 = ps;
      ps2[i] = ps[i] * alpha + ps[j] * (1 - alpha);
      ps2.erase(begin(ps2) + j);
      auto factors = solve(ps2, target);
      factors.insert(begin(factors) + j, 0);
      factors[j] = factors[i] * (1 - alpha);
      factors[i] = factors[i] * alpha;
      return factors;
    }
  }
}

int main() {
  srand(time(0));
  int n;
  cin >> n;
  P target;
  cin >> target.x >> target.y;
  vector<P> ps(n);
  for (auto &p : ps) cin >> p.x >> p.y, p = p - target;
  target = target - target;
  for (auto x : solve(ps, target)) cout << setprecision(10) << x << endl;
}
