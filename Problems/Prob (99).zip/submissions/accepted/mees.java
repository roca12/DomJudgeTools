import java.util.Scanner;
import java.lang.Math;

public class mees {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        long x = sc.nextLong();
        long y = sc.nextLong();

        long[] xs = new long[n];
        long[] ys = new long[n];
        
        for(int i = 0; i < n; i++) {
            xs[i] = sc.nextLong();
            ys[i] = sc.nextLong();
        }

        for(int j = 1; j + 1 < n; j++) {
            long dA = (xs[j]*ys[j+1] - ys[j]*xs[j+1])
                - (xs[0]*ys[j+1] - ys[0]*xs[j+1])
                + (xs[0]*ys[j] - xs[j]*ys[0]);

            long dA0 = (xs[j]*ys[j+1] - ys[j]*xs[j+1])
                - (x*ys[j+1] - y*xs[j+1])
                + (x*ys[j] - xs[j]*y);

            long dA1 = (x*ys[j+1] - y*xs[j+1])
                - (xs[0]*ys[j+1] - ys[0]*xs[j+1])
                + (xs[0]*y - x*ys[0]);

            long dAj = (xs[j]*y - ys[j]*x)
                - (xs[0]*y - ys[0]*x)
                + (xs[0]*ys[j] - xs[j]*ys[0]);
           
            double a0 = (1.0*dA0)/dA; 
            double a1 = (1.0*dA1)/dA; 
            double aj = (1.0*dAj)/dA; 

            if(a0 >= 0 && a1 >= 0 && aj >= 0) {
                System.out.format("%.12f\n", a0);
                for(int i = 1; i < j; i++)
                    System.out.format("%.12f\n", 0.0);
                System.out.format("%.12f\n", a1);
                System.out.format("%.12f\n", aj);
                for(int i = j + 2; i < n; i++)
                    System.out.format("%.12f\n", 0.0);
                break;
            }

        }

	}
}
