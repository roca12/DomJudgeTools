#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

int main() {
    int n;
    long long x, y;
    cin >> n >> x >> y;
    vector<long long> xs(n), ys(n);
    for(int i = 0; i < n; i++)
        cin >> xs[i] >> ys[i];

    for(int j = 1; j + 1 < n; j++) {
        // Using points 0, j, j+1.

        // We have:
        // / x[0]  x[j]  x[j+1] \ / a0 \   / x \
        // | y[0]  y[j]  y[j+1] | | a1 | = | y |
        // \ 1     1     1      / \ aj /   \ 1 /

        long long dA = (xs[j]*ys[j+1] - ys[j]*xs[j+1])
            - (xs[0]*ys[j+1] - ys[0]*xs[j+1])
            + (xs[0]*ys[j] - xs[j]*ys[0]);

        long long dA0 = (xs[j]*ys[j+1] - ys[j]*xs[j+1])
            - (x*ys[j+1] - y*xs[j+1])
            + (x*ys[j] - xs[j]*y);

        long long dA1 = (x*ys[j+1] - y*xs[j+1])
            - (xs[0]*ys[j+1] - ys[0]*xs[j+1])
            + (xs[0]*y - x*ys[0]);

        long long dAj = (xs[j]*y - ys[j]*x)
            - (xs[0]*y - ys[0]*x)
            + (xs[0]*ys[j] - xs[j]*ys[0]);
       
        long double a0 = (1.0*dA0)/dA; 
        long double a1 = (1.0*dA1)/dA; 
        long double aj = (1.0*dAj)/dA; 

        if(a0 >= 0 && a1 >= 0 && aj >= 0) {
            printf("%.8llf\n", a0);
            for(int i = 1; i < j; i++)
                printf("%.8lf\n", 0.0);
            printf("%.8llf\n", a1);
            printf("%.8llf\n", aj);
            for(int i = j + 2; i < n; i++)
                printf("%.8lf\n", 0.0);
            break;
        }
    }
}
