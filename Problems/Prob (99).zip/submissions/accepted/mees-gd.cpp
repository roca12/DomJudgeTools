#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

int main() {
    int n; 
    double x, y; 
    cin >> n >> x >> y;
    vector<double> xs(n), ys(n);
    for(int i = 0; i < n; i++)
        cin >> xs[i] >> ys[i];

    double avg_x = 0.0;
    double avg_y = 0.0;
    for(int i = 0; i < n; i++) {
        avg_x += xs[i];
        avg_y += ys[i];
    }
    avg_x /= n;
    avg_y /= n;
    
    double biggest_x = 0.0;
    double biggest_y = 0.0;
    for(int i = 0; i < n; i++) {
        xs[i] -= avg_x;
        ys[i] -= avg_y;
        biggest_x = max(biggest_x, abs(xs[i]));
        biggest_y = max(biggest_y, abs(ys[i]));
    }

    for(int i = 0; i < n; i++){
        xs[i] /= biggest_x;
        ys[i] /= biggest_y;
    }

    x = (x - avg_x)/biggest_x;
    y = (y - avg_y)/biggest_y;


    // CPP is fast enough to allow 5e6 iterations!
    int num_steps = 5000000;
    double learning_rate = 0.001;

    vector<double> a(n, 1.0/n);

    double cur_x, cur_y, a_sum;
    for(int step = 1; step <= num_steps; step++) {
        cur_x = 0.0;
        cur_y = 0.0;
        a_sum = 0.0;
        for(int i = 0; i < n; i++) {
            cur_x += a[i]*xs[i];
            cur_y += a[i]*ys[i];
            a_sum += a[i];
        }

        for(int i = 0; i < n; i++) {
            double jump = -learning_rate * 
                (2*xs[i]*(cur_x - x) + 2*ys[i]*(cur_y - y) + 2*(a_sum - 1));
            a[i] += jump;
            a[i] = max(0.0, a[i]);
            a[i] = min(a[i], 1.0);
        }
    }
    for(int i = 0; i < n; i++)
        printf("%.10lf\n", a[i]);
    return 0;
}
