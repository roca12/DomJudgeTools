#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

int main() {
    int n;
    long long x, y;
    cin >> n >> x >> y;
    vector<long long> xs(n), ys(n);
    for(int i = 0; i < n; i++)
        cin >> xs[i] >> ys[i];

    int num_iterations = 100000;

    vector<double> a(n, 1.0/n);

    for(int it = 0; it < num_iterations; it++) {
        for(int i = 0; i < n; i++) {
            // Currently the error is
            // (\sum_i a_ix_i - x)^2 + (\sum_i a_iy_i - y)^2
            // = \sum_i,j a_ia_jx_ix_j - 2\sum_i a_ix_ix + x^2 (+ the same for y)
            // so as a polynomial in a[i], the degree 2 coefficient is x[i]^2 +
            // y[i]^2, and the deg 1 coefficient is \sum_j!=i a_jx[i]x[j] - 2*x[i]x
            // plus the same for y.
            
            double B = -2*xs[i]*x -2*ys[i]*y;
            for(int j = 0; j < n; j++)
                if(i != j)
                    B += 2*a[j]*xs[i]*xs[j] + 2*a[j]*ys[i]*ys[j];
            double A = xs[i]*xs[i] + ys[i]*ys[i];

            a[i] = max(0.0, -B/(2.0*A));

            double sum_a = 0.0;
            for(double el : a)
                sum_a += el;
            for(int j = 0; j < n; j++)
                a[j] /= sum_a;
            // printf("sum_a: %lf\n", sum_a);
        }
        double cur_x = 0.0;
        double cur_y = 0.0;
        for(int i = 0; i < n; i++) {
            cur_x += a[i]*xs[i];
            cur_y += a[i]*ys[i];
        }
        /*printf("%.4lf %.4lf\n", cur_x, cur_y);*/
    }
    for(double el : a)
        printf("%.8lf\n", el);
    return 0;
}
