#include <algorithm>
#include <array>
#include <cassert>
#include <iomanip>
#include <iostream>
#include <vector>
using namespace std;

struct P {
  double x, y;
  P operator-(const P r) const { return {x - r.x, y - r.y}; }
  P operator+(const P r) const { return {x + r.x, y + r.y}; }
  P operator*(double f) const { return {x * f, y * f}; }
};

long long cross(P a, P b) { return a.x * b.y - a.y * b.x; }
// t left of the line a->b?
bool left(P a, P b, P t) { return cross(a - b, t - b) < 0; }
// t left or on of the line a->b?
bool lefton(P a, P b, P t) { return cross(a - b, t - b) < 0; }

// t inside/edge of triangle?
bool inside(P a, P b, P c, P t) {
  return lefton(a, b, t) and lefton(b, c, t) and lefton(c, a, t);
}

int main() {
  // srand(time(0));
  int n;
  cin >> n;
  P target;
  cin >> target.x >> target.y;
  vector<P> ps(n);
  for (auto &p : ps) cin >> p.x >> p.y, p = p - target;
  target = target - target;

  while (true) {
    array<int, 3> a;
    for (auto &x : a) x = rand() % n;
    sort(begin(a), end(a));
    if (a[0] == a[1] or a[1] == a[2]) continue;
    if (inside(ps[a[0]], ps[a[1]], ps[a[2]], target)) {
      int start = a[0];
      int j = a[1];
      int i = a[2];
      double alpha = (-ps[start].y * ps[j].x + ps[start].x * ps[j].y) /
                     (ps[start].y * (ps[i].x - ps[j].x) -
                      ps[start].x * (ps[i].y - ps[j].y));
      P avg = ps[i] * alpha + ps[j] * (1 - alpha);
      double beta;
      if (ps[start].x == avg.x)
        beta = -avg.y / (ps[start].y - avg.y);
      else
        beta = -avg.x / (ps[start].x - avg.x);
      vector<double> ans(n, 0);
      ans[start] = beta;
      ans[i] = alpha * (1 - beta);
      ans[j] = (1 - alpha) * (1 - beta);
      for (auto x : ans) cout << setprecision(10) << x << endl;
      return 0;
    }
  }
}
