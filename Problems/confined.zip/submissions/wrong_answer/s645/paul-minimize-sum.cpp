#include <bits/stdc++.h>
using namespace std;

const int dx[] = {-1,1,0,0,0}, dy[] = {0,0,-1,1,0};

int main() {
	int n, ax, ay, bx, by, x, y;
	cin >> n >> ax >> ay >> bx >> by;

	while (true) {
		cin >> x >> y;
		if (x == 0) break;
		
		int best_sum = INT_MAX;
		vector<tuple<int,int,int,int>> best;
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				int nax = ax+dx[i], nay = ay+dy[i];
				int nbx = bx+dx[j], nby = by+dy[j];

				int sum = abs(nax-x) + abs(nay-y) + abs(nbx-x) + abs(nby-y);
				if (sum > best_sum) continue;
				if (sum < best_sum) best.clear();
				best_sum = sum;
				best.emplace_back(nax,nay,nbx,nby);
			}
		}

		tie(ax,ay,bx,by) = best[rand() % best.size()];
		cout << ax << " " << ay << " " << bx << " " << by << endl;
	}
}
