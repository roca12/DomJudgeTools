#include <bits/stdc++.h>
using namespace std;

void approach(int &a, int b) {
	if (a < b) a++;
	if (a > b) a--;
}

int main() {
	int n, ax, ay, bx, by, x, y;
	cin >> n >> ax >> ay >> bx >> by;

	while (true) {
		cin >> x >> y;
		if (x == 0) break;
		
		if (ax == x) approach(ay,y);
		else approach(ax,x);

		if (by == y) approach(bx,x);
		else approach(by,y);

		cout << ax << " " << ay << " " << bx << " " << by << endl;
	}
}
