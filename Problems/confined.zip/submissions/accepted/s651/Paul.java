import java.util.*;

public class Paul {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		sc.next();
		int x1 = sc.nextInt(), y1 = sc.nextInt(), x2 = sc.nextInt(), y2 = sc.nextInt();

		while (true) {
			int x = sc.nextInt(), y = sc.nextInt();
			if (x == 0) break;
			if (x != x1) x1 += Math.signum(x-x1);
			else y1 += Math.signum(y-y1);
			if (y != y2) y2 += Math.signum(y-y2);
			else x2 += Math.signum(x-x2);
			System.out.format("%d %d %d %d\n", x1, y1, x2, y2);
			System.out.flush();
		}
	}
}
