#include <algorithm>
#include <cassert>
#include <iostream>
#include <tuple>
#include <vector>
using namespace std;
struct P{int x,y;};
bool operator<(const P&l, const P&r){return tie(l.x,l.y)<tie(r.x,r.y);}
int main(){
	int n, b;
	cin >> n >> b;
	vector<P> ps(n); // CCW order
	for(auto&p:ps) cin >> p.x >> p.y;
	vector<int> bs(b);
	for(auto&b:bs) cin >> b;
	bs.push_back(1e9);
	sort(bs.begin(), bs.end());
	auto bi = bs.begin();
	int ans = 0, pending = 0, ok = 1;
	auto pi = min_element(ps.begin(), ps.end()); // lowest leftmost point
	for(;*bi < pi->x; ++bi) ++ans; // points before left
	while(true){
		auto pj = next(pi);
		if(pj == ps.end()) pj = ps.begin();
		if(pj->x < pi->x) break;
		int c = 0;
		for(;*bi < pj->x; ++bi) ++c; // number of points on this segment
		if(pj->y < pi->y){
			if(ok){
				ans += c;
				assert(pending == 0);
			}
			else pending = 0;
		}
		else if(pj->y == pi->y){
			if(pj->y > 0){
				ans += c;
				assert(pending == 0);
			} else
				pending=0;
		}
		else if(pj->y > pi->y){
			if(pj->y > 0) ans += c;
			else pending += c;
		} else assert(false);
		pi = pj;
	}
	for(;*bi < 1e9; ++bi) ++ans; // points after right
	cout << (b- ans) << endl;
}
