/**
 * GCPC 2020 - Knightly Knowledge
 *
 * Accepted solution with duplicate counting.
 */

#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <algorithm>

#define MAX_NUM   1000
#define MAX_POS   1000000
#define POS_RANGE 2000001

using namespace std;

struct int2d { int x, y; };

int2d mpos[MAX_NUM], cpos[MAX_NUM];
short mnumx[POS_RANGE], mnumy[POS_RANGE];
short cnumx[POS_RANGE], cnumy[POS_RANGE];

int main()
{
  // Read data
  int m, c;
  cin >> m >> c;
  for (int i = 0; i < m; i++)
    cin >> mpos[i].x >> mpos[i].y;
  for (int i = 0; i < c; i++)
    cin >> cpos[i].x >> cpos[i].y;

  // Adapt coordinates
  for (int i = 0; i < m; i++) {
    mpos[i].x += MAX_POS;
    mpos[i].y += MAX_POS;
  }
  for (int i = 0; i < c; i++) {
    cpos[i].x += MAX_POS;
    cpos[i].y += MAX_POS;
  }

  // Evaluate horizontal and vertical lines
  vector<int> cids;
  memset(mnumx, 0, POS_RANGE*sizeof(short));
  memset(mnumy, 0, POS_RANGE*sizeof(short));
  memset(cnumx, 0, POS_RANGE*sizeof(short));
  memset(cnumy, 0, POS_RANGE*sizeof(short));
  for (int i = 0; i < m; i++) {
    mnumx[mpos[i].x]++;
    mnumy[mpos[i].y]++;
  }
  for (int i = 0; i < c; i++) {
    int cx = cpos[i].x, cy = cpos[i].y;
    short nx = mnumx[cx], ny = mnumy[cy];
    if (nx < 2 && ny < 2 && (nx > 0 || ny > 0)) {
      cnumx[cx]++;
      cnumy[cy]++;
      cids.push_back(i);
    }
  }

  // Find best location
  int maxx = 0, maxy = 0;
  short maxnx = 0, maxny = 0;
  for (int i : cids) {
    int cx = cpos[i].x, cy = cpos[i].y;
    if (cnumx[cx] > maxnx) {
      maxx = cx;
      maxnx = cnumx[cx];
    }
    if (cnumy[cy] > maxny) {
      maxy = cy;
      maxny = cnumy[cy];
    }
  }
  cout << maxx-MAX_POS << " " << maxy-MAX_POS << endl;
  cout << maxnx+maxny << endl;

  return 0;
}
