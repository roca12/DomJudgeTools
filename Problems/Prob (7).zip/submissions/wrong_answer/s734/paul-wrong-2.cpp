#include <bits/stdc++.h>
using namespace std;

int main() {
	int m, c;
	cin >> m >> c;
	
	map<int,int> mx, my, cx, cy;
	set<pair<int,int>> cs;

	while (m--) {
		int x, y;
		cin >> x >> y;
		mx[x]++, my[y]++;
	}
	
	while (c--) {
		int x, y;
		cin >> x >> y;
		cx[x]++, cy[y]++, cs.emplace(x,y);
	}

	int res = 0, bx = 0, by = 0;
	for (auto [x,a]: cx) for (auto [y,b]: cy) {
		int cur = (mx[x] == 1) * a +  (my[y] == 1) * b;
		if (mx[x] == 1 && my[y] == 1) cur -= cs.count({x,y});
		if (cur > res) res = cur, bx = x, by = y;
	}
	cout << bx << " " << by << endl << res << endl;
}
