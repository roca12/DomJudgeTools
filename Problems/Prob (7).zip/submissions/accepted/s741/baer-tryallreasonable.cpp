#include <bits/stdc++.h>

using namespace std;

const int MAX = 1000000;

int main() {
	int m, c;
	cin >> m >> c;
	set<pair<int, int>> cs;
	vector<int> cx(2*MAX + 5), cy(2*MAX + 5), mx(2*MAX + 5), my(2*MAX + 5);
	set<int> possX, possY;
	possX.insert(0); // fallback for 0
	possY.insert(0); // fallback for 0
	for (int i = 0; i < m; i++) {
		int x, y;
		cin >> x >> y;
		possX.insert(x+MAX); // only reasonable if there is at least one monument
		possY.insert(y+MAX);
		mx[x + MAX]++;
		my[y + MAX]++;
	}
	for (int i = 0; i < c; i++) {
		int x, y;
		cin >> x >> y;
		x += MAX;
		y += MAX;
		if (my[y] < 2 && mx[x] < 2) {
			//cout << "can convert at " << x << " " << y << endl;
			cx[x]++;
			cy[y]++;
			cs.insert(make_pair(x, y));
		}
	}
	int bestc = 0;
	int bestx = MAX;
	int besty = MAX;
	for (int x : possX) for (int y : possY) {
		int sum = 0;
		if (mx[x] == 1) sum += cx[x];
		if (my[y] == 1) sum += cy[y];
		if (mx[x] == 1 && my[y] == 1 && cs.find(make_pair(x, y)) != cs.end()) sum--; // counted twice
//		cout << "sum is " << sum << "for " << x << ",  " << y << endl;
		if (sum > bestc) {
			bestc = sum;
			bestx = x;
			besty = y;
		}
	}
	cout << bestx-MAX << " " << besty-MAX << endl << bestc << endl;
}
