#include <iostream>
#include <map>
#include <set>
#include <utility>
using namespace std;

int main()
{
	int m,c; cin >> m >> c;
	map<int,int> mx, my, cx, cy;
	for (int i = 0; i < m; ++i)
	{
		int x,y; cin >> x >> y;
		mx[x]++; my[y]++;
	}
	set<pair<int,int>> unmighty;
	for (int i = 0; i < c; ++i)
	{
		int x,y; cin >> x >> y;
		if (mx[x] <= 1 && my[y] <= 1)
		{
			unmighty.insert({x,y});
			cx[x]++; cy[y]++;
		}
	}
	int px = 0; int py = 0;
	int res = 0;
	for (auto &[x,v] : cx)
	{
		for (auto &[y,h] : cy)
		{
			int cnt = (mx[x] == 1) * v + (my[y] == 1) * h - (mx[x] == 1) * (my[y] == 1) * unmighty.count({x,y});
			if (cnt > res) px = x, py = y, res = cnt;
		}
	}
	cout << px << " " << py << endl << res << endl; 
}
