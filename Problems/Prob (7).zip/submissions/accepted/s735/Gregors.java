import java.util.*;

class Pair<T1,T2>
{
    T1 first; T2 second;
    Pair(T1 first, T2 second)
    {
        this.first = first;
        this.second = second;
    }
    @Override
    public int hashCode()
    {
        return Objects.hash(first,second);
    }
    @Override
    public boolean equals(Object o)
    {
        Pair other = (Pair) o;
        return first == other.first && second == other.second;
    }
}

public class Gregors
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int c = sc.nextInt();
        Map<Integer,Integer> mx = new HashMap<>();
        Map<Integer,Integer> my = new HashMap<>();
        for (int i = 0; i < m; ++i)
        {
            int x = sc.nextInt();
            mx.putIfAbsent(x,0);
            mx.put(x, mx.get(x) + 1);
            int y = sc.nextInt();
            my.putIfAbsent(y,0);
            my.put(y, my.get(y) + 1);
        }
        Map<Integer,Integer> cx = new HashMap<>();
        Map<Integer,Integer> cy = new HashMap<>();
        Set<Pair<Integer,Integer>> unmighty = new HashSet<>();
        for (int i = 0; i < c; ++i)
        {
            int x = sc.nextInt();
            int y = sc.nextInt();
            mx.putIfAbsent(x,0);
            my.putIfAbsent(y,0);
            if (mx.get(x) <= 1 && my.get(y) <= 1)
            {
                unmighty.add(new Pair<>(x,y));
                cx.putIfAbsent(x,0);
                cx.put(x, cx.get(x) + 1);
                cy.putIfAbsent(y,0);
                cy.put(y, cy.get(y) + 1);
            }
        }
        int px = 0; int py = 0;
        int res = 0;
        for (Map.Entry<Integer,Integer> e1 : cx.entrySet())
        {
            int x = e1.getKey();
            int v = e1.getValue();
            for (Map.Entry<Integer,Integer> e2 : cy.entrySet())
            {
                int y = e2.getKey();
                int h = e2.getValue();
                int cnt = 0;
                if (mx.get(x) == 1) cnt += v;
                if (my.get(y) == 1) cnt += h;
                if (mx.get(x) == 1 && my.get(y) == 1 && unmighty.contains(new Pair<>(x,y))) cnt--;
                if (cnt > res)
                {
                    px = x;
                    py = y;
                    res = cnt;
                }
            }
        }
        System.out.println(px + " " + py + "\n" + res);
    }
}
