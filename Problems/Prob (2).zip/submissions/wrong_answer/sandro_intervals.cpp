/**
 * GCPC 2020 - Exhausting Errands
 *
 * Wrong solution, just adding up all motion interval
 * widths after merging so that all motions between
 * intervals (w/o carrying a message) are not counted.
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>

using namespace std;

// Interval from a to b
struct veci2 { int a, b; };

bool cmp_veci2(const veci2 &x, const veci2 &y)
{ return x.a < y.a; }

int main()
{
  // Read data
  int l, n, a, b;
  vector<veci2> vecs[2];
  scanf("%d %d", &l, &n);
  for (int i = 0; i < n; i++) {
    scanf("%d %d", &a, &b);
    if (a < b)
      vecs[0].push_back({a, b});
    else
      vecs[1].push_back({b, a});
  }

  // Merge intervals
  for (int k = 0; k < 2; k++) {
    int m = vecs[k].size(), i = 0;
    sort(vecs[k].begin(), vecs[k].end(), cmp_veci2);
    while (i+1 < m) {
      while (i+1 < m && vecs[k][i+1].a <= vecs[k][i].b) {
        if (vecs[k][i+1].b > vecs[k][i].b)
          vecs[k][i].b = vecs[k][i+1].b;
        vecs[k].erase(vecs[k].begin() + i+1);
        m--;
      }
      i++;
    }
  }

  // Sum interval widths
  int dist = 0;
  for (int k = 0; k < 2; k++) {
    int n = vecs[k].size();
    for (int i = 0; i < n; i++)
      dist += vecs[k][i].b - vecs[k][i].a;
  }
  printf("%d\n", dist);
  return 0;
}
