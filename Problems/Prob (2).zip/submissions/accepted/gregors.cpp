#include <iostream>
#include <vector>
#include <utility>
#include <set>
using namespace std;
using ll = long long;

vector<pair<int,int>> mergeErrands(int right, vector<pair<int,int>> &errands)
{
	multiset<pair<int,int>> ops;
	for (auto &[a,b] : errands)
		ops.insert({a,1}), ops.insert({b,-1});
	vector<pair<int,int>> merged;
	int start, cnt = 0;
	for (auto &[p,op] : ops)
	{
		if (cnt == 0) start = p;
		cnt += op;
		if (cnt == 0) merged.emplace_back(start,p);
	}
	merged.emplace_back(right,right); // add dummy errand
	return merged;
}

ll computeMinDist(int left, int right, vector<pair<int,int>> &merged)
{
	ll minDist = 2 * (right - left);
	ll start = left; // start of tour
	ll rev = 0;
	for (auto &[l,r] : merged) // (r->l) is the last errand of the route
	{
		ll route = (start - left) + (right - left) + rev + (right - l);
		minDist = min(minDist,route);
		// check whether errand (r -> l) should be run as a reverse errand 
		// during the forward sweep or whether the tour should be started at r
		rev += 2 * (r-l);
		if (start - left + rev > r - left)
		{
			start = r;
			rev = 0;
		}
	}
	return minDist;
}

int main()
{
	int l,n; cin >> l >> n;
	vector<pair<int,int>> fwd, bwd;
	int left = l;
	int right = 1;
	for (int i = 0; i < n; ++i)
	{
		int a,b; cin >> a >> b;
		left = min(left,min(a,b));
		right = max(right,max(a,b));
		if (a < b) fwd.emplace_back(a,b);
		else bwd.emplace_back(a,b);
	}
	vector<pair<int,int>> merged = mergeErrands(right,bwd);
	ll x = computeMinDist(left, right, merged);
	for (auto &[a,b] : fwd) a = -a, b = -b;
	swap(left,right); left = -left; right = -right;
	merged = mergeErrands(right, fwd);
	ll y = computeMinDist(left, right, merged);
	cout << min(x, y) << endl;
}
