/**
 * GCPC 2020 - Exhausting Errands
 *
 * Search for optimal solution using a combination
 * of elevator scan and zigzag scan, runtime O(n^2)
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>

//#define DEBUG

using namespace std;

// Motion from position a to b
struct vec2l { long a, b; };

bool cmp_vec2l_a(const vec2l &x, const vec2l &y)
{ return x.a < y.a; }

bool cmp_vec2l_b(const vec2l &x, const vec2l &y)
{ return x.b < y.b; }

int main()
{
  // Read data
  long l;
  int n;
  vector<vec2l> vecs1, vecs2;
  scanf("%ld %d", &l, &n);
  for (int i = 0; i < n; i++) {
    vec2l x;
    scanf("%ld %ld", &x.a, &x.b);
    if (x.a < x.b)
      vecs1.push_back(x);
    else
      vecs2.push_back(x);
  }

  // Sort and merge motion intervals
  int n1 = vecs1.size();
  if (n1 > 0) {
    int i = 0;
    sort(vecs1.begin(), vecs1.end(), cmp_vec2l_a);
    while (i+1 < n1) {
      while (i+1 < n1 && vecs1[i+1].a <= vecs1[i].b) {
        if (vecs1[i+1].b > vecs1[i].b)
          vecs1[i].b = vecs1[i+1].b;
        vecs1.erase(vecs1.begin() + i+1);
        n1--;
      }
      i++;
    }
  }
  int n2 = vecs2.size();
  if (n2 > 0) {
    int i = 0;
    sort(vecs2.begin(), vecs2.end(), cmp_vec2l_b);
    while (i+1 < n2) {
      while (i+1 < n2 && vecs2[i+1].b <= vecs2[i].a) {
        if (vecs2[i+1].a > vecs2[i].a)
          vecs2[i].a = vecs2[i+1].a;
        vecs2.erase(vecs2.begin() + i+1);
        n2--;
      }
      i++;
    }
  }

  // Compute minimal length of a run which covers all
  // motion intervals with respect to their direction
  long min_dist = 2*l;
  for (int dir = 0; dir < 2; dir++) {
    if (dir == 1) {
      // Mirror data for second computation
      vector<vec2l> tmp = vecs1;
      vecs1 = vecs2;
      vecs2 = tmp;
      n1 = vecs1.size();
      n2 = vecs2.size();
      for (int i = 0; i < n1; i++) {
        vecs1[i].a = l + 1 - vecs1[i].a;
        vecs1[i].b = l + 1 - vecs1[i].b;
      }
      for (int i = 0; i < n2; i++) {
        vecs2[i].a = l + 1 - vecs2[i].a;
        vecs2[i].b = l + 1 - vecs2[i].b;
      }
      reverse(vecs1.begin(), vecs1.end());
      reverse(vecs2.begin(), vecs2.end());
    }
#ifdef DEBUG
    // Debug output
    printf("\nforward:");
    for (int i = 0; i < n1; i++)
      printf(" (%ld, %ld)", vecs1[i].a, vecs1[i].b);
    printf("\nbackward:");
    for (int i = 0; i < n2; i++)
      printf(" (%ld, %ld)", vecs2[i].a, vecs2[i].b);
    printf("\n\n");
#endif
    // Continue if there are no forward motions
    if (vecs1.empty()) {
      continue;
    }
    // Find start and end of forward run
    long a_min = vecs1[0].a, b_max = vecs1[n1-1].b;
    // Return run length if there are no backward motions
    if (vecs2.empty()) {
      min_dist = b_max - a_min;
      break;
    }
    // Partition backward motions into "before", "during"
    // and "after forward run" and compute total running
    // distance for each partion (the motion with index i
    // belongs to class "before" if i < l1, to "after" if
    // i >= l2, to "during" if l1 <= i < l2)
    vector<int> sumDvecs2(n2+1, 0);
    for (int i = 1; i <= n2; i++)
      sumDvecs2[i] = sumDvecs2[i-1] + vecs2[i-1].a - vecs2[i-1].b;
    for (int l1 = 0; l1 <= n2; l1++) {
      for (int l2 = l1; l2 <= n2; l2++) {
        long dist = b_max - a_min;
        // Add backward motions before forward run
        if (l1 > 0)
          dist += vecs2[l1-1].a - vecs2[0].b + abs(vecs2[0].b - a_min);
        // Add backward motions after forward run
        if (l2 < n2)
          dist += vecs2[n2-1].a - vecs2[l2].b + abs(vecs2[n2-1].a - b_max);
        // Add backward motions during forward run
        if (l1 == 0 && l2 > 0 && vecs2[0].a <= a_min)
          dist = 2*l;
        else if (l2 == n2 && l1 < n2 && vecs2[n2-1].a >= b_max)
          dist = 2*l;
        else if (l1 < l2)
          dist += 2*(sumDvecs2[l2] - sumDvecs2[l1]);
        if (dist < min_dist) {
          min_dist = dist;
#ifdef DEBUG
          // Debug output
          if (l1 > 0)
            printf("%ld <- %ld -> ", vecs2[l1-1].a, vecs2[0].b);
          printf("[%ld] ", a_min);
          for (int i = l1; i < l2; i++)
            printf("-> %ld <- %ld ", vecs2[i].a, vecs2[i].b);
          printf("-> [%ld] ", b_max);
          if (l2 < n2)
            printf("-> %ld <- %ld ", vecs2[n2-1].a, vecs2[l2].b);
          printf("[= %ld]\n", dist);
#endif
        }
      }
    }
  }
  printf("%ld\n", min_dist);
  return 0;
}
