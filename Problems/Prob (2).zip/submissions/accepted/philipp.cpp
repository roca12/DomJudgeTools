#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main() {
	ll l, n;
	cin >> l >> n;
	vector<pair<ll,ll>> input(n);
	for(ll i = 0; i < n; i++) {
		ll a, b;
		cin >> a >> b;
		input[i] = {a,b};
	}

	ll res = LLONG_MAX;
	for(ll order = 0; order < 2; order++) {
		map<ll,ll> forw, backw;
		pair<ll,ll> lr = {LLONG_MAX,LLONG_MIN}, rl = {LLONG_MIN,LLONG_MAX};
		for(auto ab : input) {
			ll a = ab.first, b = ab.second;
			if(a < b) {
				forw[a]++;
				forw[b]--;
				lr.first = min(a, lr.first);
				lr.second = max(b, lr.second);
			} else {
				backw[a]++;
				backw[b]--;
				rl.first = max(a, rl.first);
				rl.second = min(b, rl.second);
			}
		}
		if(backw.empty()) {
			cout << lr.second - lr.first << endl;
			return 0;
		}
		if(forw.empty()) {
			cout << rl.first - rl.second << endl;
			return 0;
		}

		vector<pair<ll,ll>> intervals;
		auto it = backw.begin();
		while(it != backw.end()) {
			ll origin = it->first;
			ll open = it->second;
			while(open) {
				it++;
				open += it->second;
			}
			intervals.emplace_back(origin, it->first);
			it++;
		}

		set<ll> leftmost, rightmost;
		leftmost.insert(lr.first);
		leftmost.insert(rl.second);
		rightmost.insert(lr.second);
		rightmost.insert(rl.first);
		for(ll leftest : leftmost) {
			if(leftest > lr.first) {
				continue;
			}
			for(ll rightest : rightmost) {
				if(rightest < lr.second) {
					continue;
				}
				bool lknick = (leftest == *leftmost.begin());
				bool rknick = (rightmost.upper_bound(rightest) == rightmost.end());
				if(!lknick && !rknick) {
					continue;
				}

				vector<pair<ll,ll>> fromle(intervals.size());
				if(lknick) {
					fromle[0].first = fromle[0].second = intervals[0].second - leftest;
					if(intervals[0].first >= leftest && intervals[0].second <= rightest) {
						fromle[0].first = min(fromle[0].first, 2 * (intervals[0].second - intervals[0].first));
					}
					for(ll i = 1; i < intervals.size(); i++) {
						fromle[i].first = fromle[i].second = fromle[i-1].second + intervals[i].second - intervals[i-1].second;
						if(intervals[i].first >= leftest && intervals[i].second <= rightest) {
							fromle[i].first = min(fromle[i].first, fromle[i-1].first + 2 * (intervals[i].second - intervals[i].first));
						}
					}
					res = min(res, rightest - leftest + fromle.back().first);
				}

				vector<pair<ll,ll>> fromri(intervals.size());
				if(rknick) {
					fromri.back().first = fromri.back().second = rightest - intervals.back().first;
					if(intervals.back().first >= leftest && intervals.back().second <= rightest) {
						fromri.back().first = min(fromri.back().first, 2 * (intervals.back().second - intervals.back().first));
					}
					for(ll j = intervals.size()-2; j >= 0; j--) {
						fromri[j].first = fromri[j].second = fromri[j+1].second + intervals[j+1].first - intervals[j].first;
						if(intervals[j].first >= leftest && intervals[j].second <= rightest) {
							fromri[j].first = min(fromri[j].first, fromri[j+1].first + 2 * (intervals[j].second - intervals[j].first));
						}
					}
					res = min(res, rightest - leftest + fromri[0].first);
				}

				if(lknick && rknick) {
					for(ll i = 1; i < intervals.size(); i++) {
						res = min(res, rightest - leftest + fromle[i-1].first + fromri[i].first);
					}
				}
			}
		}

		for(auto& ab : input) {
			ab.first = 1'000'000'001 - ab.first;
			ab.second = 1'000'000'001 - ab.second;
		}
	}

	cout << res << endl;
}
