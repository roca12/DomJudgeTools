import java.util.*;
// Translated from paul.cpp by Sandro.

class PaulMain
{
  public static void main(String[] args)
  {
    PaulMain m = new PaulMain();
    m.run();
  }

  class IntPair implements Comparable<IntPair>
  {
    int a, b;
    IntPair(int a, int b) { this.a = a; this.b = b; }
    @Override
    public int compareTo(IntPair ip) { return this.a - ip.a; }
  }

  void run()
  {
    Scanner scanner = new Scanner(System.in);
    int n = scanner.nextInt();
    n = scanner.nextInt();
	IntPair[] jobs = new IntPair[n];
	for (int i = 0; i < n; i++) {
      int a = scanner.nextInt();
      int b = scanner.nextInt();
      jobs[i] = new IntPair(a, b);
    }
	
	long res = Long.MAX_VALUE;
	for (int dir = 0; dir <= 1; dir++) {
		int xmin = Integer.MAX_VALUE, xmax = Integer.MIN_VALUE;

		List<IntPair> events = new ArrayList<IntPair>();
		for (IntPair ip : jobs) {
			xmin = Math.min(xmin, Math.min(ip.a, ip.b));
			xmax = Math.max(xmax, Math.max(ip.a, ip.b));
			
			if (ip.a > ip.b) {
				events.add(new IntPair(ip.a, 1));
				events.add(new IntPair(ip.b, -1));
			}
		}
        Collections.sort(events);
		
		int balance = 0, start = 0;
		List<IntPair> back_intervals = new ArrayList<IntPair>();
		back_intervals.add(new IntPair(xmin, xmin));
		for (IntPair ip : events) {
			if (balance == 0) start = ip.a;
			balance += ip.b;
			if (balance == 0) back_intervals.add(new IntPair(start, ip.a));
		}
		back_intervals.add(new IntPair(xmax, xmax));

		long best = xmin;
		for (IntPair ip : back_intervals) {
			res = Math.min(res, 2*(xmax-xmin) + best - ip.a);
			best = Math.min(ip.b, best + 2*(ip.b - ip.a));
		}

		for (IntPair ip : jobs) { ip.a = -ip.a; ip.b = -ip.b; }
	}
	System.out.println(res);
  }
}
