#!/usr/bin/python3
# Translated from paul.cpp by Sandro.

INF = float("inf")
line = input().split()
l = int(line[0])
n = int(line[1])
jobs = []
for i in range(n):
	line = input().split()
	a = int(line[0])
	b = int(line[1])
	jobs.append([a, b])

res = INF
for dir in [0, 1]:
	xmin, xmax = INF, -INF
	events = []
	for ip in jobs:
		xmin = min(xmin, min(ip[0], ip[1]))
		xmax = max(xmax, max(ip[0], ip[1]))
		if ip[0] > ip[1]:
			events.append([ip[0], 1])
			events.append([ip[1], -1])
	events.sort(key=lambda ip: ip[0])

	balance, start = 0, 0
	back_intervals = []
	back_intervals.append([xmin, xmin])
	for ip in events:
		if balance == 0:
			start = ip[0]
		balance += ip[1]
		if balance == 0:
			back_intervals.append([start, ip[0]])
	back_intervals.append([xmax, xmax])

	best = xmin
	for ip in back_intervals:
		res = min(res, 2*(xmax-xmin) + best - ip[0])
		best = min(ip[1], best + 2*(ip[1] - ip[0]))
	for ip in jobs:
		ip[0] = -ip[0]
		ip[1] = -ip[1]

print(res)

