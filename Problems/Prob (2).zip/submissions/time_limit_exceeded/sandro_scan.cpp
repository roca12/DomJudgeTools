/**
 * GCPC 2020 - Exhausting Errands
 *
 * Search for optimal solution using a combination
 * of elevator scan and zigzag scan, TLE due to O(n³)
 * computation, better compute sum in line 142 ff. index
 * constant time using sum table (see accepted solution)
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>

using namespace std;

// Motion from position a to b
struct vec2l { long a, b; };

bool cmp_vec2l_a(const vec2l &x, const vec2l &y)
{ return x.a < y.a; }

bool cmp_vec2l_b(const vec2l &x, const vec2l &y)
{ return x.b < y.b; }

int main()
{
  // Read data
  long l;
  int n;
  vector<vec2l> vecs1, vecs2;
  scanf("%ld %d", &l, &n);
  for (int i = 0; i < n; i++) {
    vec2l x;
    scanf("%ld %ld", &x.a, &x.b);
    if (x.a < x.b)
      vecs1.push_back(x);
    else
      vecs2.push_back(x);
  }

  // Sort and merge motion intervals
  int n1 = vecs1.size();
  if (n1 > 0) {
    int i = 0;
    sort(vecs1.begin(), vecs1.end(), cmp_vec2l_a);
    while (i+1 < n1) {
      while (i+1 < n1 && vecs1[i+1].a <= vecs1[i].b) {
        if (vecs1[i+1].b > vecs1[i].b)
          vecs1[i].b = vecs1[i+1].b;
        vecs1.erase(vecs1.begin() + i+1);
        n1--;
      }
      i++;
    }
  }
  int n2 = vecs2.size();
  if (n2 > 0) {
    int i = 0;
    sort(vecs2.begin(), vecs2.end(), cmp_vec2l_b);
    while (i+1 < n2) {
      while (i+1 < n2 && vecs2[i+1].b <= vecs2[i].a) {
        if (vecs2[i+1].a > vecs2[i].a)
          vecs2[i].a = vecs2[i+1].a;
        vecs2.erase(vecs2.begin() + i+1);
        n2--;
      }
      i++;
    }
  }

  // Compute minimal length of a run which covers all
  // motion intervals with respect to their direction
  long min_dist = 2*l;
  for (int dir = 0; dir < 2; dir++) {
    if (dir == 1) {
      // Mirror data for second computation
      vector<vec2l> tmp = vecs1;
      vecs1 = vecs2;
      vecs2 = tmp;
      n1 = vecs1.size();
      n2 = vecs2.size();
      for (int i = 0; i < n1; i++) {
        vecs1[i].a = l + 1 - vecs1[i].a;
        vecs1[i].b = l + 1 - vecs1[i].b;
      }
      for (int i = 0; i < n2; i++) {
        vecs2[i].a = l + 1 - vecs2[i].a;
        vecs2[i].b = l + 1 - vecs2[i].b;
      }
      sort(vecs1.begin(), vecs1.end(), cmp_vec2l_a);
      sort(vecs2.begin(), vecs2.end(), cmp_vec2l_b);
    }
    // Continue if there are no forward motions
    if (vecs1.empty()) {
      continue;
    }
    // Find start and end of forward run
    long p1 = l+1, p2 = 0;
    for (int i = 0; i < n1; i++) {
      vec2l &x = vecs1[i];
      if (x.a < p1)
        p1 = x.a;
      if (x.b > p2)
        p2 = x.b;
    }
    // Return run length if there are no backward motions
    if (vecs2.empty()) {
      min_dist = p2 - p1;
      break;
    }
    // Partition backward motions into "before", "during"
    // and "after forward run" and compute total running
    // distance for each partion (the motion with index i
    // belongs to class "before" if i < l1, to "after" if
    // i >= l2, to "during" if l1 <= i < l2)
    for (int l1 = 0; l1 <= n2; l1++) {
      for (int l2 = l1; l2 <= n2; l2++) {
        long dist = p2 - p1;
        long p_min = p1, p_max = p2;
        // Add backward motions before forward run
        if (l1 > 0) {
          if (p1 > vecs2[0].b) {
            dist += vecs2[l1-1].a + p1 - 2*vecs2[0].b;
            p_min = vecs2[0].b;
          } else {
            dist += vecs2[l1-1].a - p1;
          }
        }
        // Add backward motions after forward run
        if (l2 < n2) {
          if (p2 < vecs2[n2-1].a) {
            dist += 2*vecs2[n2-1].a - p2 - vecs2[l2].b;
            p_max = vecs2[n2-1].a;
          } else {
            dist += p2 - vecs2[l2].b;
          }
        }
        // Add backward motions during forward run
        for (int i = l1; i < l2; i++) {
          if (vecs2[i].a < p_min || vecs2[i].a > p_max) {
            // Set distance to maximum since this case
            // cannot occur in the optimal solution
            dist = 2*l;
            break;
          }
          dist += 2*(vecs2[i].a - vecs2[i].b);
        }
        if (dist < min_dist)
          min_dist = dist;
      }
    }
  }
  printf("%ld\n", min_dist);
  return 0;
}
