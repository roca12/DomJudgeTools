/**
 * GCPC 2020 - Exhausting Errands
 *
 * Search for optimal solution using a combination
 * of elevator scan and zigzag scan, TLE due to O(n³)
 * computation, better compute sum in line 136 ff. index
 * constant time using sum table (see accepted solution)
 */

import java.io.*;
import java.util.*;

class SandroScanMain
{
  public static void main(String[] args)
  {
    SaeScanMain m = new SaeScanMain();
    m.run();
  }

  void run()
  {
    // Read data
    Scanner scanner = new Scanner(System.in);
    List<int[]> vecs1 = new ArrayList<int[]>();
    List<int[]> vecs2 = new ArrayList<int[]>();
    int l = scanner.nextInt();
    int n = scanner.nextInt();
    for (int i = 0; i < n; i++) {
      int[] x = new int[2];
      x[0] = scanner.nextInt();
      x[1] = scanner.nextInt();
      if (x[0] < x[1])
        vecs1.add(x);
      else
        vecs2.add(x);
    }

    // Sort and merge motion intervals
    int n1 = vecs1.size();
    if (n1 > 0) {
      int i = 0;
      vecs1.sort((int[] x, int[] y) -> Integer.compare(x[0], y[0]));
      while (i+1 < n1) {
        while (i+1 < n1 && vecs1.get(i+1)[0] <= vecs1.get(i)[1]) {
          if (vecs1.get(i+1)[1] > vecs1.get(i)[1])
            vecs1.get(i)[1] = vecs1.get(i+1)[1];
          vecs1.remove(i+1);
          n1--;
        }
        i++;
      }
    }
    int n2 = vecs2.size();
    if (n2 > 0) {
      int i = 0;
      vecs2.sort((int[] x, int[] y) -> Integer.compare(x[1], y[1]));
      while (i+1 < n2) {
        while (i+1 < n2 && vecs2.get(i+1)[1] <= vecs2.get(i)[0]) {
          if (vecs2.get(i+1)[0] > vecs2.get(i)[0])
            vecs2.get(i)[0] = vecs2.get(i+1)[0];
          vecs2.remove(i+1);
          n2--;
        }
        i++;
      }
    }

    // Compute minimal length of a run which covers all
    // motion intervals with respect to their direction
    int min_dist = 2*l;
    for (int dir = 0; dir < 2; dir++) {
      if (dir == 1) {
        // Mirror data for second computation
        List<int[]> tmp = vecs1;
        vecs1 = vecs2;
        vecs2 = tmp;
        n1 = vecs1.size();
        n2 = vecs2.size();
        for (int i = 0; i < n1; i++) {
          vecs1.get(i)[0] = l + 1 - vecs1.get(i)[0];
          vecs1.get(i)[1] = l + 1 - vecs1.get(i)[1];
        }
        for (int i = 0; i < n2; i++) {
          vecs2.get(i)[0] = l + 1 - vecs2.get(i)[0];
          vecs2.get(i)[1] = l + 1 - vecs2.get(i)[1];
        }
        vecs1.sort((int[] x, int[] y) -> Integer.compare(x[0], y[0]));
        vecs2.sort((int[] x, int[] y) -> Integer.compare(x[1], y[1]));
      }
      // Continue if there are no forward motions
      if (vecs1.isEmpty()) {
        continue;
      }
      // Find start and end of forward run
      int p1 = l+1, p2 = 0;
      for (int i = 0; i < n1; i++) {
        int[] x = vecs1.get(i);
        if (x[0] < p1)
          p1 = x[0];
        if (x[1] > p2)
          p2 = x[1];
      }
      // Return run length if there are no backward motions
      if (vecs2.isEmpty()) {
        min_dist = p2 - p1;
        break;
      }
      // Partition backward motions into "before", "during"
      // and "after forward run" and compute total running
      // distance for each partion (the motion with index i
      // belongs to class "before" if i < l1, to "after" if
      // i >= l2, to "during" if l1 <= i < l2)
      for (int l1 = 0; l1 <= n2; l1++) {
        for (int l2 = l1; l2 <= n2; l2++) {
          int dist = p2 - p1;
          int p_min = p1, p_max = p2;
          // Add backward motions before forward run
          if (l1 > 0) {
            if (p1 > vecs2.get(0)[1]) {
              dist += vecs2.get(l1-1)[0] + p1 - 2*vecs2.get(0)[1];
              p_min = vecs2.get(0)[1];
            } else {
              dist += vecs2.get(l1-1)[0] - p1;
            }
          }
          // Add backward motions after forward run
          if (l2 < n2) {
            if (p2 < vecs2.get(n2-1)[0]) {
              dist += 2*vecs2.get(n2-1)[0] - p2 - vecs2.get(l2)[1];
              p_max = vecs2.get(n2-1)[0];
            } else {
              dist += p2 - vecs2.get(l2)[1];
            }
          }
          // Add backward motions during forward run
          for (int i = l1; i < l2; i++) {
            if (vecs2.get(i)[0] < p_min || vecs2.get(i)[0] > p_max) {
              // Set distance to maximum since this case
              // cannot occur in the optimal solution
              dist = 2*l;
              break;
            }
            dist += 2*(vecs2.get(i)[0] - vecs2.get(i)[1]);
          }
          if (dist < min_dist)
            min_dist = dist;
        }
      }
    }
    System.out.printf("%d\n", min_dist);
  }

}
