/**
 * GCPC 2020 - Exhausting Errands
 *
 * Exhaustive search for optimal solution with
 * backtracking, will exceed time limit
 */

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>
#include <queue>

#define MAX_NUM 100

using namespace std;

// Positions to visit (odd index = source,
// even index = destination of previous node)
struct node_t { long pos; bool visited; };

node_t nodes[2*MAX_NUM];

bool g_debug = false;

// Backtracking for num nodes, adding the node at
// index idx to route with previous distance dist
long compute(int num, int idx, long pos, long dist, long &dist_min, vector<long> &route)
{
  // Add node at index idx to route
  long d, d_min = -1;
  int num_visited = 0;
  node_t *nptr = nodes + idx;
  dist += abs(pos - nptr->pos);
  pos = nptr->pos;
  nptr->visited = true;
  route.push_back(pos);
  nptr = nodes;
  // Try to append remaining nodes to route
  for (int j = 0; j < num; j++, nptr++) {
    if (nptr->visited) {
      num_visited++;
    } else if (j % 2 == 0 || (nptr-1)->visited) {
      // Check if another visitable node is inbetween
      bool ok = true;
      node_t *nptr2 = nodes;
      long a = nptr->pos < pos ? nptr->pos : pos;
      long b = nptr->pos > pos ? nptr->pos : pos;
      for (int j2 = 0; j2 < num && ok; j2++, nptr2++) {
        if (j2 != j && !nptr2->visited &&
            nptr2->pos > a && nptr2->pos < b &&
            (j2 % 2 == 0 || (nptr2-1)->visited))
          ok = false;
      }
      // Append node to route if there is no visitable
      // node inbetween and proceed recursively
      if (ok) {
        d = compute(num, j, pos, dist, dist_min, route);
        if (d >= 0 && (d < d_min || d_min < 0))
          d_min = d;
      }
    }
  }
  // Check if all nodes have been visited now,
  // update minimal distance if necessary
  if (num_visited < num) {
    dist = d_min >= dist_min ? -1 : d_min;
  } else if (dist < dist_min) {
    dist_min = dist;
    // Debug output when new minimum is found
    if (g_debug) {
      printf("%ld, [", dist_min);
      for (int j = 0; j+1 < num; j++)
        printf("%ld, ", route[j]);
      printf("%ld]\n", route[num-1]);
    }
  }
  // Backtracking step
  nodes[idx].visited = false;
  route.pop_back();
  return dist;
}

int main(int argv, char* args[])
{
  // Set debug flag
  if (argv > 1 && strcmp(args[1], "--debug") == 0)
    g_debug = true;
  // Read data
  long l, a, b;
  int n;
  scanf("%ld %d", &l, &n);
  node_t *nptr = nodes;
  for (int i = 0; i < n; i++) {
    scanf("%ld %ld", &a, &b);
    nptr->pos = a;
    nptr->visited = false;
    nptr++;
    nptr->pos = b;
    nptr->visited = false;
    nptr++;
  }
  // Compute best solution via backtracking
  long dist_min = 2*l;
  vector<long> route;
  for (int i = 0; i < n; i++)
    compute(2*n, 2*i, nodes[2*i].pos, 0, dist_min, route);
  printf("%ld\n", dist_min);
  return 0;
}
