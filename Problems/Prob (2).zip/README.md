Exhausting Errands
===

Problem
---

Given are L houses arranged in a linear row with equal distance of 1 unit
between subsequent houses, and N errands of the form "pick up a package at
house a and deliver it to house b". The aim is to find the minimal distance
that has to be covered from starting the first errand until finishing the
final errand. The errands can be completed in any order (i.e., the starting
position can be chosen arbitrarily), and the deliverer can carry an unlimited
amount of packages at the same time (i.e., an errand does not have to be
finished to start another errand).

The number of house is limited by 1 <= L <= 10^9, and the number of errands is
limited by 1 <= N <= 10^5. The i-th errand (1 <= i <= N) is defined by a pickup
location a_i and destination b_i with 1 <= a_i <= L, 1 <= b_i <= L, and a != b.

Solution
---

Naturally, the errands are described by a list of integer pairs. Sorting them
by starting position and keeping different lists for "forward motions" (i.e.,
a_i < b_i)  and "backward motions" (a_i > b_i) should be helpful.

An exhaustive check for all feasible schedules or recursive testing with back-
tracking is far to expensive and should lead to exceeding the time limit for
approximately > 10 distinct pairs (a_i, b_i).

The optimal solution can be found by completing all errands i with a_i < b_i
during a scan from left to right, while completing all errands with a_i > b_i
either before the forward scan during an initial backward scan, after the scan
during a final backward scan, or during the forward scan by stepping back part
of the way. This can be done quite straight-forward in O(n^2) time and should
also be possible in O(n) time.

The provided example solution consists of the followed steps:

- Partition errands into forward and backward motions (denoted as sets F, B).
- Sort motions by starting position in ascending order (e.g., sort pairs (a, b)
  in F by a and pairs (a, b) in B by b).
- Merge errands with overlapping motions, but merge only motions with the same
  same direction (i.e., process sets F and B separately). Since F and B are
  sorted, this is done in O(n) time.
- The distance to cover all motions in F during a forward scan is given by:  
  max{b | (a, b) in F} - min{a | (a, b) in F}
- The remaining motions in B are partioned into classes "before", "during" and
  "after" (e.g., by parameters lambda, mu with 0 <= lambda <= mu <= |B|, so that
  the first lambda motions are appended before, the last |B| - mu after, and the
  remaining motions during the forward scan). For each partition the distance
  is updated appropriately to find the minimal total distance.

Note that all (n+1)*(n+2) possible partitions of the backward motions can be
tested in O(n^2) which is inside the time limit for the given problem size.

To find the optimal solution with this strategy, a second run must be performed
where the direction of a all errands is flipped (e.g., each (a_i, b_i) in the
input is replaced by (L+1-a_i, L+1-b_i)).

Variants
---

By reducing max. N to 10^4, the O(n^2) solution for finding the best partition
of the backward motions would also be feasible within the time limit.

A less complicated variant of the problem can be derived as follows: We just
add the constraint that for all errands we have a_i < b_i, but the messenger
must also proceed to the leftmost position 0 after finishing the last errand.
Now we only need a forward scan from some starting position covering part of
the errands (after sorting and merging the motions as described above), while
the remaining errands are completed during the following backward scan to the
leftmost position 0. Testing all starting positions is done in O(n) time.

A very simple variant of the problem states that only those distances matter,
where the deliverer is carrying at least one package. The problem can already
be solved after the merging step by summing up the lengths of all resulting
motion intervals.
