#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

// Checks whether points (x1,y1), (x2,y2), (x3,y3) are collinear.
bool collinear(int x1, int y1, int x2, int y2, int x3, int y3) {
  // Promote integers to avoid overflow.
  long long a1 = x1, b1 = y1, a2 = x2, b2 = y2, a3 = x3, b3 = y3;
  return (a2 - a1)*(b3 - b1) == (b2 - b1)*(a3 - a1);
}

int main() {
  // Store the coordinates of the points.
  int n;
  cin >> n;

  vector<int> x(n), y(n);
  for(int i = 0; i < n; i++) {
    cin >> x[i] >> y[i];
  }

  // If there are no more than 4 points, 2 lines always cover them.
  if(n <= 4) {
    cout << "success" << endl;
    return 0;
  }

  // Attempt to find one of the 2 lines.
  bool found = false;
  int i,j,k;

  for(i = 0; i < 5; i++) {
    for(j = i + 1; j < 5; j++) {
      for(k = j + 1; k < 5; k++) {
        if(collinear(x[i],y[i],x[j],y[j],x[k],y[k])) {
          found = true;
          break;
        }
      }
      if(found)
        break;
    }
    if(found)
      break;
  }

  
  if(!found) {
    // Two lines cover at most 4 of the first 5 points.
    cout << "failure" << endl;
    return 0;
  }

  // Points i, j, k must form one of the 2 lines. So we collect all
  // points not on that line.
  vector<int> xr, yr;
  for(int m = 0; m < n; m++) {
    if(!collinear(x[i],y[i],x[j],y[j],x[m],y[m])) {
      xr.push_back(x[m]);
      yr.push_back(y[m]);
    }
  }

  // If at most two points are not on the first line, then another
  // line will suffice.
  if(xr.size() <= 2) {
    cout << "success" << endl;
    return 0;
  }
  
  // Otherwise, all remaining points must lie on the line through any two 
  // remaining points.

  for(i = 0; i < (int) xr.size(); i++) {
    if(!collinear(xr[0],yr[0],xr[1],yr[1],xr[i],yr[i])) {
      cout << "failure" << endl;
      break;
    }
  }
  
  // If we didn't find any points off the line through the first two
  // remaining points, we win.
  if(i == (int) xr.size()) {
    cout << "success" << endl;
  }
  return 0;
}

