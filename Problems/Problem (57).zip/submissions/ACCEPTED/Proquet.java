import java.io.*;
import java.util.*;
import java.math.*;

public class Proquet {
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

	public Proquet() {}

	public static void main(String[] args) throws Exception {
		new Proquet().doProblem();
	}

	public void doProblem() throws Exception {
		solve();
	}

	public void solve() throws Exception {
		boolean result = this.solve(false);
		if (result) System.out.println("success");
		else System.out.println("failure");
	}

	public boolean solve(boolean verbose) throws Exception {
		String input = in.readLine();
		int n = Integer.parseInt(input);
		ArrayList<point> inPoints = new ArrayList<point>();
		ArrayList<point> points = new ArrayList<point>();
		for (int i = 0; i < n; i++) {
			inPoints.add(readPoint());
		}

		line first_line = null;
		boolean first_line_found = false;
		line second_line = null;
		boolean second_line_found = false;
		int points_not_on_first_line = 0;

		boolean result = true;
		boolean result_determined = false;
		for (int i = 0; i < n; i++) {
			point p = inPoints.get(i);
			points.add(p);

			if (verbose) System.out.println(p);
			if (result_determined) continue;

			// Determine whether the next point is collinear with the first points
			if (!first_line_found) {
				// Try to find three points that are on a single line
				first_line = findLine(points, p);
				if (first_line != null) {
					if (verbose) System.out.println("First line found: " + first_line);
					first_line_found = true;
					// Remove the points on the line, as we don't need to check them anymore
					points.remove(first_line.p1);
					points.remove(first_line.p2);
				}
				if (!first_line_found && i == 4) {
					result = false;
					result_determined = true; // Continue reading all lines
				}
			}
			// If we already found a line, determine whether the next point is collinear with this line
			else if (!collinear(first_line.p1.x, first_line.p1.y, first_line.p2.x, first_line.p2.y, p.x, p.y)) {
				// The point is not on the same line. So we have to find another line
				++points_not_on_first_line;
				// Try to find three points that are on a single line
				if (!second_line_found) {
					second_line = findLine(points, p);
					if (second_line != null) {
						// Second line was found!
						second_line_found = true;
						if (verbose) System.out.println("Second line found: " + second_line);
						// Remove the points on the line, as we don't need to check them anymore
						points.remove(second_line.p1);
						points.remove(second_line.p2);
					}
				}
				// If a second line was already found and the new point is not one the first or second line, then we have to have a third line, which is too much 
				if (second_line_found) {
					if (!collinear(second_line.p1.x, second_line.p1.y, second_line.p2.x, second_line.p2.y, p.x, p.y)) {
						// We have two lines, but that's still not enough... So we lose!
						if (verbose) System.out.println("This point requires third line: " + p);
						result = false;
						result_determined = true; // Continue reading all lines
					}
					else { // The found point was collinear with the second line, so we remove it from the list of points as we don't have to check it anymore
						if (verbose) System.out.println("Point is not on first line, but it is on the second line: " + p);
						if (points.indexOf(p) != -1) points.remove(p);
					}
				}
			}
			else // The found point was collinear with the first line, so we remove it from the list of points as we don't have to check it anymore
            	points.remove(p);
		}
    
		// Return the answer
		if (n <= 4) return true; // 4 points can always be connected by two lines
		if (verbose) System.out.println("Result determined: " + result_determined + ", result: " + result);
		if (verbose) System.out.println("Points not on first line: " + points_not_on_first_line + ", first_line_found: " + first_line_found + ", second_line_found: " + second_line_found);
		if (result_determined) return result;
		if (points_not_on_first_line > 2 && !second_line_found) return false;
		return true;
	}

	public point readPoint() throws Exception {
		String input = in.readLine();
		String[] x_y = input.split(" ");
		BigInteger x = new BigInteger(x_y[0]);
		BigInteger y = new BigInteger(x_y[1]);
		return new point(x, y);
	}

	public line findLine(ArrayList<point> points, point p) {
		for (int j = 0; j < points.size(); j++) {
			point pj = points.get(j);
			if (pj == p) continue;

			for (int k = j + 1; k < points.size(); k++) {
				point pk = points.get(k);
				if (pk == p) continue;
				if (collinear(pj.x, pj.y, pk.x, pk.y, p.x, p.y))
					return new line(pj, p);
			}
		}
		return null;
	}

    public boolean collinear(BigInteger x1, BigInteger y1, BigInteger x2, BigInteger y2, BigInteger x3, BigInteger y3) {
        BigInteger dx12 = x2.subtract(x1);
        BigInteger dy12 = y2.subtract(y1);
        BigInteger dx23 = x3.subtract(x2);
        BigInteger dy23 = y3.subtract(y2);
		
        return equal(dx12, dy12, dx23, dy23);
    }

    public boolean equal(BigInteger a1, BigInteger b1, BigInteger a2, BigInteger b2) {
		return a1.multiply(b2).equals(a2.multiply(b1));
    }

	public class line {
        public point p1, p2;
		public line(point p1, point p2) { this.p1 = p1; this.p2 = p2; }
		public String toString() {
			return "[" + p1 + " => " + p2 + "]";
		}
	}

	public class point {
		public BigInteger x, y;
		public point(BigInteger _x, BigInteger _y) { x = _x; y = _y; }
        public boolean Equals(Object o) {
            point p = (point)o;
            return this.x == p.x && this.y == p.y;
        }
		public String toString() {
			return "(" + this.x + "," + this.y + ")";
		}
	}
}
