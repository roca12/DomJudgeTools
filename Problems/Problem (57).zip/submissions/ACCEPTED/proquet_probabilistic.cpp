#include <iostream>

using namespace std;

int n;
long long x[100100], y[100100];

bool areCollinear(long long x1, long long y1, long long x2, long long y2, long long x3, long long y3) {
	return (x1*y2 + x2*y3 + x3*y1 == x1*y3 + x2*y1 + x3*y2);
}

bool tryit(int r1, int r2){
	if (r1 == r2)
		return false;
	bool done[100100];
	int notdone1 = -1;
	int notdone2 = -1;
	for (int i = 0; i < n; i++) {
		if (areCollinear(x[r1], y[r1], x[r2], y[r2], x[i], y[i])) {
			done[i] = true;
		} else {
			done[i] = false;
			if (notdone1 == -1) {
				notdone1 = i;
			} else if (notdone2 == -1) {
				notdone2 = i;
			}
		}
	}
	if (notdone2 == -1)
		return true;
	for (int i = 0; i < n; i++) {
		if (areCollinear(x[notdone1], y[notdone1], x[notdone2], y[notdone2], x[i], y[i]))
			done[i] = true;
		if (!(done[i]))
			return false;
	}
	return true;	
}

int main () {
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> x[i] >> y[i];
	for (int i = 0; i < 100; i++)
		if (tryit(rand() % n, rand() % n)) {
			cout << "success\n";
			return 0;
		}
	cout << "failure\n";
	return 0;
}

