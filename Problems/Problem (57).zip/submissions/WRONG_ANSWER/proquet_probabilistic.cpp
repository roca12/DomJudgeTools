#include <iostream>

using namespace std;

int n;
long long x[100100], y[100100];

bool areCollinear(long long x1, long long y1, long long x2, long long y2, long long x3, long long y3) {
	return (x1*y2 + x2*y3 + x3*y1 == x1*y3 + x2*y1 + x3*y2);
}

bool tryit(){
	int r[5];
	r[0] = rand() % n;
	r[1] = r[2] = r[3] = r[4] = r[0];
	while (r[0] == r[1])
		r[1] = rand() % n;
	while ((r[0] == r[2]) || (r[1] == r[2]))
		r[2] = rand() % n;
	while ((r[0] == r[3]) || (r[1] == r[3]) || (r[2] == r[3]))
		r[3] = rand() % n;
	while ((r[0] == r[4]) || (r[1] == r[4]) || (r[2] == r[4]) || (r[3] == r[4]))
		r[4] = rand() % n;
	for (int i = 0; i < 3; i++)
	for (int j = i+1; j < 4; j++)
	for (int k = j+1; k < 5; k++)
		if (areCollinear(x[r[i]], y[r[i]], x[r[j]], y[r[j]], x[r[k]], y[r[k]]))
			return true;
	return false;
}

int main () {
	cin >> n;
	if (n < 5) {
		cout << "sucess\n";
		return 0;
	}
	for (int i = 0; i < n; i++)
		cin >> x[i] >> y[i];
	for (int i = 0; i < 1000000; i++)
		if (!(tryit())) {
			cout << "failure\n";
			return 0;
		}
	cout << "success\n";
	return 0;
}

