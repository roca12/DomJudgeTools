#include <vector>
#include <set>
#include <tuple>
#include <cmath>
#include <iostream>
using namespace std;

const int TASKS = 51;
const int LEN = 2001;
vector<vector<vector<int>>> dpA(TASKS, vector<vector<int>>(TASKS,vector<int>(LEN,1e8)));
vector<vector<vector<int>>> dpB(TASKS, vector<vector<int>>(TASKS,vector<int>(LEN,1e8)));
vector<int> taskA(TASKS);
vector<int> taskB(TASKS);

void performTaskA(int i, int j, int posA, int posB, int val)
{
	// number of steps for crane A to finish next task
    int stepsA = abs(posA - taskA[i+1]) + 1; 
    // in case crane B would hit crane A, adjust target position
	int targetB = taskB[j+1] <= taskA[i+1] ? taskA[i+1]+1 : taskB[j+1]; 
	// crane B moves toward its next target but cannot use more steps than A
	int stepsB = min(stepsA, abs(posB - targetB));
	// crane B is using its steps to move towards its target position
	int nxtB = posB < targetB ? posB + stepsB : posB - stepsB;
	dpA[i+1][j][nxtB] = min(dpA[i+1][j][nxtB], val + stepsA);
}

void performTaskB(int i, int j, int posA, int posB, int val)
{
	int stepsB = abs(posB - taskB[j+1]) + 1;
	int targetA = taskA[i+1] >= taskB[j+1] ? taskB[j+1]-1 : taskA[i+1];
	int stepsA = min(stepsB, abs(posA - targetA));
	int nxtA = posA < targetA ? posA + stepsA : posA - stepsA;
	dpB[i][j+1][nxtA] = min(dpB[i][j+1][nxtA], val + stepsB);
}

void performTaskAB(int i, int j, int posA, int posB, int val)
{
    int nxtA = taskA[i+1];
    int nxtB = taskB[j+1];
    // return if cranes would hit each other
    if (nxtA >= nxtB) return;
    int stepsA = abs(posA - nxtA) + 1;
    int stepsB = abs(posB - nxtB) + 1;
    // if both cranes need a different number of steps, then only one
    // crane can perform its next operation. This case was covered before.
    if (stepsA != stepsB) return; 
    dpA[i+1][j+1][nxtB] = min(dpA[i+1][j+1][nxtB], val + stepsA);
    dpB[i+1][j+1][nxtA] = min(dpB[i+1][j+1][nxtA], val + stepsA);
}

int main()
{
    int n, a, b;
    cin >> n >> a >> b;
    for (int i = 0; i < a; ++i)
        cin >> taskA[i];
    for (int i = 0; i < b; ++i)
        cin >> taskB[i];
    taskA[a] = 1;
    taskB[b] = n;
    dpA[0][0][n] = 1;
    dpB[0][0][1] = 1;
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            for (int posB = taskA[i]+1; posB <= n; ++posB)
            {
                int posA = taskA[i];
                int val = dpA[i][j][posB];
                performTaskA(i,j,posA,posB,val);
                performTaskB(i,j,posA,posB,val);
                performTaskAB(i,j,posA,posB,val);
            }
            for (int posA = 1; posA < taskB[j]; ++posA)
            {
                int posB = taskB[j];
                int val = dpB[i][j][posA];
                performTaskA(i,j,posA,posB,val);
                performTaskB(i,j,posA,posB,val);
                performTaskAB(i,j,posA,posB,val);
            }
        }
    }
    cout << min(dpA[a-1][b-1][n], dpB[a-1][b-1][1]) << endl;
}
