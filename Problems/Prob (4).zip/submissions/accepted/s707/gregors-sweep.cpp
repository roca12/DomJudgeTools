#include <vector>
#include <set>
#include <tuple>
#include <cmath>
#include <iostream>
using namespace std;

const int TASKS = 51;
const int LEN = 2005;

vector<vector<vector<int>>> dpA(TASKS, vector<vector<int>>(TASKS,vector<int>(LEN,1e9)));
vector<vector<vector<int>>> dpB(TASKS, vector<vector<int>>(TASKS,vector<int>(LEN,1e9)));
vector<vector<vector<tuple<int,int,int>>>> intervalsA(TASKS,vector<vector<tuple<int,int,int>>>(TASKS));
vector<vector<vector<tuple<int,int,int>>>> intervalsB(TASKS,vector<vector<tuple<int,int,int>>>(TASKS));
vector<vector<int>> events(LEN);

void updateDP(vector<int> &dp, vector<tuple<int,int,int>> &intervals, int from, int to) 
{
	for (auto [i,j,v]: intervals) 
	{
		events[i].push_back(v);
		events[j+1].push_back(-v);
	}
	multiset<int> active;
	for (int i = from; i <= to; i++) 
	{
		for (int v: events[i]) 
		{
			if (v > 0) 
				active.insert(v);
			else 
				active.erase(active.find(-v));
		}
		if (!active.empty()) 
			dp[i] = min(dp[i], *begin(active));
	}
	for (int i = from+1; i <= to; i++)
		dp[i] = min(dp[i], dp[i-1]+1);
	for (int i = to-1; i >= from; i--)
		dp[i] = min(dp[i], dp[i+1]+1);
	for (int i = from; i <= to+1; ++i)
		events[i].clear();
}


pair<int,int> limitRange(int low, int high, int a, int b)
{
	return {max(low,a-b),min(high,a+b)};
}


void performTaskA(int n, int i, int j, int posA, int posB, int nxtA, int val)
{
	int stepsA = abs(nxtA - posA) + 1;
	pair<int,int> range = limitRange(nxtA+1, n, posB, stepsA);
	intervalsA[i+1][j].emplace_back(range.first, range.second, val + stepsA);
}


void performTaskB(int i, int j, int posA, int posB, int nxtB, int val)
{
	int stepsB = abs(nxtB - posB) + 1;
	pair<int,int> range = limitRange(1, nxtB-1, posA, stepsB);
	intervalsB[i][j+1].emplace_back(range.first, range.second, val + stepsB);
}


void performTaskAB(int i, int j, int posA, int posB, int nxtA, int nxtB, int val)
{
	if (nxtA > nxtB) 
		return;
	int stepsA = abs(nxtA - posA) + 1;
	int stepsB = abs(nxtB - posB) + 1;
	dpA[i+1][j+1][nxtB] = min(dpA[i+1][j+1][nxtB], val + max(stepsA,stepsB));
	dpB[i+1][j+1][nxtA] = min(dpB[i+1][j+1][nxtA], val + max(stepsA,stepsB));
}


int main() 
{
	int n, a, b;
	cin >> n >> a >> b;
	vector<int> taskA(a);
	vector<int> taskB(b);
	for (int i = 0; i < a; ++i)
		cin >> taskA[i];
	for (int i = 0; i < b; ++i)
		cin >> taskB[i];
	taskA.push_back(1);
	taskB.push_back(n);
	dpA[0][0][n] = 1;
	dpB[0][0][1] = 1;
	
	for (int i = 0; i < a; i++) 
	{
		for (int j = 0; j < b; j++) 
		{
			updateDP(dpA[i][j], intervalsA[i][j], taskA[i]+1, n);
			updateDP(dpB[i][j], intervalsB[i][j], 1, taskB[j]-1);
			for (int posB = taskA[i]+1; posB <= n; posB++) 
			{
				performTaskA(n, i, j, taskA[i], posB, taskA[i+1], dpA[i][j][posB]);
				performTaskB(i, j, taskA[i], posB, taskB[j+1], dpA[i][j][posB]);
				performTaskAB(i, j, taskA[i], posB, taskA[i+1], taskB[j+1], dpA[i][j][posB]);
			}
			for (int posA = 1; posA < taskB[j]; posA++) 
			{
				performTaskA(n, i, j, posA, taskB[j], taskA[i+1], dpB[i][j][posA]);
				performTaskB(i, j, posA, taskB[j], taskB[j+1], dpB[i][j][posA]);
				performTaskAB(i, j, posA, taskB[j], taskA[i+1], taskB[j+1], dpB[i][j][posA]);
			}
		}
	}
	cout << dpA[a-1][b-1][n] << endl;
}
