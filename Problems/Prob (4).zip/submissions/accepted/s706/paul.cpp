#include <bits/stdc++.h>
using namespace std;

void self_min(int &a, int b) { a = min(a,b); }

/* Find the minimal number of steps needed to get to certain configurations:
 * 
 * dpa[i][j][y]: A completed i tasks, B completed j tasks, A is at p[i-1], B is at y
 * dpb[i][j][x]: A completed i tasks, B completed j tasks, A is at x, B is at q[j-1]
 */

int dpa[51][51][2001], dpb[51][51][2001];

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> p(a), q(b);
	for (int &x: p) cin >> x;
	for (int &y: q) cin >> y;
	p.push_back(1);
	q.push_back(n);

	memset(dpa, 0x3f, sizeof dpa);
	memset(dpb, 0x3f, sizeof dpb);

	auto approachB = [&](int x, int y, int goal, int dt) {
		int ymin = max(x+1, y-dt), ymax = y+dt;
		return goal < ymin ? ymin : goal > ymax ? ymax : goal;
	};

	auto approachA = [&](int x, int y, int goal, int dt) {
		int xmin = x-dt, xmax = min(y-1, x+dt);
		return goal < xmin ? xmin : goal > xmax ? xmax : goal;
	};

	/* From every configuration, either crane A or crane B is the next to
	 * finish a task. Try both possibilities.
	 *
	 * One crane is moved to its next task, the other crane is moved so that no
	 * crash occurs and it is as close as possible to its next task. The first
	 * crane then finishes a task, the other crane uses that time step to
	 * either finish a task itself or move one step closer to its next task.
	 */
	auto process = [&](int i, int j, int x, int y, int t) {
		if (i < a) {
			int dt = abs(p[i]-x);
			int nj = j, ny = approachB(p[i], y, q[j], dt);
			if (ny == q[j]) nj = min(j+1,b);
			else ny = approachB(p[i], y, q[j], dt+1);
			self_min(dpa[i+1][nj][ny], t+dt+1);
		}
		if (j < b) {
			int dt = abs(q[j]-y);
			int ni = i, nx = approachA(x, q[j], p[i], dt);
			if (nx == p[i]) ni = min(i+1,a);
			else nx = approachA(x, q[j], p[i], dt+1);
			self_min(dpb[ni][j+1][nx], t+dt+1);
		}
	};

	dpa[1][1][n] = dpb[1][1][1] = 1;

	for (int i = 1; i <= a; i++) {
		for (int j = 1; j <= b; j++) {
			for (int y = n; y > p[i-1]; y--) {
				process(i, j, p[i-1], y, dpa[i][j][y]);
			}
			for (int x = 1; x < q[j-1]; x++) {
				process(i, j, x, q[j-1], dpb[i][j][x]);
			}
		}
	}
	
	cout << min(dpa[a][b][n], dpb[a][b][1]) << endl;
}
