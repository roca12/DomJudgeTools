// This solution is a straightforward breadth-first search that runs in O(a*b*n*n)
// This should give a RTE because the size of the distance array exceeds the memory limit.
#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> u(a), v(b);
	for (int &x: u) cin >> x, x--;
	for (int &y: v) cin >> y, y--;

	/* dist[i][j][x][y]: the minimal number of steps needed to reach a configuration where
	 *                   A last visited u[i] and is at x, B last visited v[j] and is at y
	 */
	
	int dist[a][b][n][n];
	memset(dist,-1,sizeof dist);

	queue<tuple<int,int,int,int>> q;

	q.emplace(0,0,0,n-1);
	dist[0][0][0][n-1] = 1;
	
	while (!q.empty()) {
		auto [i,j,x,y] = q.front();
		q.pop();

		if (i == a-1 && j == b-1) {
			cout << dist[i][j][x][y] << endl;
			return 0;
		}
		
		for (int nx = max(0,x-1); nx <= min(n-1,x+1); nx++) {
			for (int ny = max(0,y-1); ny <= min(n-1,y+1); ny++) {
				if (nx >= ny) continue;
				int ni = i + (i+1 < a && x == nx && x == u[i+1]);
				int nj = j + (j+1 < b && y == ny && y == v[j+1]);
				
				if (dist[ni][nj][nx][ny] != -1) continue;
				q.emplace(ni,nj,nx,ny);
				dist[ni][nj][nx][ny] = dist[i][j][x][y] + 1;
			}
		}
	}
}
