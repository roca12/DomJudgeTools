// This is a simplified version of `paul.cpp` without optimization.
// The time complexity is O(a*b*n*n).

#include <bits/stdc++.h>
using namespace std;

void self_min(int &x, int y) { x = min(x,y); }

const int N = 2005;

struct dp_row {
	int from, to, val[N];

	dp_row(int from, int to): from(from), to(to) {
		memset(val,0x3f,sizeof val);
	}

	void add_update(int a, int b, int c) {
		for (int i = from; i <= to; i++) {
			self_min(val[i], max(abs(i-a),b) + c);
		}
	}

	void process_updates() { } // only used in the sweep solution

	int &operator[](int i) { return val[i]; }
};

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> p(a), q(b);
	for (int &x: p) cin >> x;
	for (int &y: q) cin >> y;
	p.push_back(1), q.push_back(n);

	/* Find the minimal number of steps needed to get to certain configurations:
	 * 
	 * dpa[i][j][y]: A last visited p[i], B last visited q[j], A is at p[i], B is at y
	 * dpb[i][j][x]: A last visited p[i], B last visited q[j], A is at x, B is at q[j]
	 */

	vector<vector<dp_row>> dpa(a+1), dpb(a+1);
	for (int i = 0; i <= a; i++) {
		for (int j = 0; j <= b; j++) {
			dpa[i].emplace_back(p[i]+1, n);
			dpb[i].emplace_back(1, q[j]-1);
		}
	}
	
	dpa[0][0][n] = dpb[0][0][1] = 1;
	
	for (int i = 0; i < a; i++) {
		for (int j = 0; j < b; j++) {
			dpa[i][j].process_updates();
			for (int y = p[i]+1; y <= n; y++) {
				int goa = abs(p[i+1]-p[i]) + 1, gob = abs(q[j+1]-y) + 1;
				
				dpa[i+1][j].add_update(y, goa, dpa[i][j][y]);

				dpb[i][j+1].add_update(p[i], gob, dpa[i][j][y]);

				self_min(dpa[i+1][j+1][q[j+1]], dpa[i][j][y] + max(goa,gob));
			}
			
			dpb[i][j].process_updates();
			for (int x = 1; x < q[j]; x++) {
				int goa = abs(p[i+1]-x) + 1, gob = abs(q[j+1]-q[j]) + 1;
				
				dpa[i+1][j].add_update(q[j], goa, dpb[i][j][x]);

				dpb[i][j+1].add_update(x, gob, dpb[i][j][x]);

				self_min(dpa[i+1][j+1][q[j+1]], dpb[i][j][x] + max(goa,gob));
			}
		}
	}

	cout << dpa[a-1][b-1][n] << endl;
}
