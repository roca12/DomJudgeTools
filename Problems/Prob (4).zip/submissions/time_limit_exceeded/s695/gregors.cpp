#include <iostream>
#include <vector>
#include <utility>
#include <set>
#include <tuple>
#include <stack>
using namespace std;
const int INF = 1e9;

vector<pair<int,int>> commands(int len)
{
    vector<int> prog(len);
    for (int i = 0; i < len; ++i) cin >> prog[i];
    vector<pair<int,int>> c;
    int pos = prog[0];
    for (int i = 0; i < len; ++i)
    {
        int dir = pos < prog[i] ? 1 : -1;
        while (pos != prog[i])
        {
            c.emplace_back(pos,pos+dir);
            pos += dir;
        }
        c.emplace_back(prog[i],prog[i]);
    }
    return c;
}

vector<int> sidesteps(vector<pair<int,int>> &c)
{
    vector<int> step(c.size(),-1);
    stack<int> s;
    for (int i = 0; i < c.size(); ++i)
    {
        if (c[i].first == c[i].second) continue;
        if (s.empty() || c[i] != make_pair(c[s.top()].second,c[s.top()].first))
            s.push(i);
        else
        {
            step[s.top()] = i+1;
            s.pop();
        }
    }
    return step;
}

bool compatibleOps(pair<int,int> &op1, pair<int,int> &op2)
{return !((op1.second == op2.second) || (op1.first == op2.second && op2.first == op1.second));}

void updateDist(set<tuple<int,int,int>> &pq, vector<vector<int>> &dist, int x, int y, int w)
{
    if (w < dist[x][y])
    {
        pq.erase({dist[x][y],x,y});
        dist[x][y] = w;
        pq.insert({w,x,y});
    }
}

int main()
{
    int n, a, b; cin >> n >> a >> b;
    vector<pair<int,int>> c1 = commands(a);
    vector<pair<int,int>> c2 = commands(b);
    vector<int> s1 = sidesteps(c1);
    vector<int> s2 = sidesteps(c2);
    vector<vector<int>> dist(c1.size()+1,vector<int>(c2.size()+1,INF));
    dist[0][0] = 0;
    set<tuple<int,int,int>> pq {{0,0,0}};
    while (!pq.empty())
    {
        auto [w,x,y] = *pq.begin();
        pq.erase(pq.begin());
        // both cranes are done
        if (x == c1.size() && y == c2.size()) break;
        // one of the cranes is done
        if (x == c1.size() || y == c2.size())
        {
            updateDist(pq,dist,(int)c1.size(),(int)c2.size(),(int)(w+c1.size()+c2.size()-x-y));
            continue;
        }
        // operate both
        if (compatibleOps(c1[x],c2[y])) updateDist(pq,dist,x+1,y+1,w+1);
        // operate c1, idle c2
        pair<int,int> idle2 = {c2[y].first,c2[y].first};
        if (compatibleOps(c1[x],idle2)) updateDist(pq,dist,x+1,y,w+1);
        // idle c1, operate c2
        pair<int,int> idle1 = {c1[x].first,c1[x].first};
        if (compatibleOps(idle1,c2[y])) updateDist(pq,dist,x,y+1,w+1);
        // operate c1, sidestep c2
        if (s1[x] != -1) updateDist(pq,dist,s1[x],y,w+s1[x]-x);
        // operate c2, sidestep c1
        if (s2[y] != -1) updateDist(pq,dist,x,s2[y],w+s2[y]-y);
    }
    cout << dist[c1.size()][c2.size()] << endl;
}
