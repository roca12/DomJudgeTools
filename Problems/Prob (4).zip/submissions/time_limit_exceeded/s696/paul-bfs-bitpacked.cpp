// Optimized version of the breadth-first search solution, time complexity is O(a*b*n*n)
// This should fit in the memory limit, but should time out on large cases.
#include <bits/stdc++.h>
using namespace std;

const int N = 2000, K = 50, Q = 1234567;
bitset<N> mark[K][K][N];
using ll = long long;
ll qu[Q];

ll encode(int dist, int i, int j, int x, int y) {
	return (((((((ll(dist) << 6) | i) << 6) | j) << 11) | x) << 11) | y;
}

void decode(ll pack, int &dist, int &i, int &j, int &x, int &y) {
	dist = pack >> 34;
	i = (pack >> 28) % (1 << 6);
	j = (pack >> 22) % (1 << 6);
	x = (pack >> 11) % (1 << 11);
	y = pack % (1 << 11);
}

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> u(a), v(b);
	for (int &x: u) cin >> x, x--;
	for (int &y: v) cin >> y, y--;

	int qh = 0, qt = 1;
	qu[0] = encode(1,0,0,0,n-1);
	mark[0][0][0][n-1] = 1;

	while (qh != qt) {
		int dist, i, j, x, y;
		decode(qu[qh],dist,i,j,x,y);
		if (++qh == Q) qh = 0;

		if (i == a-1 && j == b-1) {
			cout << dist << endl;
			return 0;
		}

		for (int nx = max(0,x-1); nx <= min(n-1,x+1); nx++) {
			for (int ny = max(0,y-1); ny <= min(n-1,y+1); ny++) {
				if (nx >= ny) continue;
				int ni = i + (i+1 < a && x == nx && x == u[i+1]);
				int nj = j + (j+1 < b && y == ny && y == v[j+1]);

				if (mark[ni][nj][nx][ny]) continue;
				mark[ni][nj][nx][ny] = 1;

				qu[qt] = encode(dist+1,ni,nj,nx,ny);
				if (++qt == Q) qt = 0;
			}
		}
	}
}
