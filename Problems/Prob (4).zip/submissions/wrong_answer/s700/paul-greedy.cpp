#include <bits/stdc++.h>
using namespace std;

int main() {
	int n, a, b;
	cin >> n >> a >> b;

	vector<int> p(a), q(b);
	for (int &x: p) cin >> x;
	for (int &y: q) cin >> y;
	p.push_back(-1e6);
	q.push_back(1e6);
	
	auto approachB = [&](int x, int y, int goal, int dt) {
		int ymin = max(x+1, y-dt), ymax = y+dt;
		return goal < ymin ? ymin : goal > ymax ? ymax : goal;
	};

	auto approachA = [&](int x, int y, int goal, int dt) {
		int xmin = x-dt, xmax = min(y-1, x+dt);
		return goal < xmin ? xmin : goal > xmax ? xmax : goal;
	};
	
	int i = 1, j = 1, x = 1, y = n, t = 1;

	while (i < a || j < b) {
		int dt = min(abs(p[i]-x), abs(q[j]-y));
		if (dt == abs(p[i]-x)) {
			x = p[i++], y = approachB(x, y, q[j], dt);
			if (y == q[j]) j++;
			else y = approachB(x, y, q[j], 1);
		} else {
			y = q[j++], x = approachA(x, y, p[i], dt);
			if (x == p[i]) i++;
			else x = approachA(x, y, p[i], 1);
		}
		t += dt+1;
	}

	cout << t << endl;
}
