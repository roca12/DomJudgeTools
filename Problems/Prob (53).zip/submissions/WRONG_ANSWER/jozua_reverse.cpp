#include <bits/stdc++.h>
using namespace std;

/*
Code by Timon
Copied by Joshua to make mistakes
*/

using ll = long long;
using vi = vector<ll>;
using ii = pair<ll, ll>;
using vii = vector<ii>;
using vvii = vector<vii>;

vi dijkstra(int s, const vvii &E) {
	vi d(E.size(), -1LL);
	priority_queue<ii, vii, greater<ii>> pq;
	pq.push({d[s] = 0LL, s});
	while (!pq.empty()) {
		ll u, w;
		tie(w, u) = pq.top(); pq.pop();
		if (d[u] != w) continue;
		for (ii adj : E[u]) {
			if (d[adj.first] < 0LL || d[adj.first] > d[u] + adj.second) {
				pq.push({d[adj.first] = d[u] + adj.second, adj.first});
			}
		}
	}
	return d;
}

bool dfs(int u, const vvii &E, const vi &d, vi &vis, vi &res) {
	res.push_back(u);
	vis[u] = 1;

	if (u == 1) return true;

	for (auto e : E[u]) {
		if (vis[e.first]) continue;
		if (d[u] == e.second + d[e.first]) continue;
		if (dfs(e.first, E, d, vis, res)) return true;
	}

	res.pop_back();
	return false;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int n, m;
	cin >> n >> m;

	vvii E(n);
	while (m--) {
		int a, b, w;
		cin >> a >> b >> w;
		E[a].push_back({b, w});
		E[b].push_back({a, w});
	}

	vi d = dijkstra(1, E), vis(n, 0), res;
	if (dfs(0, E, d, vis, res)) {
		cout << res.size();
		for (auto it = res.rbegin(); it != res.rend(); ++it) cout << ' ' << *it;
		cout << endl;
	} else cout << "impossible" << endl;
}
