#include <iostream>
#include <cstdlib>

using namespace std;

int main(){
	char out[100000];
	for(int i = 0; i < 100000; ++i) out[i] = rand();
	out[99999] = '\0';
	cout << out << endl;
}