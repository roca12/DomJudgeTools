#include <iostream>

using namespace std;

int main(){
	char out[100000];
	out[99999] = '\0';
	cout << out << endl;
}