#include <iostream>
using namespace std;

int main(){
	cout << 1000000;
	for(int i = 0; i < 1000000; ++i){
		cout << ' ' << i;
	}
	cout << endl;
}
