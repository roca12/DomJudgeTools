#include <cstdio>
#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

typedef vector<int> vi;
typedef pair<int, int> pii;
typedef vector<pii> vpii;
typedef vector<vpii> vvpii;

int n, m;
vvpii adj_list;


class compare {
    public:
        bool operator() (pii &p1, pii &p2) {
            return p1.second > p2.second;
        }
};

vi distances;
vpii origin;
vi prev_node;

void dijkstra(int start_node, bool allow_shortest_edge) {
    vi visited;
    distances.assign(n, 9999999);
    visited.assign(n, 0); 
    if(allow_shortest_edge) {
        origin.assign(n, pii(-1, -1));
    } else {
        prev_node.assign(n, -1);
    }

    priority_queue<pii, vpii, compare> pq;

    pq.push(pii(start_node, 0));
    distances[start_node] = 0;

    while(!pq.empty()) {
        pii nf = pq.top();
        pq.pop();

        int node_from = nf.first;
        int dist_from = nf.second;

        if(visited[node_from]) {
            continue;
        }
        visited[node_from] = 1;
        
        for(auto nt : adj_list[node_from]) {
            int node_to = nt.first;
            int dist_between = nt.second;

            /*if(!allow_shortest_edge) {
                cout << "nt: (" << nt.first << ", " << nt.second << endl;
                cout << "origin: (" << origin[node_from].first << ", " << origin[node_from].second << endl;
                cout << node_from << "     " << distances[1] << endl;
            }*/
            if(!allow_shortest_edge && nt == origin[node_from]) {
                continue;
            }
            

            int dist = dist_from + dist_between;
            if(distances[node_to] > dist) {
                distances[node_to] = dist;
                if(allow_shortest_edge) {
                    origin[node_to] = pii(node_from, dist_between);
                }
                if(!allow_shortest_edge) {
                    prev_node[node_to] = node_from; 
                }
            }
            pq.push(pii(node_to, dist));
        }
    }

}

int main() {

    cin >> n >> m;

    //n++;

    adj_list.assign(n, vpii());

    for(int i=0; i<m; i++) {
        int a, b, d;
        cin >> a >> b >> d;
        //a--; b--;
        adj_list[a].push_back(pii(b, d));
        adj_list[b].push_back(pii(a, d));
    }

    for(int i=0; i<n; i++) {
        dijkstra(i,true);
    }

    dijkstra(1, true);

    /*for(int i=0; i<n; i++) {
        cout << i << " " << distances[i] << " : " << origin[i].first << " " << origin[i].second << endl;
    }*/

    dijkstra(0,false);

    /*for(int i=0; i<n; i++) {
        cout << i << " " << distances[i] << endl;
    }*/

    if(distances[1] < 9999999) {
        stack<int> s;
        int prev = 1;
        s.push(prev);
        while(prev != 0) {
            prev = prev_node[prev];
            s.push(prev);
        }

        cout << s.size();
        while(!s.empty()) {
            cout << " " << s.top();
            s.pop();
        }
        cout << endl;
    } else {
        cout << "impossible" << endl;
    }

    return 0;
}
