#include <iostream>
#include <queue>
#include <vector>
using namespace std;
using ll = long long;
struct Edge {
	int v;
	ll weight;
}; // input edges
struct PQ {
	ll d;
	int v;
	Edge *e;
}; // distance and target
bool operator>(const PQ &l, const PQ &r) { return l.d > r.d; }
pair<vector<int>, ll> dijkstra(vector<vector<Edge>> &edges, int s, int t) {
	vector<ll> dist(edges.size(), 1e13);
	vector<int> p(edges.size(), -1);
	priority_queue<PQ, vector<PQ>, greater<PQ>> pq;
	dist[s] = 0;
	pq.push({0, s, nullptr});
	while(!pq.empty()) {
		auto x = pq.top();
		pq.pop();
		if(x.v == t) break; // target reached
		if(x.d == dist[x.v]) {
			if(x.e) x.e->weight = 1e13;
			for(auto &e : edges[x.v])
				if(dist[e.v] > x.d + e.weight)
					pq.push({dist[e.v] = x.d + e.weight, e.v, &e}), p[e.v] = x.v;
		}
	}
	return {p, t == -1 ? -1 : dist[t]};
}
int main() {
	int n, m;
	cin >> n >> m;
	vector<vector<Edge>> g(n);
	int s = 0, t = 1;
	while(m--) {
		int u, v, c;
		cin >> u >> v >> c;
		g[u].push_back({v, c});
		g[v].push_back({u, c});
	}
	dijkstra(g, t, -1);
	auto _ = dijkstra(g, t, s);
	if(_.second >= 1e13) return cout << "impossible\n", 0;
	auto p = _.first;
	vector<int> path;
	for(int u = s; u != -1; u = p[u]) path.push_back(u);
	cout << path.size();
	for(auto u : path) cout << ' ' << u;
	cout << endl;
	return 0;
}
