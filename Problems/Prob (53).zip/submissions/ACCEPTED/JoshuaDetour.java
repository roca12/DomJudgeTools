import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/*
First Dijkstra
Then again Dijkstra (why not the shortest ;-))

Should be AC, but just hits the 1s bound
This is *slightly* then my other solution
*/

public class JoshuaDetour {
    int n, m;
    int AMSTERDAM = 1;
    int DELFT = 0;
    // index -> adjecency list with two components
    List<int[]>[] adj_w;
    int[] parents;
    int[] parents2;
    private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws IOException {
        (new JoshuaDetour()).solve();
    }

    void dijkstra(int s) {
        parents = new int[n];
        Arrays.fill(parents, -1);
        boolean[] seen = new boolean[n];
        Arrays.fill(seen, false);
        int[] dist = new int[n];
        Arrays.fill(dist, Integer.MAX_VALUE);

        PriorityQueue<int[]> work = new PriorityQueue<>(Comparator.comparingInt(o -> o[1]));
        dist[s] = 0;
        work.add(new int[]{s, dist[s]});

        while (!work.isEmpty()) {
            int[] curr = work.poll();
            int currn = curr[0];

            if (seen[currn]) continue;
            seen[currn] = true;

            for (int[] tw : adj_w[currn]) {
                int t = tw[0];
                if (seen[t]) continue;

                int newd = dist[currn] + tw[1];

                if (newd < dist[t]) {
                    dist[t] = newd;
                    parents[t] = currn;
                    work.add(new int[]{t, dist[t]});
                }
            }
        }
    }

    void dijkstra2(int s, int s2) {
        parents2 = new int[n];
        Arrays.fill(parents2, -1);
        boolean[] seen = new boolean[n];
        Arrays.fill(seen, false);
        int[] dist = new int[n];
        Arrays.fill(dist, Integer.MAX_VALUE);

        PriorityQueue<int[]> work = new PriorityQueue<>(Comparator.comparingInt(o -> o[1]));
        dist[s] = 0;
        work.add(new int[]{s, dist[s]});

        while (!work.isEmpty()) {
            int[] curr = work.poll();
            int currn = curr[0];

            if (seen[currn]) continue;
            seen[currn] = true;

            if (currn == s2) return;

            for (int[] tw : adj_w[currn]) {
                int t = tw[0];
                if (parents[currn] == t) continue; // NOT ALLOWED!
                if (seen[t]) continue;

                int newd = dist[currn] + tw[1];

                if (newd < dist[t]) {
                    dist[t] = newd;
                    parents2[t] = currn;
                    work.add(new int[]{t, dist[t]});
                }
            }
        }
    }

    void solve() throws IOException {
        String[] words = br.readLine().split("\\s");
        n = Integer.parseInt(words[0]);
        m = Integer.parseInt(words[1]);

        adj_w = new ArrayList[n];
        for (int i = 0; i < n; i++) {
            adj_w[i] = new ArrayList<>();
        }

        for (int i = 0; i < m; i++) {
            words = br.readLine().split("\\s");
            int a = Integer.parseInt(words[0]);
            int b = Integer.parseInt(words[1]);
            int d = Integer.parseInt(words[2]);

            adj_w[a].add(new int[]{b, d});
            adj_w[b].add(new int[]{a, d});
        }

        dijkstra(AMSTERDAM);

        dijkstra2(DELFT, AMSTERDAM);

        if (parents2[AMSTERDAM] == -1) {
            System.out.println("impossible");
            return;
        } else {
            List<Integer> sol = new ArrayList<>();

            int n = AMSTERDAM;
            while (n != -1) {
                sol.add(n);
                n = parents2[n];
            }

            System.out.print(sol.size());
            Collections.reverse(sol);
            for (int x : sol) {
                System.out.print(" " + x);
            }
            System.out.println();
            return;
        }
    }
}
