import java.io.*;
import java.util.*;
import java.math.*;

public class ragnar {
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public ragnar() {}

	public static void main(String[] args) throws Exception { new ragnar().solve(); }

	class Edge {
		public int v;
		public long w;
		Edge(int _v, long _w) {
			v = _v;
			w = _w;
		}
	}

	long inf = 10000000000000L;

	class PQ implements Comparable<PQ> {
		public long d;
		public int v;
		public Edge e;
		PQ(long _d, int _v, Edge _e) {
			d = _d;
			v = _v;
			e = _e;
		}
		@Override
		public int compareTo(PQ r) {
			return Long.compare(d, r.d);
		}
	}

	public class Pair<T, U> {
		public final T t;
		public final U u;

		public Pair(T t, U u) {
			this.t = t;
			this.u = u;
		}
	}

	public Pair<int[], Long> dijkstra(ArrayList<Edge>[] g, int s, int t) {
		long[] dist = new long[g.length];
		int[] p     = new int[g.length];
		for(int i = 0; i < g.length; ++i) {
			dist[i] = inf;
			p[i]    = -1;
		}

		PriorityQueue<PQ> pq = new PriorityQueue<PQ>();
		dist[s]              = 0;
		pq.add(new PQ(0, s, null));
		while(!pq.isEmpty()) {
			PQ x = pq.poll();
			if(x.v == t) break;
			if(x.d == dist[x.v]) {
				if(x.e != null) x.e.w = inf;
				for(int i = 0; i < g[x.v].size(); ++i) {
					Edge e = g[x.v].get(i);
					if(dist[e.v] > x.d + e.w) {
						dist[e.v] = x.d + e.w;
						pq.add(new PQ(dist[e.v], e.v, e));
						p[e.v] = x.v;
					}
				}
			}
		}
		return new Pair<int[], Long>(p, t == -1 ? -1 : dist[t]);
	}

	public void solve() throws Exception {
		String input = in.readLine();

		String[] parts = input.split(" ");
		int n          = Integer.parseInt(parts[0]);
		int m          = Integer.parseInt(parts[1]);

		ArrayList<Edge>[] g = new ArrayList[n];
		for(int i = 0; i < n; ++i) g[i] = new ArrayList<Edge>();

		for(int i = 0; i < m; i++) {
			input      = in.readLine();
			String[] s = input.split(" ");
			int u      = Integer.parseInt(s[0]);
			int v      = Integer.parseInt(s[1]);
			int d      = Integer.parseInt(s[2]);

			g[u].add(new Edge(v, d));
			g[v].add(new Edge(u, d));
		}

		int s = 0, t = 1;
		dijkstra(g, t, -1);
		Pair<int[], Long> pair = dijkstra(g, t, s);
		if(pair.u >= inf) {
			System.out.println("impossible");
			return;
		}

		int[] p                 = pair.t;
		ArrayList<Integer> path = new ArrayList();
		for(int u = s; u != -1; u = p[u]) path.add(u);
		System.out.print(path.size());
		for(int i = 0; i < path.size(); ++i) {
			System.out.print(' ');
			System.out.print(path.get(i));
		}
		System.out.println();
	}
}
