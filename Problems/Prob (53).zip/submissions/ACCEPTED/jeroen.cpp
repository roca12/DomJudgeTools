#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <stack>

using namespace std;

#define INF (1LL<<60)
#define endl '\n'
#define mp make_pair

typedef pair<int64_t,int64_t> pii;

vector<int64_t> dist, pred;
vector<vector<pii> > g;
vector<vector<bool> > gokey;

void dijkstra(int64_t u, bool check){
	int64_t n = g.size();
	dist.assign(n,INF);
	pred.assign(n, -1);
    dist[u] = 0;
    priority_queue<pii> Q;
    Q.push({-dist[u],u});
    vector<bool> seen (n);

    while(!Q.empty()){
        pii p = Q.top();
        int64_t w = p.second;
        Q.pop();
        if(seen[w]) continue;
	    seen[w] = true;
        for(auto to : g[w]){

        	if( (check && !gokey[w][to.first]) ||  //If we need to check and cant take road
        		seen[to.first] || 
        		dist[to.first] <= dist[w] + to.second)
        		continue;

            dist[to.first] = dist[w] + to.second;
            if(!check && pred[to.first] != -1){
            	gokey[to.first][pred[to.first]] = true;
            	// gokey[pred[to.first]][to.first] = true;

            }
            pred[to.first] = w;
            if(!check){
	            gokey[to.first][w] = false;
	            // gokey[w][to.first] = false;
	        }
            Q.push({-dist[to.first],to.first});
        }
    }
}

int main(){
	ios::sync_with_stdio(false); cin.tie(nullptr);
	int n, m;
	cin >> n >> m;
	g.assign(n,vector<pii>());
	gokey.assign(n,vector<bool> (n,false));
	for(int i = 0; i < m; i++){
		int a, b, d;
		cin >> a >> b >> d;
		g[a].push_back({b,d});
		g[b].push_back({a,d});
		gokey[a][b] = true;
		gokey[b][a] = true;
	}

	dijkstra(1, false);
	int cur = 1, cnt = 0;
	// while(pred[cur] != -1 && cnt < 50000){
	// 	int next = pred[cur];
	// 	gokey[cur][next] = false;
	// 	gokey[next][cur] = false;
	// 	cur = next;
	// 	cnt++;
	// }
	/*
	stack<int> S;
	cur = 1;
	while(cur != -1){
		S.push(cur);
		cur = pred[cur];
	}
	clog << "shortest path ";
	clog << S.size() << " ";
	while(!S.empty()){
		int k = S.top();
		S.pop();
		if(S.empty()) clog << k << endl;
		else clog << k << " ";
	}
	*/

	dijkstra(0, true);
	if(dist[1] == INF) cout << "impossible" << endl;
	else{
		stack<int> S;
		cur = 1;
		while(cur != -1){
			S.push(cur);
			cur = pred[cur];
		}
		cout << S.size() << " ";
		while(!S.empty()){
			int k = S.top();
			S.pop();
			if(S.empty()) cout << k << endl;
			else cout << k << " ";
		}
	}

	return 0;
}