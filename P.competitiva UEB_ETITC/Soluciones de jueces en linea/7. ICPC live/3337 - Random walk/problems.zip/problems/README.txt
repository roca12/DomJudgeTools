Each problem is in a seperate subdirectory.  The typical structure is

index.html provides a table access to the problem descriptions and example data.

count/count.html
count/count.pdf
count/count.c -- example solution
count/cases/example/count.in
count/cases/example/count.out
count/cases/test1/count.in
count/cases/test1/count.out

etc.

The data format is all unix.


Enjoy!
